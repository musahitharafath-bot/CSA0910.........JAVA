#!/bin/sh
# Compile and run TaskB1
cd "$(dirname "$0")"
mkdir -p out output
javac -cp "../lib/*" -d out src/*.java
java -cp "out:../lib/*" PassStore | tee output/PassStore_output.txt
java -cp "out:../lib/*" StoreTests | tee output/StoreTests_output.txt
java -cp "out:../lib/*" CountBench output | tee output/CountBench_output.txt
java -cp "out:../lib/*" FindGrowth output | tee output/FindGrowth_output.txt
rm -rf out
