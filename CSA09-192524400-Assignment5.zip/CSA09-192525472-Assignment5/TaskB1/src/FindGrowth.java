import java.io.*;
import java.nio.file.*;
import java.util.*;

/** B1.4: time to find a pass as the file grows (text store), and the HashMap alternative of Task B1. */
public class FindGrowth {
    public static void main(String[] args) throws Exception {
        String out = args.length > 0 ? args[0] : "output";
        Files.createDirectories(Path.of(out));
        int[] sizes = {1000, 5000, 10000, 50000, 100000};
        try (PrintWriter g = new PrintWriter(out + "/b1_growth.csv"); PrintWriter q = new PrintWriter(out + "/b1_queries.csv"); PrintWriter raw = new PrintWriter(out + "/b1_growth_raw.csv")) {
            g.println("records,file_kb,find_first_ms,find_last_ms,find_missing_ms,find_random_ms_mean,find_random_ms_sd,alloc_per_find_kb");
            raw.println("records,case,rep,ms");
            System.out.printf("%-9s %9s %12s %12s %14s %18s %16s%n", "records", "file KB", "first (ms)", "last (ms)", "missing (ms)", "random hit (ms)", "garbage/find KB");
            Path big = null;
            for (int n : sizes) {
                Path f = Files.createTempFile("store" + n, ".txt"); DataGen.writeStoreFile(f, n, 5);
                BusPassFileStore s = new BusPassFileStore(f);
                Random r = new Random(1);
                String first = "P000001", last = String.format("P%06d", n), none = "P999999";
                Runnable rf = () -> { try { Bench.sink += s.find(first).isPresent() ? 1 : 0; } catch (IOException e) { throw new RuntimeException(e); } };
                Runnable rl = () -> { try { Bench.sink += s.find(last).isPresent() ? 1 : 0; } catch (IOException e) { throw new RuntimeException(e); } };
                Runnable rm = () -> { try { Bench.sink += s.find(none).isPresent() ? 1 : 0; } catch (IOException e) { throw new RuntimeException(e); } };
                int reps = n >= 50000 ? 9 : 15;
                double[] a = Bench.measure(rf, 5, reps), b = Bench.measure(rl, 5, reps), c = Bench.measure(rm, 5, reps);
                double[] rnd = new double[reps * 4];                                     // random existing IDs: the average case
                for (int i = 0; i < rnd.length; i++) { String id = String.format("P%06d", 1 + r.nextInt(n)); long t0 = System.nanoTime(); try { Bench.sink += s.find(id).isPresent() ? 1 : 0; } catch (IOException e) { throw new RuntimeException(e); } rnd[i] = System.nanoTime() - t0; }
                long alloc = Bench.allocated(rm);
                for (int i = 0; i < reps; i++) { raw.printf("%d,first,%d,%.4f%n%d,last,%d,%.4f%n%d,missing,%d,%.4f%n", n, i + 1, a[i] / 1e6, n, i + 1, b[i] / 1e6, n, i + 1, c[i] / 1e6); }
                g.printf("%d,%d,%.4f,%.4f,%.4f,%.4f,%.4f,%.1f%n", n, Files.size(f) / 1024, Bench.mean(a) / 1e6, Bench.mean(b) / 1e6, Bench.mean(c) / 1e6, Bench.mean(rnd) / 1e6, Bench.stdev(rnd) / 1e6, alloc / 1024.0);
                System.out.printf("%-9d %9d %12.3f %12.3f %14.3f %12.3f (sd %.3f) %12.1f%n", n, Files.size(f) / 1024, Bench.mean(a) / 1e6, Bench.mean(b) / 1e6, Bench.mean(c) / 1e6, Bench.mean(rnd) / 1e6, Bench.stdev(rnd) / 1e6, alloc / 1024.0);
                if (n == 100000) big = f; else Files.delete(f);
            }

            // ---- alternative: read once into a HashMap<String, String[]> keyed by pass ID
            System.out.println("\nAlternative: HashMap loaded once (n = 100,000 passes). Total time for q searches:");
            BusPassFileStore s = new BusPassFileStore(big);
            Bench.gc(); long h0 = Bench.usedHeap();
            long t0 = System.nanoTime();
            Map<String, String[]> map = new HashMap<>();
            try (BufferedReader r = new BufferedReader(new FileReader(big.toFile()))) {
                String line; while ((line = r.readLine()) != null) { if (line.startsWith("#")) continue; PassCodec.Result res = PassCodec.decode(line); if (res.ok()) map.put(res.pass().passId, line.split(",", -1)); }
            }
            double loadMs = (System.nanoTime() - t0) / 1e6;
            Bench.gc(); long h1 = Bench.usedHeap(); Bench.sink += map.size();
            double heapPerRec = (h1 - h0) / 100000.0;
            Random r = new Random(2);
            double[] lk = new double[2000]; for (int i = 0; i < lk.length; i++) { String id = String.format("P%06d", 1 + r.nextInt(100000)); long a = System.nanoTime(); Bench.sink += map.get(id) != null ? 1 : 0; lk[i] = System.nanoTime() - a; }
            double lookupNs = Bench.mean(lk);
            System.out.printf("  load once: %.1f ms, retained heap %.1f MB (%.0f bytes per record), one lookup %.0f ns%n", loadMs, (h1 - h0) / 1048576.0, heapPerRec, lookupNs);
            q.println("q,scan_total_ms,hashmap_total_ms,scan_per_search_ms");
            System.out.printf("  %-8s %18s %20s%n", "q", "scan every time (ms)", "load + q lookups (ms)");
            double perScan = 0;
            for (int qq : new int[]{1, 10, 100, 1000}) {
                Random rr = new Random(3); String[] ids = new String[qq]; for (int i = 0; i < qq; i++) ids[i] = String.format("P%06d", 1 + rr.nextInt(100000));
                long a = System.nanoTime(); for (String id : ids) Bench.sink += s.find(id).isPresent() ? 1 : 0; double scanMs = (System.nanoTime() - a) / 1e6;
                a = System.nanoTime(); for (String id : ids) Bench.sink += map.get(id) != null ? 1 : 0; double mapMs = loadMs + (System.nanoTime() - a) / 1e6;
                perScan = scanMs / qq;
                q.printf("%d,%.2f,%.2f,%.3f%n", qq, scanMs, mapMs, perScan);
                System.out.printf("  %-8d %18.1f %20.1f%n", qq, scanMs, mapMs);
            }
            q.println("# map_load_ms," + String.format("%.2f", loadMs) + ",heap_bytes_per_record," + String.format("%.0f", heapPerRec) + ",lookup_ns," + String.format("%.0f", lookupNs));
            Files.delete(big);
        }
    }
}
