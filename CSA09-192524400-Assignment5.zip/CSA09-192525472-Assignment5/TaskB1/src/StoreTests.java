import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;

/** B1.1: tests of the Task A1 text store. Each row says what is expected and what happened. */
public class StoreTests {
    static int pass, fail;
    static void check(String id, String what, String expected, String actual) {
        boolean ok = expected.equals(actual); if (ok) pass++; else fail++;
        System.out.printf("%-4s %-52s expected: %-34s actual: %-34s %s%n", id, what, expected, actual, ok ? "PASS" : "FAIL");
    }
    static BusPass p(String id, String name, int route, double amt) { return new BusPass(id, "192311001", name, route, "Tambaram", LocalDate.of(2027, 3, 31), amt); }
    static String show(Optional<BusPass> o) { return o.map(x -> x.passId + "/" + x.name + "/Rs" + (int) x.amount).orElse("not found"); }

    public static void main(String[] args) throws Exception {
        Path f = Files.createTempFile("buspass", ".txt"); Files.delete(f);
        BusPassFileStore s = new BusPassFileStore(f);
        System.out.println("--- Missing file");
        check("T1", "find in a file that does not exist", "not found", show(s.find("P000001")));
        check("T2", "list route in a file that does not exist", "0", String.valueOf(s.listByRoute(5).size()));

        System.out.println("--- Normal cases");
        s.add(p("P000001", "Arun Kumar", 12, 4500), true);
        s.add(p("P000002", "Divya Raman", 7, 3800), true);
        s.add(p("P000003", "Raman, Meena", 12, 4500), true);       // the name contains the delimiter
        check("T3", "add creates the file; find an existing pass", "P000002/Divya Raman/Rs3800", show(s.find("P000002")));
        check("T4", "name that contains a comma is stored and restored", "P000003/Raman, Meena/Rs4500", show(s.find("P000003")));
        check("T5", "list passes of route 12", "P000001,P000003", s.listByRoute(12).stream().map(x -> x.passId).reduce((a, b) -> a + "," + b).orElse(""));

        System.out.println("--- Pass ID that does not exist");
        check("T6", "find P999999 (not in the file)", "not found", show(s.find("P999999")));

        System.out.println("--- Damaged data");
        String good = Files.readString(f);
        Files.writeString(f, "P000004,DAMAGED LINE\n", StandardOpenOption.APPEND);                       // wrong number of fields
        Files.writeString(f, "\n", StandardOpenOption.APPEND);                                              // empty line
        String ok5 = PassCodec.encode(p("P000005", "Karthik Nair", 9, 4100));
        Files.writeString(f, ok5.replace("4100.00", "41OO.00") + "\n", StandardOpenOption.APPEND);        // amount altered after the checksum
        s.add(p("P000006", "Rahul Das", 9, 4100), false);
        check("T7", "find the pass AFTER the damaged lines", "P000006/Rahul Das/Rs4100", show(s.find("P000006")));
        check("T8", "find the pass whose line is damaged (wrong field count)", "not found", show(s.find("P000004")));
        check("T9", "find the pass whose amount was altered (checksum)", "not found", show(s.find("P000005")));
        BusPassFileStore.ScanResult sr = s.scanAll();
        check("T10", "scan reports the three damaged lines", "3 damaged, 4 good", sr.damaged.size() + " damaged, " + sr.passes.size() + " good");
        for (BusPassFileStore.Damaged d : sr.damaged) System.out.println("       line " + d.lineNo() + ": " + d.reason() + "   [" + d.text() + "]");

        System.out.println("--- Incomplete write (power failure) and recovery");
        byte[] all = Files.readAllBytes(f);
        Files.write(f, Arrays.copyOf(all, all.length - 12));                                                // cut the last line in the middle, no newline
        check("T11", "half-written last line is ignored", "not found", show(s.find("P000006")));
        s.add(p("P000007", "Priya Menon", 3, 4000), true);
        check("T12", "next add is not glued to the broken line", "P000007/Priya Menon/Rs4000", show(s.find("P000007")));
        check("T13", "invalid pass (negative amount) is rejected by add()", "rejected", rejected(s, p("P000008", "Test", 3, -5)));
        System.out.println("\nTests passed: " + pass + ", failed: " + fail);
        Files.delete(f);
    }
    static String rejected(BusPassFileStore s, BusPass p) throws IOException {
        try { s.add(p, false); return "accepted"; } catch (IllegalArgumentException e) { return "rejected"; }
    }
}
