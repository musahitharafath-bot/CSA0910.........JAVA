import java.nio.file.*;

/** Counts the lines of one file with one method; used with strace to see the real number of read system calls. */
public class OneRun {
    public static void main(String[] args) throws Exception {
        Path f = Path.of(args[0]); long[] c = new long[1];
        long lines = args[1].equals("unbuffered") ? LineCounter.unbuffered(f, c) : LineCounter.bufferedStream(f, 8192, c);
        System.out.println(args[1] + ": " + lines + " lines, read calls seen by FileInputStream: " + c[0]);
    }
}
