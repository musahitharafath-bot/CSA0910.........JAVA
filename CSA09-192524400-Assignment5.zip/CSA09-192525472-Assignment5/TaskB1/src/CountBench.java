import java.io.PrintWriter;
import java.nio.file.*;
import java.util.*;

/** B1.3: time to count lines in 1, 10 and 50 MB files, unbuffered versus buffered. */
public class CountBench {
    interface Counter { long count(Path p, long[] calls) throws Exception; }

    public static void main(String[] args) throws Exception {
        String out = args.length > 0 ? args[0] : "output";
        Files.createDirectories(Path.of(out));
        Map<String, Counter> methods = new LinkedHashMap<>();
        methods.put("1 unbuffered read()", LineCounter::unbuffered);
        methods.put("2 BufferedInputStream 8 KB, read()", (p, c) -> LineCounter.bufferedStream(p, 8192, c));
        methods.put("3 BufferedInputStream 64 KB, read()", (p, c) -> LineCounter.bufferedStream(p, 65536, c));
        methods.put("4 own byte[64 KB], read(byte[])", (p, c) -> LineCounter.byteArray(p, 65536, c));
        methods.put("5 BufferedInputStream 8 KB + read(byte[64 KB])", (p, c) -> LineCounter.bufferedStreamBigReads(p, c));
        methods.put("6 BufferedReader.readLine()", LineCounter::readerReadLine);
        methods.put("7 Files.readAllLines()", LineCounter::readAllLines);
        System.out.println("(one MB = 1,048,576 bytes; the files are in the operating-system cache, so the cost shown is the cost of making calls, not of the disk)");
        System.out.printf("%-10s %-48s %10s %9s %16s %12s %10s%n", "file", "method", "mean ms", "sd", "read calls", "alloc MB", "lines");
        try (PrintWriter raw = new PrintWriter(out + "/b1_count_raw.csv"); PrintWriter sum = new PrintWriter(out + "/b1_count_summary.csv")) {
            raw.println("size_mb,method,rep,ms");
            sum.println("size_mb,method,reps,mean_ms,sd_ms,median_ms,read_calls,allocated_bytes,lines");
            for (int mb : new int[]{1, 10, 50}) {
                Path f = Files.createTempFile("log" + mb, ".txt");
                long lines = DataGen.writeLog(f, mb * 1048576L, 11);
                for (var e : methods.entrySet()) {
                    boolean slow = e.getKey().startsWith("1 ") && mb == 50;
                    int warm = slow ? 0 : (mb == 50 ? 1 : 2), reps = slow ? 3 : (mb == 50 ? 5 : 7);
                    long[] calls = new long[1]; long[] got = new long[1];
                    double[] ms = new double[reps];
                    for (int i = 0; i < warm + reps; i++) {
                        long t0 = System.nanoTime(); got[0] = e.getValue().count(f, calls); double t = (System.nanoTime() - t0) / 1e6;
                        if (i >= warm) { ms[i - warm] = t; raw.printf("%d,\"%s\",%d,%.3f%n", mb, e.getKey(), i - warm + 1, t); }
                    }
                    long bytes = Bench.allocated(() -> { try { got[0] = e.getValue().count(f, calls); } catch (Exception ex) { throw new RuntimeException(ex); } });
                    if (got[0] != lines) throw new IllegalStateException(e.getKey() + " counted " + got[0] + " instead of " + lines);
                    sum.printf("%d,\"%s\",%d,%.3f,%.3f,%.3f,%d,%d,%d%n", mb, e.getKey(), reps, Bench.mean(ms), Bench.stdev(ms), Bench.median(ms), calls[0], bytes, lines);
                    System.out.printf("%-10s %-48s %10.1f %9.1f %,16d %12.2f %,10d%n", mb + " MB", e.getKey(), Bench.mean(ms), Bench.stdev(ms), calls[0], bytes / 1048576.0, lines);
                }
                Files.delete(f); System.out.println();
            }
        }
    }
}
