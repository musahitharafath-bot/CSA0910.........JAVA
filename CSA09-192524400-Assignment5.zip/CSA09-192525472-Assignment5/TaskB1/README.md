# TaskB1 - Assignment 5 (CO5), Programming in Java

**Student:** Syed Aakif Hussain S A  |  **Register number:** 192525472

File store (BusPassFileStore), tests, six line-counting methods, find-time growth, and the Complete-the-Code PassStore.

## Environment
- Compiled and run with Java 21.0.12.1
- No database needed.
- Test database for the reported results: MariaDB 10.11 with MariaDB Connector/J (MySQL-compatible). Edit `../db.properties` to use your own MySQL.

## Folder contents
- `src/` - Java source code
- `output/` - program output (`*_output.txt`), console screenshots (`*_console.png`), CSV data and charts
- `run.sh` - compiles and runs everything in this task

## How to run
```
sh run.sh
```
Or by hand: `javac -cp "../lib/*" -d out src/*.java` then `java -cp "out:../lib/*" <MainClass> output`.

## Programs and results
- `PassStore` -> `output/PassStore_output.txt` and `output/PassStore_console.png`
- `StoreTests` -> `output/StoreTests_output.txt` and `output/StoreTests_console.png`
- `CountBench` -> `output/CountBench_output.txt` and `output/CountBench_console.png`
- `FindGrowth` -> `output/FindGrowth_output.txt` and `output/FindGrowth_console.png`

Data files and charts written to `output/`: `b1_*.csv`, `chart_b1_*.png`.

Timings are from a shared 2-vCPU machine and vary by run. Compare ratios and trends, not single numbers.
