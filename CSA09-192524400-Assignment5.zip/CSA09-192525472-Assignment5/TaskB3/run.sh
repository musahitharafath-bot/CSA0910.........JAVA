#!/bin/sh
# Compile and run TaskB3
cd "$(dirname "$0")"
mkdir -p out output
javac -cp "../lib/*" -d out src/*.java
java -cp "out:../lib/*" InsertBench output | tee output/InsertBench_output.txt
rm -rf out
