import java.sql.*;
import java.util.*;

/** The other ways of inserting that are compared in B3.2 / B3.3 (all use the same five columns as PassLoader). */
final class Loaders {
    static final String SQL5 = "INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount) VALUES (?, ?, ?, ?, ?)";

    static List<String[]> rows(int n, long seed) {
        List<String[]> out = new ArrayList<>(n);
        for (BusPass p : DataGen.passes(n, seed)) out.add(new String[]{p.passId, p.regNo, p.name, String.valueOf(p.route), String.valueOf(p.amount)});
        return out;
    }
    static String esc(String s) { return s.replace("\\", "\\\\").replace("'", "''"); }

    /** (a) Statement: the SQL text is built by concatenation for every row. */
    static int statement(Connection con, List<String[]> rows, boolean oneTransaction) throws SQLException {
        boolean old = con.getAutoCommit(); con.setAutoCommit(!oneTransaction);
        try (Statement st = con.createStatement()) {
            for (String[] p : rows) st.executeUpdate("INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount) VALUES ('" + esc(p[0]) + "','" + esc(p[1]) + "','" + esc(p[2]) + "'," + p[3] + "," + p[4] + ")");
            if (oneTransaction) con.commit();
        } catch (SQLException | RuntimeException e) { if (oneTransaction) con.rollback(); throw e; } finally { con.setAutoCommit(old); }
        return rows.size();
    }

    /** (b) PreparedStatement: executeUpdate() once per row. */
    static int prepared(Connection con, List<String[]> rows, boolean oneTransaction) throws SQLException {
        boolean old = con.getAutoCommit(); con.setAutoCommit(!oneTransaction);
        try (PreparedStatement ps = con.prepareStatement(SQL5)) {
            for (String[] p : rows) { bind(ps, p); ps.executeUpdate(); }
            if (oneTransaction) con.commit();
        } catch (SQLException | RuntimeException e) { if (oneTransaction) con.rollback(); throw e; } finally { con.setAutoCommit(old); }
        return rows.size();
    }

    /** (c) PreparedStatement with addBatch()/executeBatch(), 1,000 rows per batch. */
    static int batch(Connection con, List<String[]> rows, boolean oneTransaction) throws SQLException {
        boolean old = con.getAutoCommit(); con.setAutoCommit(!oneTransaction);
        try (PreparedStatement ps = con.prepareStatement(SQL5)) {
            int n = 0;
            for (String[] p : rows) { bind(ps, p); ps.addBatch(); if (++n % 1000 == 0) ps.executeBatch(); }
            ps.executeBatch();
            if (oneTransaction) con.commit();
        } catch (SQLException | RuntimeException e) { if (oneTransaction) con.rollback(); throw e; } finally { con.setAutoCommit(old); }
        return rows.size();
    }

    /** (d) Alternative: one INSERT statement with many VALUES groups (b rows per statement). */
    static int multiRow(Connection con, List<String[]> rows, int b) throws SQLException {
        boolean old = con.getAutoCommit(); con.setAutoCommit(false);
        try (Statement st = con.createStatement()) {
            for (int i = 0; i < rows.size(); i += b) {
                StringBuilder sb = new StringBuilder("INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount) VALUES ");
                for (int j = i; j < Math.min(i + b, rows.size()); j++) {
                    String[] p = rows.get(j); if (j > i) sb.append(',');
                    sb.append("('").append(esc(p[0])).append("','").append(esc(p[1])).append("','").append(esc(p[2])).append("',").append(p[3]).append(',').append(p[4]).append(')');
                }
                st.executeUpdate(sb.toString());
            }
            con.commit();
        } catch (SQLException | RuntimeException e) { con.rollback(); throw e; } finally { con.setAutoCommit(old); }
        return rows.size();
    }

    static void bind(PreparedStatement ps, String[] p) throws SQLException {
        ps.setString(1, p[0]); ps.setString(2, p[1]); ps.setString(3, p[2]); ps.setInt(4, Integer.parseInt(p[3])); ps.setDouble(5, Double.parseDouble(p[4]));
    }
}
