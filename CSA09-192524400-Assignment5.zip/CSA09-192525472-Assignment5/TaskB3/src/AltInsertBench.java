import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/** B3 alternative concepts: multi-row INSERT statements and LOAD DATA LOCAL INFILE, compared with the PreparedStatement batch. */
public class AltInsertBench {
    static void writeCsv(Path f, List<String[]> rows) throws IOException {
        try (BufferedWriter w = Files.newBufferedWriter(f)) {
            for (String[] p : rows) w.write(p[0] + "," + p[1] + ",\"" + p[2].replace("\"", "\"\"") + "\"," + p[3] + "," + p[4] + "\n");
        }
    }

    public static void main(String[] args) throws Exception {
        String out = args.length > 0 ? args[0] : "output";
        Files.createDirectories(Path.of(out));
        try (Connection root = Db.connect(); PrintWriter csv = new PrintWriter(out + "/b3_alternatives.csv")) {
            Db.runScript(root, Path.of("schema.sql"));
            csv.println("rows,method,mean_ms,sd_ms,client_bytes_allocated_per_row");
            System.out.println("Each method inserts all rows inside ONE transaction (LOAD DATA is one statement). Client memory = bytes allocated by the Java program per row inserted.\n");
            System.out.printf("%-9s %-40s %12s %10s %18s%n", "rows", "method", "mean ms", "sd", "client B per row");
            for (int n : new int[]{10000, 100000}) {
                List<String[]> rows = Loaders.rows(n, 61);
                Path file = Files.createTempFile("passes", ".csv"); writeCsv(file, rows);
                Object[][] ms = {
                    {"PreparedStatement + batch (PassLoader)", (Callable) () -> PassLoader.loadAll(root, rows)},
                    {"multi-row INSERT, 100 rows per statement", (Callable) () -> Loaders.multiRow(root, rows, 100)},
                    {"multi-row INSERT, 1,000 rows per statement", (Callable) () -> Loaders.multiRow(root, rows, 1000)},
                    {"LOAD DATA LOCAL INFILE", (Callable) () -> {
                        try (Statement st = root.createStatement()) {
                            return st.executeUpdate("LOAD DATA LOCAL INFILE '" + file.toString().replace("\\", "/") + "' INTO TABLE bus_pass CHARACTER SET utf8mb4 FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' LINES TERMINATED BY '\\n' (pass_id, reg_no, name, route_no, amount)");
                        }
                    }}};
                for (Object[] m : ms) {
                    Callable c = (Callable) m[1]; int reps = n == 100000 ? 3 : 5; double[] t = new double[reps];
                    for (int i = -1; i < reps; i++) {
                        Db.run(root, "TRUNCATE TABLE bus_pass");
                        long t0 = System.nanoTime(); int got = c.call(); double ms1 = (System.nanoTime() - t0) / 1e6;
                        if (got != n || Db.count(root, "bus_pass") != n) throw new IllegalStateException(m[0] + " inserted " + got + ", table has " + Db.count(root, "bus_pass"));
                        if (i >= 0) t[i] = ms1;
                    }
                    Db.run(root, "TRUNCATE TABLE bus_pass");
                    long bytes = Bench.allocated(() -> { try { c.call(); } catch (Exception e) { throw new RuntimeException(e); } });
                    csv.printf("%d,\"%s\",%.2f,%.2f,%.1f%n", n, m[0], Bench.mean(t), Bench.stdev(t), bytes / (double) n);
                    System.out.printf("%-9d %-40s %12.1f %10.1f %18.0f%n", n, m[0], Bench.mean(t), Bench.stdev(t), bytes / (double) n);
                }
                Files.delete(file); System.out.println();
            }
            Db.run(root, "TRUNCATE TABLE bus_pass");
        }
    }
    interface Callable { int call() throws Exception; }
}
