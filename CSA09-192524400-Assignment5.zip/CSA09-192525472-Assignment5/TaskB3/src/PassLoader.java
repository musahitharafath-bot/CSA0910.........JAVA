import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class PassLoader {
    /** Inserts all passes (each String[] = passId, regNo, name, route, amount). Returns the number inserted; all or nothing. */
    public static int loadAll(Connection con, List<String[]> passes) throws SQLException {
        String sql = "INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount) " + "VALUES (?, ?, ?, ?, ?)";
        boolean oldAuto = con.getAutoCommit();
        con.setAutoCommit(false);
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            int n = 0;
            for (String[] p : passes) {
                // TODO 1 (completed): bind the five parameters with the correct setXxx() methods, then add to the batch
                ps.setString(1, p[0]);
                ps.setString(2, p[1]);
                ps.setString(3, p[2]);
                ps.setInt(4, Integer.parseInt(p[3]));
                ps.setDouble(5, Double.parseDouble(p[4]));
                ps.addBatch();
                if (++n % 1000 == 0) ps.executeBatch();
            }
            ps.executeBatch();
            // TODO 2 (completed): commit, and return the number of rows inserted
            con.commit();
            return n;
        } catch (SQLException | RuntimeException e) {
            // TODO 3 (completed): undo everything inserted so far, then rethrow so that the caller knows the load failed
            con.rollback();
            throw e;
        } finally {
            con.setAutoCommit(oldAuto);
        }
    }
}
