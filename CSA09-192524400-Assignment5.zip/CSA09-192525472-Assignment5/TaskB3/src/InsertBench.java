import java.io.PrintWriter;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/** B3.2: Statement, PreparedStatement and batch at 1,000 / 10,000 / 100,000 rows, with auto-commit on (JDBC default) and in one transaction. */
public class InsertBench {
    interface Load { int run(Connection c, List<String[]> rows) throws SQLException; }

    public static void main(String[] args) throws Exception {
        String out = args.length > 0 ? args[0] : "output";
        Files.createDirectories(Path.of(out));
        try (Connection probe = Db.connect(); PrintWriter raw = new PrintWriter(out + "/b3_insert_raw.csv"); PrintWriter sum = new PrintWriter(out + "/b3_insert_summary.csv")) {
            Db.runScript(probe, Path.of("schema.sql"));
            try (Statement st = probe.createStatement(); ResultSet rs = st.executeQuery("SELECT @@innodb_flush_log_at_trx_commit, @@version")) { rs.next(); System.out.println("Server " + rs.getString(2) + "; innodb_flush_log_at_trx_commit = " + rs.getString(1)); }
            System.out.println("Driver default batch behaviour. Time in ms for the whole load; the table is emptied before every run.\n");
            raw.println("rows,method,commit_mode,rep,ms"); sum.println("rows,method,commit_mode,reps,mean_ms,sd_ms,median_ms,rows_per_second");
            // method, commit mode, extra URL parameter
            Object[][] methods = {
                {"Statement", "auto-commit", "", (Load) (c, r) -> Loaders.statement(c, r, false)},
                {"PreparedStatement", "auto-commit", "", (Load) (c, r) -> Loaders.prepared(c, r, false)},
                {"PreparedStatement + batch", "auto-commit", "", (Load) (c, r) -> Loaders.batch(c, r, false)},
                {"Statement", "one transaction", "", (Load) (c, r) -> Loaders.statement(c, r, true)},
                {"PreparedStatement", "one transaction", "", (Load) (c, r) -> Loaders.prepared(c, r, true)},
                {"PreparedStatement + batch", "one transaction", "", (Load) (c, r) -> Loaders.batch(c, r, true)},
                {"batch, driver bulk protocol OFF", "one transaction", "useBulkStmts=false", (Load) (c, r) -> Loaders.batch(c, r, true)}};
            System.out.printf("%-9s %-34s %-16s %12s %10s %12s%n", "rows", "method", "commit mode", "mean ms", "sd", "rows/second");
            for (int n : new int[]{1000, 10000, 100000}) {
                List<String[]> rows = Loaders.rows(n, 41);
                for (Object[] m : methods) {
                    String name = (String) m[0], mode = (String) m[1]; Load ld = (Load) m[3];
                    int reps = n == 100000 ? 3 : (n == 10000 ? 5 : 7), warm = n == 100000 ? 0 : 1;
                    double[] ms = new double[reps];
                    try (Connection c = Db.connect((String) m[2])) {
                        for (int i = 0; i < warm + reps; i++) {
                            Db.run(c, "TRUNCATE TABLE bus_pass");
                            long t0 = System.nanoTime(); int got = ld.run(c, rows); double t = (System.nanoTime() - t0) / 1e6;
                            if (got != n || Db.count(c, "bus_pass") != n) throw new IllegalStateException("wrong row count");
                            if (i >= warm) { ms[i - warm] = t; raw.printf("%d,\"%s\",%s,%d,%.2f%n", n, name, mode, i - warm + 1, t); }
                        }
                    }
                    double mean = Bench.mean(ms);
                    sum.printf("%d,\"%s\",%s,%d,%.2f,%.2f,%.2f,%.0f%n", n, name, mode, reps, mean, Bench.stdev(ms), Bench.median(ms), n / (mean / 1000));
                    System.out.printf("%-9d %-34s %-16s %12.1f %10.1f %12.0f%n", n, name, mode, mean, Bench.stdev(ms), n / (mean / 1000));
                    sum.flush(); raw.flush();
                }
                System.out.println();
            }
            Db.run(probe, "TRUNCATE TABLE bus_pass");
        }
    }
}
