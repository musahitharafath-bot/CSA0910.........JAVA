import java.nio.file.*;
import java.sql.*;
import java.util.*;

/** B3.1 correctness (10 records, three ways, with metadata), the Complete-the-Code program, and the half-way failure. */
public class LoaderDemo {
    static String dump(Connection con) throws SQLException {
        StringBuilder sb = new StringBuilder();
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("SELECT pass_id, reg_no, name, route_no, amount FROM bus_pass ORDER BY pass_id")) {
            while (rs.next()) sb.append(rs.getString(1)).append('|').append(rs.getString(2)).append('|').append(rs.getString(3)).append('|').append(rs.getInt(4)).append('|').append(rs.getBigDecimal(5)).append('\n');
        }
        return sb.toString();
    }

    public static void main(String[] args) throws Exception {
        try (Connection con = Db.connect()) {
            Db.runScript(con, Path.of("schema.sql"));
            DatabaseMetaData md = con.getMetaData();
            System.out.println("Database: " + md.getDatabaseProductName() + " " + md.getDatabaseProductVersion() + " | Driver: " + md.getDriverName() + " " + md.getDriverVersion());
            System.out.println("\n=== B3.1 Table structure as the program sees it (ResultSetMetaData of SELECT * FROM bus_pass)");
            try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM bus_pass")) {
                ResultSetMetaData m = rs.getMetaData();
                System.out.printf("%-14s %-12s %6s %8s%n", "column", "SQL type", "size", "nullable");
                for (int i = 1; i <= m.getColumnCount(); i++) System.out.printf("%-14s %-12s %6d %8s%n", m.getColumnName(i), m.getColumnTypeName(i), m.getPrecision(i), m.isNullable(i) == ResultSetMetaData.columnNoNulls ? "NOT NULL" : "NULL");
            }
            List<String[]> ten = Loaders.rows(10, 21);
            String expected = null; StringBuilder exp = new StringBuilder();
            for (String[] p : ten.stream().sorted(Comparator.comparing(x -> x[0])).toList()) exp.append(p[0]).append('|').append(p[1]).append('|').append(p[2]).append('|').append(p[3]).append('|').append(String.format("%.2f", Double.parseDouble(p[4]))).append('\n');
            expected = exp.toString();
            System.out.println("\n=== B3.1 Ten records inserted three ways: is the table the same as the data that was sent?");
            String[] names = {"Statement", "PreparedStatement", "PreparedStatement + batch"};
            for (int k = 0; k < 3; k++) {
                Db.run(con, "DELETE FROM bus_pass");
                if (k == 0) Loaders.statement(con, ten, false); else if (k == 1) Loaders.prepared(con, ten, false); else Loaders.batch(con, ten, false);
                String got = dump(con);
                System.out.printf("%-28s rows in table: %d, identical to the expected 10 rows: %s%n", names[k], Db.count(con, "bus_pass"), got.equals(expected));
            }
            System.out.println("\nThe ten rows (from the last run):");
            System.out.print(dump(con));
            System.out.println("A name that contains the delimiter and an apostrophe, through Statement (escaped by the program) and PreparedStatement:");
            Db.run(con, "DELETE FROM bus_pass");
            String[] odd = {"P000001", "192311001", "O'Neil, Rahul", "7", "3800.0"};
            Loaders.statement(con, Collections.singletonList(odd), false); try (ResultSet rs = con.createStatement().executeQuery("SELECT name FROM bus_pass")) { rs.next(); System.out.println("  Statement  : stored as [" + rs.getString(1) + "]"); }
            Db.run(con, "DELETE FROM bus_pass"); Loaders.prepared(con, Collections.singletonList(odd), false); try (ResultSet rs = con.createStatement().executeQuery("SELECT name FROM bus_pass")) { rs.next(); System.out.println("  Prepared   : stored as [" + rs.getString(1) + "]"); }

            System.out.println("\n=== Complete the Code: PassLoader.loadAll");
            for (int n : new int[]{1000, 10000, 100000}) {
                Db.run(con, "DELETE FROM bus_pass");
                List<String[]> rows = Loaders.rows(n, 31);
                long t0 = System.nanoTime(); int ins = PassLoader.loadAll(con, rows); double ms = (System.nanoTime() - t0) / 1e6;
                System.out.printf("loadAll(%,d passes) returned %,d; rows in table: %,d; time %.1f ms; autocommit restored to %s%n", n, ins, Db.count(con, "bus_pass"), ms, con.getAutoCommit());
            }

            System.out.println("\n=== Failure half-way: pass number 5,250 of 10,000 has the amount \"abc\"");
            Db.run(con, "DELETE FROM bus_pass");
            List<String[]> bad = Loaders.rows(10000, 31); bad.get(5249)[4] = "abc";
            try { PassLoader.loadAll(con, bad); System.out.println("loadAll returned normally (unexpected)"); }
            catch (Exception e) { System.out.println("loadAll threw " + e.getClass().getSimpleName() + ": " + e.getMessage()); }
            System.out.printf("rows in table after the failed load: %d (the 5,000 rows already sent to the server were rolled back)%n", Db.count(con, "bus_pass"));
            System.out.println("autocommit after the failure: " + con.getAutoCommit() + " (restored in finally)");
            System.out.println("\nSecond failure type, raised by the database itself: the 2nd pass repeats the primary key of the 1st");
            List<String[]> dup = Loaders.rows(3000, 31); dup.get(1)[0] = dup.get(0)[0];
            try { PassLoader.loadAll(con, dup); } catch (Exception e) { System.out.println("loadAll threw " + e.getClass().getSimpleName()); }
            System.out.printf("rows in table after the failed load: %d%n", Db.count(con, "bus_pass"));
        }
    }
}
