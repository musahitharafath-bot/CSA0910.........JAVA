import java.io.PrintWriter;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/** B3.3: the same batch insert with auto-commit on and in one transaction - speed, and what is left in the table after a failure half-way. */
public class CommitModeBench {
    public static void main(String[] args) throws Exception {
        String out = args.length > 0 ? args[0] : "output";
        Files.createDirectories(Path.of(out));
        try (Connection con = Db.connect(); PrintWriter csv = new PrintWriter(out + "/b3_commit_modes.csv")) {
            Db.runScript(con, Path.of("schema.sql"));
            csv.println("rows,mode,mean_ms,sd_ms");
            System.out.println("=== Speed of the same batch insert (1,000 rows per executeBatch)");
            System.out.printf("%-9s %-34s %12s %10s%n", "rows", "mode", "mean ms", "sd");
            for (int n : new int[]{10000, 100000}) {
                List<String[]> rows = Loaders.rows(n, 51);
                for (boolean tx : new boolean[]{false, true}) {
                    int reps = n == 100000 ? 3 : 7; double[] ms = new double[reps];
                    for (int i = -1; i < reps; i++) {
                        Db.run(con, "TRUNCATE TABLE bus_pass");
                        long t0 = System.nanoTime(); Loaders.batch(con, rows, tx); double t = (System.nanoTime() - t0) / 1e6;
                        if (i >= 0) ms[i] = t;
                    }
                    String mode = tx ? "single transaction (commit once)" : "auto-commit on";
                    csv.printf("%d,%s,%.2f,%.2f%n", n, mode, Bench.mean(ms), Bench.stdev(ms));
                    System.out.printf("%-9d %-34s %12.1f %10.1f%n", n, mode, Bench.mean(ms), Bench.stdev(ms));
                }
            }
            System.out.println("\n=== A failure half-way: 100,000 passes, the amount of pass number 50,250 is \"abc\" (the program fails while it prepares that row)");
            List<String[]> bad = Loaders.rows(100000, 51); bad.get(50249)[4] = "abc";
            for (boolean tx : new boolean[]{false, true}) {
                Db.run(con, "TRUNCATE TABLE bus_pass");
                String r;
                try { Loaders.batch(con, bad, tx); r = "no error"; } catch (Exception e) { r = e.getClass().getSimpleName(); }
                String mode = tx ? "single transaction + rollback" : "auto-commit on";
                long left = Db.count(con, "bus_pass");
                String first = "-", last = "-";
                if (left > 0) try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("SELECT MIN(pass_id), MAX(pass_id) FROM bus_pass")) { rs.next(); first = rs.getString(1); last = rs.getString(2); }
                System.out.printf("%-30s error: %-22s rows left in table: %,7d   (first %s, last %s)%n", mode, r, left, first, last);
                csv.printf("failure_halfway,%s,%d,0%n", mode, left);
            }
            System.out.println("\nWith auto-commit on, the 50 batches that were already executed are permanent: the table holds 50,000 of 100,000 passes, with no sign in the table of which ones are missing.");
            System.out.println("To finish the job the program must find out where it stopped and resume, or delete the partial load by hand. With one transaction the table is back to its state before the load.");
            Db.run(con, "TRUNCATE TABLE bus_pass");
        }
    }
}
