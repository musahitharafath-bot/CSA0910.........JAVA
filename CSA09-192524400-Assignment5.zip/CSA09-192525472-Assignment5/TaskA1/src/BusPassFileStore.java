import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** The text-file store designed in Task A1: add, find by pass ID, list by route, with damaged-line handling. */
final class BusPassFileStore {
    record Damaged(int lineNo, String reason, String text) { }

    static final class ScanResult {
        final List<BusPass> passes = new ArrayList<>();
        final List<Damaged> damaged = new ArrayList<>();
        int lines;
    }

    private final Path file;
    BusPassFileStore(Path file) { this.file = file; }

    /** (i) Add: one write() of one complete line to a file opened in APPEND mode. */
    void add(BusPass p, boolean sync) throws IOException {
        String why = PassCodec.validate(p);
        if (why != null) throw new IllegalArgumentException("invalid pass " + p.passId + ": " + why);
        StringBuilder sb = new StringBuilder();
        long size = Files.exists(file) ? Files.size(file) : 0;
        if (size == 0) sb.append(PassCodec.HEADER).append('\n');
        else if (!endsWithNewline(size)) sb.append('\n');                      // isolate a half-written line from a power failure
        sb.append(PassCodec.encode(p)).append('\n');
        ByteBuffer buf = ByteBuffer.wrap(sb.toString().getBytes(StandardCharsets.UTF_8));
        try (FileChannel ch = FileChannel.open(file, StandardOpenOption.CREATE, StandardOpenOption.APPEND, StandardOpenOption.WRITE)) {
            while (buf.hasRemaining()) ch.write(buf);
            if (sync) ch.force(true);                                          // ask the OS to put the bytes on the disk
        }
    }

    private boolean endsWithNewline(long size) throws IOException {
        try (FileChannel ch = FileChannel.open(file, StandardOpenOption.READ)) {
            ByteBuffer b = ByteBuffer.allocate(1); ch.read(b, size - 1); return b.get(0) == '\n';
        }
    }

    private BufferedReader open() throws IOException {
        // InputStreamReader replaces illegal bytes instead of throwing, so one bad byte cannot stop the whole scan.
        return new BufferedReader(new InputStreamReader(Files.newInputStream(file), StandardCharsets.UTF_8));
    }

    /** (ii) Find by pass ID: sequential scan, damaged lines skipped, stops at the first valid match. */
    Optional<BusPass> find(String passId) throws IOException {
        if (!Files.exists(file)) return Optional.empty();
        try (BufferedReader r = open()) {
            String line;
            while ((line = r.readLine()) != null) {
                if (line.startsWith("#")) continue;
                if (!line.startsWith(passId + ",") && !line.startsWith("\"" + passId + "\",")) continue;   // cheap pre-check
                PassCodec.Result res = PassCodec.decode(line);
                if (res.ok() && res.pass().passId.equals(passId)) return Optional.of(res.pass());
            }
        }
        return Optional.empty();
    }

    /** (iii) List all passes of one route. */
    List<BusPass> listByRoute(int route) throws IOException {
        List<BusPass> out = new ArrayList<>();
        if (!Files.exists(file)) return out;
        try (BufferedReader r = open()) {
            String line;
            while ((line = r.readLine()) != null) {
                if (line.startsWith("#")) continue;
                PassCodec.Result res = PassCodec.decode(line);
                if (res.ok() && res.pass().route == route) out.add(res.pass());
            }
        }
        return out;
    }

    /** Reads the whole file and reports every valid pass and every damaged line (with its line number and reason). */
    ScanResult scanAll() throws IOException {
        ScanResult s = new ScanResult();
        if (!Files.exists(file)) return s;
        try (BufferedReader r = open()) {
            String line; int no = 0;
            while ((line = r.readLine()) != null) {
                no++; s.lines++;
                if (line.startsWith("#")) continue;
                PassCodec.Result res = PassCodec.decode(line);
                if (res.ok()) s.passes.add(res.pass()); else s.damaged.add(new Damaged(no, res.error(), line));
            }
        }
        return s;
    }
}
