import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;

/**
 * Task A1 - the three record layouts side by side:
 *   TEXT   : delimited text with quoting and a CRC (the design of A1.1 a)
 *   BINARY : DataOutputStream, variable length, strings with a 2-byte length (A1.1 b)
 *   FIXED  : RandomAccessFile with fixed-length records (the alternative concept of A1)
 * Measures file size, wasted padding and the time to find one pass by ID.
 */
public class RecordLayouts {
    static final int REC = 96;                       // fixed record size in bytes
    // FIXED layout: passId 8 | regNo 12 | name 40 | route 2 | stop 24 | validUntil(epoch day) 4 | amount (paise) 4  = 94, padded to 96

    static void putStr(ByteBuffer b, String s, int width) {
        byte[] x = s.getBytes(StandardCharsets.UTF_8);
        if (x.length > width) x = Arrays.copyOf(x, width);          // too long: cut (a weakness of fixed records)
        b.put(x); for (int i = x.length; i < width; i++) b.put((byte) 0);
    }
    static String getStr(ByteBuffer b, int width) {
        byte[] x = new byte[width]; b.get(x); int n = 0; while (n < width && x[n] != 0) n++;
        return new String(x, 0, n, StandardCharsets.UTF_8);
    }
    static byte[] fixed(BusPass p) {
        ByteBuffer b = ByteBuffer.allocate(REC);
        putStr(b, p.passId, 8); putStr(b, p.regNo, 12); putStr(b, p.name, 40); b.putShort((short) p.route); putStr(b, p.stop, 24);
        b.putInt((int) p.validUntil.toEpochDay()); b.putInt((int) Math.round(p.amount * 100)); return b.array();
    }
    static BusPass unfixed(byte[] r) {
        ByteBuffer b = ByteBuffer.wrap(r); String id = getStr(b, 8), reg = getStr(b, 12), name = getStr(b, 40); int route = b.getShort(); String stop = getStr(b, 24);
        LocalDate d = LocalDate.ofEpochDay(b.getInt()); double amt = b.getInt() / 100.0; return new BusPass(id, reg, name, route, stop, d, amt);
    }
    static void writeBinary(DataOutputStream o, BusPass p) throws IOException {
        o.writeUTF(p.passId); o.writeUTF(p.regNo); o.writeUTF(p.name); o.writeShort(p.route); o.writeUTF(p.stop);
        o.writeInt((int) p.validUntil.toEpochDay()); o.writeInt((int) Math.round(p.amount * 100));
    }
    static BusPass readBinary(DataInputStream in) throws IOException {
        String id = in.readUTF(), reg = in.readUTF(), name = in.readUTF(); int route = in.readShort(); String stop = in.readUTF();
        LocalDate d = LocalDate.ofEpochDay(in.readInt()); double amt = in.readInt() / 100.0; return new BusPass(id, reg, name, route, stop, d, amt);
    }

    static String findBinaryScan(Path f, String id) throws IOException {                    // sequential scan of variable-length records
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(f), 1 << 16))) {
            while (true) { BusPass p = readBinary(in); if (p.passId.equals(id)) return p.name; }
        } catch (EOFException e) { return null; }
    }
    static String findFixedSeek(RandomAccessFile raf, int number) throws IOException {      // O(1): IDs are P000001, P000002 ... so record i = number - 1
        byte[] r = new byte[REC]; raf.seek((long) (number - 1) * REC); raf.readFully(r); return unfixed(r).name;
    }
    static String findFixedBinarySearch(RandomAccessFile raf, String id, long n) throws IOException {   // O(log n): IDs sorted, no arithmetic assumption
        long lo = 0, hi = n - 1; byte[] r = new byte[REC];
        while (lo <= hi) {
            long mid = (lo + hi) >>> 1; raf.seek(mid * REC); raf.readFully(r); BusPass p = unfixed(r); int c = p.passId.compareTo(id);
            if (c == 0) return p.name; if (c < 0) lo = mid + 1; else hi = mid - 1;
        }
        return null;
    }

    public static void main(String[] args) throws Exception {
        String out = args.length > 0 ? args[0] : "output";
        Files.createDirectories(Path.of(out));
        // ---- A1.1: how a name containing the delimiter is handled in each layout
        BusPass odd = new BusPass("P000042", "192311042", "Raman, Meena \"Mini\"", 12, "Tambaram", LocalDate.of(2027, 3, 31), 4500);
        System.out.println("=== A1.1 A name that contains the delimiter and a quote: Raman, Meena \"Mini\"");
        String line = PassCodec.encode(odd);
        System.out.println("TEXT   line     : " + line);
        System.out.println("TEXT   decoded  : " + PassCodec.decode(line).pass().name + "   (round trip " + PassCodec.decode(line).pass().name.equals(odd.name) + ")");
        ByteArrayOutputStream bo = new ByteArrayOutputStream(); writeBinary(new DataOutputStream(bo), odd);
        System.out.println("BINARY bytes    : " + bo.size() + " (name stored as 2-byte length + " + odd.name.getBytes(StandardCharsets.UTF_8).length + " bytes: no delimiter exists, so nothing to escape)");
        System.out.println("BINARY decoded  : " + readBinary(new DataInputStream(new ByteArrayInputStream(bo.toByteArray()))).name);
        System.out.println("FIXED  decoded  : " + unfixed(fixed(odd)).name + "   (name field is 40 bytes; a longer name would be cut)");
        BusPass longName = new BusPass("P000043", "192311043", "A".repeat(55), 1, "X", LocalDate.of(2027, 1, 1), 100);
        System.out.println("FIXED  55-char name stored as " + unfixed(fixed(longName)).name.length() + " characters -> data loss");

        System.out.println("\n=== Size, wasted space and time to find one pass by ID");
        System.out.printf("%-9s %-34s %12s %10s %12s %14s%n", "records", "layout", "file bytes", "bytes/rec", "waste %", "find ms (avg)");
        try (PrintWriter csv = new PrintWriter(out + "/a1_layouts.csv")) {
            csv.println("records,layout,file_bytes,bytes_per_record,padding_waste_percent,find_avg_ms,find_sd_ms,finds_timed");
            for (int n : new int[]{8000, 100000}) {
                List<BusPass> passes = DataGen.passes(n, 5);
                Path tf = Files.createTempFile("a1t", ".txt"), bf = Files.createTempFile("a1b", ".bin"), ff = Files.createTempFile("a1f", ".dat");
                long useful = 0;
                try (BufferedWriter w = Files.newBufferedWriter(tf); DataOutputStream o = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(bf)));
                     RandomAccessFile raf = new RandomAccessFile(ff.toFile(), "rw")) {
                    w.write(PassCodec.HEADER + "\n");
                    for (BusPass p : passes) {
                        w.write(PassCodec.encode(p)); w.write('\n'); writeBinary(o, p); raf.write(fixed(p));
                        useful += p.passId.length() + p.regNo.length() + p.name.getBytes(StandardCharsets.UTF_8).length + p.stop.length() + 2 + 4 + 4;
                    }
                }
                BusPassFileStore store = new BusPassFileStore(tf);
                Random r = new Random(9);
                int scans = n <= 8000 ? 100 : 40, seeks = 4000;
                int[] ids = new int[Math.max(scans, seeks)]; for (int i = 0; i < ids.length; i++) ids[i] = 1 + r.nextInt(n);
                for (int i = 0; i < 5; i++) { store.find(String.format("P%06d", ids[i])); findBinaryScan(bf, String.format("P%06d", ids[i])); }       // warm-up
                double[] tt = new double[scans], tb = new double[scans], ts = new double[seeks], tbs = new double[seeks];
                for (int i = 0; i < scans; i++) { String id = String.format("P%06d", ids[i]); long a = System.nanoTime(); Bench.sink += store.find(id).isPresent() ? 1 : 0; tt[i] = System.nanoTime() - a;
                    a = System.nanoTime(); Bench.sink += findBinaryScan(bf, id) != null ? 1 : 0; tb[i] = System.nanoTime() - a; }
                try (RandomAccessFile raf = new RandomAccessFile(ff.toFile(), "r")) {
                    for (int i = 0; i < 500; i++) { findFixedSeek(raf, ids[i]); findFixedBinarySearch(raf, String.format("P%06d", ids[i]), n); }
                    for (int i = 0; i < seeks; i++) { long a = System.nanoTime(); Bench.sink += findFixedSeek(raf, ids[i]).length(); ts[i] = System.nanoTime() - a;
                        String id = String.format("P%06d", ids[i]); a = System.nanoTime(); Bench.sink += findFixedBinarySearch(raf, id, n).length(); tbs[i] = System.nanoTime() - a; }
                }
                Object[][] rows = {
                    {"TEXT (delimited, CRC) - scan", Files.size(tf), tt, scans, 0.0},
                    {"BINARY (DataOutputStream) - scan", Files.size(bf), tb, scans, 0.0},
                    {"FIXED (RandomAccessFile) - seek i x size", Files.size(ff), ts, seeks, 100.0 * (1 - useful / (double) Files.size(ff))},
                    {"FIXED (RandomAccessFile) - binary search", Files.size(ff), tbs, seeks, 100.0 * (1 - useful / (double) Files.size(ff))}};
                for (Object[] row : rows) {
                    long size = (Long) row[1]; double[] t = (double[]) row[2];
                    csv.printf("%d,\"%s\",%d,%.1f,%.1f,%.5f,%.5f,%d%n", n, row[0], size, size / (double) n, (Double) row[4], Bench.mean(t) / 1e6, Bench.stdev(t) / 1e6, (Integer) row[3]);
                    System.out.printf("%-9d %-42s %12d %10.1f %12.1f %14.5f%n", n, row[0], size, size / (double) n, (Double) row[4], Bench.mean(t) / 1e6);
                }
                System.out.println();
                Files.delete(tf); Files.delete(bf); Files.delete(ff);
            }
        }
    }
}
