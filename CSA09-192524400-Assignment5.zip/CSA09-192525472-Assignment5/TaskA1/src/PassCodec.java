import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.CRC32;

/**
 * Text layout of Task A1 (design a):
 *   passId,regNo,name,route,stop,validUntil,amount,crc32
 * Fields containing a comma or a double quote are written in double quotes, with every inner quote doubled (RFC 4180).
 * crc32 is the CRC-32 (8 hex digits) of the text of the first seven fields; a damaged or half-written line fails it.
 */
final class PassCodec {
    static final String HEADER = "#BUSPASS v1 passId,regNo,name,route,stop,validUntil,amount,crc32";

    /** Result of decoding one line: either a pass or the reason why the line is damaged. */
    record Result(BusPass pass, String error) { boolean ok() { return pass != null; } }

    static String crc(String s) {
        CRC32 c = new CRC32(); c.update(s.getBytes(StandardCharsets.UTF_8));
        return String.format("%08x", c.getValue());
    }

    static String quote(String f) {
        f = f.replace('\r', ' ').replace('\n', ' ');
        return (f.indexOf(',') >= 0 || f.indexOf('"') >= 0) ? '"' + f.replace("\"", "\"\"") + '"' : f;
    }

    /** Returns null when the pass is acceptable, otherwise the reason it is not. */
    static String validate(BusPass p) {
        if (p.passId == null || !p.passId.matches("P\\d{4,8}")) return "pass ID must look like P000123";
        if (p.regNo == null || !p.regNo.matches("\\d{6,12}")) return "register number must be 6-12 digits";
        if (p.name == null || p.name.isBlank() || p.name.length() > 60) return "name is empty or longer than 60 characters";
        if (p.route < 1 || p.route > 999) return "route number must be 1-999";
        if (p.stop == null || p.stop.isBlank()) return "boarding stop is empty";
        if (p.validUntil == null) return "validity date is missing";
        if (!(p.amount > 0 && p.amount <= 100000)) return "amount must be above 0 and at most 100000";
        return null;
    }

    static String encode(BusPass p) {
        String body = String.join(",", quote(p.passId), quote(p.regNo), quote(p.name), String.valueOf(p.route),
                quote(p.stop), p.validUntil.toString(), String.format(Locale.ROOT, "%.2f", p.amount));
        return body + "," + crc(body);
    }

    /** Splits one line into fields; returns null if a quote is not closed or is misplaced. */
    static List<String> split(String line) {
        List<String> out = new ArrayList<>(); StringBuilder cur = new StringBuilder();
        int i = 0, n = line.length();
        while (true) {
            cur.setLength(0);
            if (i < n && line.charAt(i) == '"') {
                i++;
                while (true) {
                    if (i >= n) return null;                                   // quote never closed
                    char c = line.charAt(i++);
                    if (c == '"') { if (i < n && line.charAt(i) == '"') { cur.append('"'); i++; } else break; }
                    else cur.append(c);
                }
                if (i < n && line.charAt(i) != ',') return null;               // text after the closing quote
            } else {
                while (i < n && line.charAt(i) != ',') { if (line.charAt(i) == '"') return null; cur.append(line.charAt(i++)); }
            }
            out.add(cur.toString());
            if (i >= n) break;
            i++;                                                               // skip the comma
        }
        return out;
    }

    static Result decode(String line) {
        if (line.isEmpty()) return new Result(null, "empty line");
        List<String> f = split(line);
        if (f == null) return new Result(null, "unbalanced quote");
        if (f.size() != 8) return new Result(null, "expected 8 fields but found " + f.size());
        int lastComma = line.lastIndexOf(',');
        if (!crc(line.substring(0, lastComma)).equals(f.get(7))) return new Result(null, "checksum mismatch (damaged or incomplete line)");
        int route; double amount; LocalDate date;
        try { route = Integer.parseInt(f.get(3)); } catch (NumberFormatException e) { return new Result(null, "route is not a number: '" + f.get(3) + "'"); }
        try { amount = Double.parseDouble(f.get(6)); } catch (NumberFormatException e) { return new Result(null, "amount is not a number: '" + f.get(6) + "'"); }
        try { date = LocalDate.parse(f.get(5)); } catch (DateTimeParseException e) { return new Result(null, "validity date is not a date: '" + f.get(5) + "'"); }
        BusPass p = new BusPass(f.get(0), f.get(1), f.get(2), route, f.get(4), date, amount);
        String why = validate(p);
        return why == null ? new Result(p, null) : new Result(null, why);
    }
}
