import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;

/** Deterministic test data: bus passes (objects or a file) and a text "attendance log" of a chosen size. */
final class DataGen {
    static final String[] FIRST = {"Arun", "Divya", "Karthik", "Meena", "Rahul", "Priya", "Suresh", "Anitha", "Vikram", "Lakshmi", "Imran", "Farah", "Naveen", "Deepa", "Hari"};
    static final String[] LAST = {"Kumar", "Raman", "Iyer", "Nair", "Reddy", "Sharma", "Hussain", "Das", "Pillai", "Menon"};
    static final String[] STOPS = {"Tambaram", "Guindy", "Velachery", "Adyar", "T Nagar", "Porur", "Poonamallee", "Avadi", "Anna Nagar", "Koyambedu",
            "Perungalathur", "Chromepet", "Pallavaram", "Sholinganallur", "Medavakkam", "Ambattur", "Thirumazhisai", "Kundrathur", "Mangadu", "Saidapet"};

    static BusPass make(int i, Random r) {
        String name = FIRST[r.nextInt(FIRST.length)] + " " + LAST[r.nextInt(LAST.length)];
        if (i % 97 == 0) name = LAST[r.nextInt(LAST.length)] + ", " + FIRST[r.nextInt(FIRST.length)];      // a name that contains the delimiter
        int route = 1 + r.nextInt(40);
        return new BusPass(String.format("P%06d", i), String.format("1923%05d", r.nextInt(100000)), name, route, STOPS[r.nextInt(STOPS.length)],
                LocalDate.of(2026, 6, 1).plusDays(r.nextInt(365)), 3500 + route * 25 + r.nextInt(5) * 100);
    }

    static List<BusPass> passes(int n, long seed) {
        Random r = new Random(seed); List<BusPass> l = new ArrayList<>(n);
        for (int i = 1; i <= n; i++) l.add(make(i, r));
        return l;
    }

    /** Writes n passes straight to a store file (much faster than n calls of add()). */
    static void writeStoreFile(Path f, int n, long seed) throws IOException {
        Random r = new Random(seed);
        try (BufferedWriter w = Files.newBufferedWriter(f, StandardCharsets.UTF_8)) {
            w.write(PassCodec.HEADER); w.write('\n');
            for (int i = 1; i <= n; i++) { w.write(PassCodec.encode(make(i, r))); w.write('\n'); }
        }
    }

    /** A text attendance log of about the requested size (lines of 40-90 characters). Returns the number of lines. */
    static long writeLog(Path f, long bytes, long seed) throws IOException {
        Random r = new Random(seed); long written = 0, lines = 0;
        try (OutputStream os = new BufferedOutputStream(Files.newOutputStream(f), 1 << 16)) {
            while (written < bytes) {
                String s = String.format("2026-%02d-%02d %02d:%02d,Gate%d,1923%05d,%s %s%s", 1 + r.nextInt(12), 1 + r.nextInt(28), r.nextInt(24), r.nextInt(60),
                        1 + r.nextInt(4), r.nextInt(100000), FIRST[r.nextInt(FIRST.length)], LAST[r.nextInt(LAST.length)], "x".repeat(r.nextInt(30)));
                byte[] b = (s + "\n").getBytes(StandardCharsets.UTF_8);
                if (written + b.length > bytes) {                       // finish exactly on the requested size with a short last line
                    int rest = (int) (bytes - written);
                    byte[] t = new byte[rest]; Arrays.fill(t, (byte) 'z'); t[rest - 1] = '\n'; os.write(t); written += rest; lines++; break;
                }
                os.write(b); written += b.length; lines++;
            }
        }
        return lines;
    }
}
