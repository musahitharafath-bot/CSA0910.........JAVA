import java.time.LocalDate;

/** One bus-pass record (the seven fields of Task A1). */
final class BusPass implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    final String passId, regNo, name, stop;
    final int route;
    final LocalDate validUntil;
    final double amount;

    BusPass(String passId, String regNo, String name, int route, String stop, LocalDate validUntil, double amount) {
        this.passId = passId; this.regNo = regNo; this.name = name; this.route = route;
        this.stop = stop; this.validUntil = validUntil; this.amount = amount;
    }

    @Override public String toString() {
        return passId + " | " + regNo + " | " + name + " | route " + route + " | " + stop + " | " + validUntil + " | Rs " + String.format("%.2f", amount);
    }
}
