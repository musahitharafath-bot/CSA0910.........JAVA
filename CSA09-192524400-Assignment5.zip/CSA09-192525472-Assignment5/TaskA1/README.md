# TaskA1 - Assignment 5 (CO5), Programming in Java

**Student:** Syed Aakif Hussain S A  |  **Register number:** 192525472

Record layouts for the bus-pass file (text vs binary vs fixed-length), with pseudocode, prediction and measured find times.

## Environment
- Compiled and run with Java 21.0.12.1
- No database needed.
- Test database for the reported results: MariaDB 10.11 with MariaDB Connector/J (MySQL-compatible). Edit `../db.properties` to use your own MySQL.

## Folder contents
- `src/` - Java source code
- `output/` - program output (`*_output.txt`), console screenshots (`*_console.png`), CSV data and charts
- `run.sh` - compiles and runs everything in this task

## How to run
```
sh run.sh
```
Or by hand: `javac -cp "../lib/*" -d out src/*.java` then `java -cp "out:../lib/*" <MainClass> output`.

## Programs and results
- `RecordLayouts` -> `output/RecordLayouts_output.txt` and `output/RecordLayouts_console.png`

Data files and charts written to `output/`: `a1_layouts.csv`, `chart_a1_layouts.png`.

Timings are from a shared 2-vCPU machine and vary by run. Compare ratios and trends, not single numbers.
