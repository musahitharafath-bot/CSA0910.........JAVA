#!/bin/sh
# Compile and run TaskA1
cd "$(dirname "$0")"
mkdir -p out output
javac -cp "../lib/*" -d out src/*.java
java -cp "out:../lib/*" RecordLayouts output | tee output/RecordLayouts_output.txt
rm -rf out
