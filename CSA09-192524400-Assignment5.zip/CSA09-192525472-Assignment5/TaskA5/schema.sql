-- Task A5: two wallets (test database only). The CHECK stops a balance from becoming negative.
DROP TABLE IF EXISTS wallet;
CREATE TABLE wallet (
    owner   VARCHAR(20)   NOT NULL PRIMARY KEY,
    balance DECIMAL(10,2) NOT NULL,
    CONSTRAINT balance_not_negative CHECK (balance >= 0)
) ENGINE=InnoDB;
