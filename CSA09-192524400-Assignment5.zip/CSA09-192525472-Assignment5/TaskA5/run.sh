#!/bin/sh
# Compile and run TaskA5
cd "$(dirname "$0")"
mkdir -p out output
javac -cp "../lib/*" -d out src/*.java
java -cp "out:../lib/*" WalletDemo output | tee output/WalletDemo_output.txt
rm -rf out
