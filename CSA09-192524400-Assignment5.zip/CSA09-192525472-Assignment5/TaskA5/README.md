# TaskA5 - Assignment 5 (CO5), Programming in Java

**Student:** Syed Aakif Hussain S A  |  **Register number:** 192525472

Transactions and SQL injection: wallet transfer with commit/rollback, and what a failed second statement leaves behind.

## Environment
- Compiled and run with Java 21.0.12.1
- Needs the database.
- Test database for the reported results: MariaDB 10.11 with MariaDB Connector/J (MySQL-compatible). Edit `../db.properties` to use your own MySQL.

## Folder contents
- `src/` - Java source code
- `output/` - program output (`*_output.txt`), console screenshots (`*_console.png`), CSV data and charts
- `schema.sql` - table definitions the programs create
- `run.sh` - compiles and runs everything in this task

## How to run
```
sh run.sh
```
Or by hand: `javac -cp "../lib/*" -d out src/*.java` then `java -cp "out:../lib/*" <MainClass> output`.

## Programs and results
- `WalletDemo` -> `output/WalletDemo_output.txt` and `output/WalletDemo_console.png`

Data files and charts written to `output/`: `a5_cost.csv`.

Timings are from a shared 2-vCPU machine and vary by run. Compare ratios and trends, not single numbers.
