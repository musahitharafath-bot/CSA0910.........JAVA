import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.*;
import java.sql.*;

/** A5.1 and its alternative: moving Rs 500 from the hostel wallet to the canteen wallet. */
public class WalletDemo {
    static class SimulatedCrash extends RuntimeException { SimulatedCrash(String m) { super(m); } }

    static void reset(Connection con, int hostel, int canteen) throws SQLException {
        Db.run(con, "DELETE FROM wallet");
        Db.run(con, "INSERT INTO wallet VALUES ('hostel', " + hostel + "), ('canteen', " + canteen + ")");
    }
    static String balances(Connection con) throws SQLException {
        try (Statement s = con.createStatement(); ResultSet rs = s.executeQuery("SELECT owner, balance FROM wallet ORDER BY owner")) {
            BigDecimal total = BigDecimal.ZERO; StringBuilder sb = new StringBuilder();
            while (rs.next()) { sb.append(rs.getString(1)).append("=").append(rs.getBigDecimal(2).setScale(0)).append("  "); total = total.add(rs.getBigDecimal(2)); }
            return sb + "TOTAL=" + total.setScale(0);
        }
    }
    static int debit(Connection con, String owner, int amt, int sign) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement("UPDATE wallet SET balance = balance + ? WHERE owner = ?")) { ps.setInt(1, sign * amt); ps.setString(2, owner); return ps.executeUpdate(); }
    }

    /** The design of A5.1: both updates inside one transaction. crashAfterFirst simulates the program failing between them. */
    static void transfer(Connection con, String from, String to, int amt, boolean crashAfterFirst) throws SQLException {
        boolean old = con.getAutoCommit();
        con.setAutoCommit(false);                                   // 1. start a transaction
        try {
            if (debit(con, from, amt, -1) != 1) throw new SQLException("unknown wallet " + from);   // 2. take the money out
            if (crashAfterFirst) throw new SimulatedCrash("power failure / exception between the two updates");
            if (debit(con, to, amt, +1) != 1) throw new SQLException("unknown wallet " + to);       // 3. put the money in
            con.commit();                                           // 4. both updates become permanent together
        } catch (SQLException | RuntimeException e) {
            con.rollback();                                         // 5. any failure: undo everything done so far
            throw e;
        } finally { con.setAutoCommit(old); }
    }

    /** The alternative: two separate auto-commit statements. */
    static void transferAutoCommit(Connection con, String from, String to, int amt, boolean crashAfterFirst) throws SQLException {
        con.setAutoCommit(true);
        debit(con, from, amt, -1);                                  // committed immediately
        if (crashAfterFirst) throw new SimulatedCrash("power failure / exception between the two updates");
        debit(con, to, amt, +1);
    }

    interface Action { void run() throws Exception; }
    static String attempt(Action a) {
        try { a.run(); return "completed"; }
        catch (SimulatedCrash e) { return "program failed: crash between the updates"; }
        catch (SQLException e) { return "program failed: " + (String.valueOf(e.getMessage()).contains("balance_not_negative") ? "CHECK balance_not_negative violated" : e.getMessage()); }
        catch (Exception e) { return "program failed: " + e; }
    }

    public static void main(String[] args) throws Exception {
        String out = args.length > 0 ? args[0] : "output";
        Files.createDirectories(Path.of(out));
        try (Connection con = Db.connect()) {
            Db.runScript(con, Path.of("schema.sql"));
            System.out.println("Engine/isolation: " + con.getMetaData().getDatabaseProductName() + " " + con.getMetaData().getDatabaseProductVersion() + ", default isolation level " + (con.getTransactionIsolation() == Connection.TRANSACTION_REPEATABLE_READ ? "REPEATABLE READ" : con.getTransactionIsolation()));
            System.out.println("\nScenario                                              outcome of the program                                            balances afterwards");
            reset(con, 1000, 200); System.out.println("start (before any transfer)                           -                                                                 " + balances(con));
            reset(con, 1000, 200); String r1 = attempt(() -> transfer(con, "hostel", "canteen", 500, false));
            System.out.printf("1 transaction, no failure                             %-66s%s%n", r1, balances(con));
            reset(con, 1000, 200); String r2 = attempt(() -> transfer(con, "hostel", "canteen", 500, true));
            System.out.printf("2 transaction, failure between the updates            %-66s%s%n", r2, balances(con));
            reset(con, 1000, 200); String r3 = attempt(() -> transferAutoCommit(con, "hostel", "canteen", 500, true));
            System.out.printf("3 two auto-commit updates, failure between them       %-66s%s%n", r3, balances(con));
            reset(con, 300, 200); String r4 = attempt(() -> transfer(con, "hostel", "canteen", 500, false));
            System.out.printf("4 transaction, hostel has only Rs 300                 %-66s%s%n", r4, balances(con));
            reset(con, 300, 200); String r5 = attempt(() -> transferAutoCommit(con, "hostel", "canteen", 500, false));
            System.out.printf("5 auto-commit, hostel has only Rs 300                 %-66s%s%n", r5, balances(con));
            System.out.println("(in 4 and 5 the CHECK constraint rejects the debit, so nothing is changed; scenario 3 is the dangerous one: Rs 500 has disappeared)");

            // ---- time cost: transaction (2 updates + 1 commit) versus two auto-commit statements
            System.out.println("\n=== Time cost per transfer (Rs 1 moved back and forth, 5 repetitions after 2 warm-ups)");
            int N = 1000;
            Runnable tx = () -> { try { for (int i = 0; i < N; i++) transfer(con, "hostel", "canteen", 1, false); } catch (SQLException e) { throw new RuntimeException(e); } };
            Runnable ac = () -> { try { for (int i = 0; i < N; i++) transferAutoCommit(con, "hostel", "canteen", 1, false); } catch (SQLException e) { throw new RuntimeException(e); } };
            reset(con, 100000, 0);
            double[] a = Bench.measure(tx, 2, 5); reset(con, 100000, 0); double[] b = Bench.measure(ac, 2, 5);
            try (Statement s = con.createStatement(); ResultSet rs = s.executeQuery("SELECT @@innodb_flush_log_at_trx_commit")) { rs.next(); System.out.println("innodb_flush_log_at_trx_commit = " + rs.getString(1) + " (1 = the log is flushed to disk at every commit)"); }
            System.out.printf("transaction (2 updates, 1 commit):        %8.1f ms per %d transfers (sd %.1f) = %.1f us per transfer%n", Bench.mean(a) / 1e6, N, Bench.stdev(a) / 1e6, Bench.mean(a) / N / 1e3);
            System.out.printf("two auto-commit updates (2 commits):      %8.1f ms per %d transfers (sd %.1f) = %.1f us per transfer%n", Bench.mean(b) / 1e6, N, Bench.stdev(b) / 1e6, Bench.mean(b) / N / 1e3);
            try (PrintWriter csv = new PrintWriter(out + "/a5_cost.csv")) {
                csv.println("method,transfers,mean_ms,sd_ms,us_per_transfer"); csv.printf("transaction,%d,%.2f,%.2f,%.1f%n", N, Bench.mean(a) / 1e6, Bench.stdev(a) / 1e6, Bench.mean(a) / N / 1e3);
                csv.printf("two auto-commit statements,%d,%.2f,%.2f,%.1f%n", N, Bench.mean(b) / 1e6, Bench.stdev(b) / 1e6, Bench.mean(b) / N / 1e3);
            }
            Db.run(con, "DROP TABLE wallet");
        }
    }
}
