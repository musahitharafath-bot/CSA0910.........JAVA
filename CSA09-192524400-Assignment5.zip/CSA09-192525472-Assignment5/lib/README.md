# lib/ - JDBC driver and helper jars
- `mariadb-java-client.jar` - MariaDB Connector/J 2.7.6. It talks to MariaDB and to MySQL servers. Used for the test run in this repository.
- `gson.jar` - Gson 2.10.1, used only by TaskA4 to compare JSON with Java serialization.

To use Oracle's driver instead: download `mysql-connector-j-8.x.jar` from https://dev.mysql.com/downloads/connector/j/ , put it in this folder,
and change the lines in `../db.properties` (an example is given in the comments there).
With MySQL Connector/J, batching only becomes a real multi-row insert when `rewriteBatchedStatements=true` is added to the URL.
