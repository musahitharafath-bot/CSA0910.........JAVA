import java.nio.file.*;
import java.sql.*;

/** B4.2: what DatabaseMetaData tells the program about the database, driver and table - and why that matters before a migration. */
public class InspectDb {
    public static void main(String[] args) throws Exception {
        try (Connection con = Db.connect()) {
            Db.runScript(con, Path.of("schema.sql"));
            DatabaseMetaData m = con.getMetaData();
            System.out.println("=== Product and driver");
            System.out.println("Database product        : " + m.getDatabaseProductName() + " " + m.getDatabaseProductVersion());
            System.out.println("Driver                  : " + m.getDriverName() + " " + m.getDriverVersion() + " (JDBC " + m.getJDBCMajorVersion() + "." + m.getJDBCMinorVersion() + ")");
            System.out.println("Connected as / catalog  : " + m.getUserName() + " / " + con.getCatalog());
            System.out.println("\n=== Capabilities the migration relies on");
            System.out.println("supportsTransactions    : " + m.supportsTransactions());
            System.out.println("supportsBatchUpdates    : " + m.supportsBatchUpdates());
            System.out.println("default isolation level : " + m.getDefaultTransactionIsolation() + " (4 = REPEATABLE READ)");
            System.out.println("supports REPEATABLE READ: " + m.supportsTransactionIsolationLevel(Connection.TRANSACTION_REPEATABLE_READ));
            System.out.println("max connections         : " + m.getMaxConnections() + " (0 = no limit reported)");
            System.out.println("max column name length  : " + m.getMaxColumnNameLength());
            System.out.println("identifier quote string : [" + m.getIdentifierQuoteString() + "]");
            System.out.println("\n=== Tables in the schema");
            try (ResultSet rs = m.getTables(con.getCatalog(), null, "%", new String[]{"TABLE"})) { while (rs.next()) System.out.println("table: " + rs.getString("TABLE_NAME")); }
            System.out.println("\n=== Columns of bus_pass");
            System.out.printf("%-14s %-10s %6s %-9s%n", "column", "type", "size", "nullable");
            try (ResultSet rs = m.getColumns(con.getCatalog(), null, "bus_pass", "%")) { while (rs.next()) System.out.printf("%-14s %-10s %6d %-9s%n", rs.getString("COLUMN_NAME"), rs.getString("TYPE_NAME"), rs.getInt("COLUMN_SIZE"), rs.getString("IS_NULLABLE").equals("NO") ? "NOT NULL" : "NULL"); }
            System.out.println("\n=== Primary key and indexes of bus_pass");
            try (ResultSet rs = m.getPrimaryKeys(con.getCatalog(), null, "bus_pass")) { while (rs.next()) System.out.println("primary key column: " + rs.getString("COLUMN_NAME")); }
            try (ResultSet rs = m.getIndexInfo(con.getCatalog(), null, "bus_pass", false, false)) { while (rs.next()) System.out.println("index " + rs.getString("INDEX_NAME") + " on " + rs.getString("COLUMN_NAME") + " (unique: " + !rs.getBoolean("NON_UNIQUE") + ")"); }
        }
    }
}
