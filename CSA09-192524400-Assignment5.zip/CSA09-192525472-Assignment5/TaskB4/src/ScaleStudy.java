import java.io.*;
import java.math.BigDecimal;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/**
 * B4.3: the number of passes grows 100 times (8,000 a year x 100 = 800,000).
 * How do the text file, Java serialization (one file, or twelve campus files) and the database cope?
 */
public class ScaleStudy {
    static final int N = 800_000, CAMPUSES = 12;
    static String id(int i) { return String.format("P%06d", i); }
    static double ms(long t0) { return (System.nanoTime() - t0) / 1e6; }
    static <T> T timed(String what, java.util.concurrent.Callable<T> c, double[] ms) throws Exception { long t0 = System.nanoTime(); T r = c.call(); ms[0] = ms(t0); System.out.printf("  %-58s %10.0f ms%n", what, ms[0]); return r; }

    @SuppressWarnings("unchecked")
    static List<BusPass> readSer(Path f) throws Exception { try (ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(Files.newInputStream(f), 1 << 16))) { return (List<BusPass>) in.readObject(); } }
    static void writeSer(List<BusPass> l, Path f) throws IOException { try (ObjectOutputStream o = new ObjectOutputStream(new BufferedOutputStream(Files.newOutputStream(f), 1 << 16))) { o.writeObject(l); } }

    public static void main(String[] args) throws Exception {
        String out = args.length > 0 ? args[0] : "output"; Files.createDirectories(Path.of(out));
        try (PrintWriter csv = new PrintWriter(out + "/b4_scale.csv"); Connection con = Db.connect()) {
            csv.println("measure,design,value,unit");
            Random rnd = new Random(8); int[] probe = new int[2000]; for (int i = 0; i < probe.length; i++) probe[i] = 1 + rnd.nextInt(N);
            double[] t = new double[1];
            Path text = Files.createTempFile("scale", ".txt"), ser = Files.createTempFile("scale", ".ser");
            Path[] campus = new Path[CAMPUSES]; for (int i = 0; i < CAMPUSES; i++) campus[i] = Files.createTempFile("campus" + i, ".ser");

            System.out.println("=== Creating " + String.format("%,d", N) + " passes");
            List<BusPass> all = timed("generate objects", () -> DataGen.passes(N, 5), t);
            timed("write text store file", () -> { DataGen.writeStoreFile(text, N, 5); return 0; }, t); csv.printf("write,text file,%.0f,ms%n", t[0]);
            timed("write one serialized file", () -> { writeSer(all, ser); return 0; }, t); csv.printf("write,serialized (one file),%.0f,ms%n", t[0]);
            List<List<BusPass>> parts = new ArrayList<>(); for (int i = 0; i < CAMPUSES; i++) parts.add(new ArrayList<>());
            for (int i = 0; i < all.size(); i++) parts.get(i % CAMPUSES).add(all.get(i));
            timed("write 12 serialized campus files", () -> { for (int i = 0; i < CAMPUSES; i++) writeSer(parts.get(i), campus[i]); return 0; }, t); csv.printf("write,serialized (12 campus files),%.0f,ms%n", t[0]);
            long campusBytes = 0; for (Path p : campus) campusBytes += Files.size(p);

            System.out.println("\n=== Loading the database (7 columns, batches of 1,000, ONE transaction)");
            Db.runScript(con, Path.of("schema.sql"));
            timed("insert " + String.format("%,d", N) + " rows", () -> {
                con.setAutoCommit(false);
                try (PreparedStatement ps = con.prepareStatement(Migrate.SQL)) {
                    int n = 0;
                    for (BusPass p : all) { ps.setString(1, p.passId); ps.setString(2, p.regNo); ps.setString(3, p.name); ps.setInt(4, p.route); ps.setBigDecimal(5, BigDecimal.valueOf(p.amount)); ps.setString(6, p.stop); ps.setDate(7, java.sql.Date.valueOf(p.validUntil)); ps.addBatch(); if (++n % 1000 == 0) ps.executeBatch(); }
                    ps.executeBatch(); con.commit();
                } finally { con.setAutoCommit(true); }
                return 0;
            }, t); csv.printf("write,database,%.0f,ms%n", t[0]);
            long rows = Db.count(con, "bus_pass");
            Db.run(con, "ANALYZE TABLE bus_pass");
            double dbMb; try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("SELECT data_length + index_length FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'bus_pass'")) { rs.next(); dbMb = rs.getLong(1) / 1048576.0; }
            System.out.printf("  rows in table: %,d; table size (data + index) %.1f MB%n", rows, dbMb);

            System.out.println("\n=== Sizes");
            System.out.printf("  text file %.1f MB | one serialized file %.1f MB | 12 campus files %.1f MB | database %.1f MB%n", Files.size(text) / 1048576.0, Files.size(ser) / 1048576.0, campusBytes / 1048576.0, dbMb);
            csv.printf("size,text file,%.1f,MB%nsize,serialized (one file),%.1f,MB%nsize,serialized (12 campus files),%.1f,MB%nsize,database,%.1f,MB%n", Files.size(text) / 1048576.0, Files.size(ser) / 1048576.0, campusBytes / 1048576.0, dbMb);

            // ---------------- find one pass by ID
            System.out.println("\n=== Find ONE pass by ID (average over random existing IDs)");
            BusPassFileStore store = new BusPassFileStore(text);
            double sum = 0; int k = 5; for (int i = 0; i < k; i++) { long t0 = System.nanoTime(); Bench.sink += store.find(id(probe[i])).isPresent() ? 1 : 0; sum += ms(t0); }
            double textFind = sum / k; System.out.printf("  text file, scan from the start                       %10.1f ms per search (%d searches)%n", textFind, k); csv.printf("find one,text file scan,%.2f,ms%n", textFind);
            Bench.gc(); long h0 = Bench.usedHeap();
            sum = 0; k = 2; List<BusPass> loaded = null;
            for (int i = 0; i < k; i++) { long t0 = System.nanoTime(); loaded = readSer(ser); Bench.sink += loaded.size(); sum += ms(t0); }
            double serLoad = sum / k; System.out.printf("  serialized file: read the whole file, then search     %10.1f ms per search (%d searches)%n", serLoad, k); csv.printf("find one,serialized: load whole file for every search,%.1f,ms%n", serLoad);
            Map<String, BusPass> map = new HashMap<>(); for (BusPass p : loaded) map.put(p.passId, p); Bench.gc();
            double heapMb = (Bench.usedHeap() - h0) / 1048576.0;
            long t0 = System.nanoTime(); for (int i = 0; i < probe.length; i++) Bench.sink += map.get(id(probe[i])) != null ? 1 : 0; double mapNs = (System.nanoTime() - t0) / (double) probe.length;
            System.out.printf("  serialized, already in memory (HashMap)              %10.0f ns per search; extra heap in use for the 800,000 loaded passes %.0f MB%n", mapNs, heapMb); csv.printf("find one,serialized: already in memory,%.0f,ns%nheap,in-memory HashMap of all passes,%.0f,MB%n", mapNs, heapMb);
            PreparedStatement pk = con.prepareStatement("SELECT pass_id, name FROM bus_pass WHERE pass_id = ?");
            for (int i = 0; i < 300; i++) { pk.setString(1, id(probe[i])); try (ResultSet rs = pk.executeQuery()) { rs.next(); } }
            t0 = System.nanoTime(); for (int i = 0; i < probe.length; i++) { pk.setString(1, id(probe[i])); try (ResultSet rs = pk.executeQuery()) { if (rs.next()) Bench.sink++; } }
            double dbUs = (System.nanoTime() - t0) / 1e3 / probe.length; System.out.printf("  database, primary key                                %10.1f us per search (%d searches)%n", dbUs, probe.length); csv.printf("find one,database primary key,%.1f,us%n", dbUs);

            // ---------------- 12 campus files
            map = null; loaded = null; Bench.gc();
            System.out.println("\n=== Find one pass when the passes are in 12 campus files (pass i is in campus i mod 12)");
            sum = 0; double files = 0; k = 3;
            for (int i = 0; i < k; i++) {
                String want = id(probe[i]); long a = System.nanoTime(); int opened = 0; boolean found = false;
                for (int c = 0; c < CAMPUSES && !found; c++) { List<BusPass> l = readSer(campus[c]); opened++; for (BusPass p : l) if (p.passId.equals(want)) { found = true; break; } }
                sum += ms(a); files += opened;
            }
            System.out.printf("  open and read campus files until found                %9.1f ms per search (on average %.1f of 12 files read)%n", sum / k, files / k); csv.printf("find one,12 campus files read until found,%.1f,ms%n", sum / k);
            System.out.println("  database: one table, one query                         see above (the same primary-key search covers all campuses)");

            // ---------------- list one route
            System.out.println("\n=== List all passes of route 12 (about 2.5% of all passes)");
            sum = 0; int cnt = 0; for (int i = 0; i < 3; i++) { long a = System.nanoTime(); cnt = store.listByRoute(12).size(); sum += ms(a); }
            System.out.printf("  text file scan                                       %10.1f ms (%,d passes)%n", sum / 3, cnt); csv.printf("list route,text file scan,%.1f,ms%n", sum / 3);
            PreparedStatement lr = con.prepareStatement("SELECT pass_id, reg_no, name, route_no, amount FROM bus_pass WHERE route_no = ?");
            String plan; try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("EXPLAIN SELECT pass_id FROM bus_pass WHERE route_no = 12")) { rs.next(); plan = "type=" + rs.getString("type") + ", key=" + rs.getString("key") + ", rows~" + rs.getString("rows"); }
            sum = 0; for (int i = 0; i < 5; i++) { long a = System.nanoTime(); lr.setInt(1, 12); int c = 0; try (ResultSet rs = lr.executeQuery()) { while (rs.next()) c++; } sum += ms(a); cnt = c; }
            System.out.printf("  database, NO index on route_no                       %10.1f ms (%,d rows)  plan: %s%n", sum / 5, cnt, plan); csv.printf("list route,database without index,%.1f,ms%n", sum / 5);
            long ic = System.nanoTime(); Db.run(con, "CREATE INDEX idx_route ON bus_pass(route_no)"); double icMs = ms(ic);
            try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("EXPLAIN SELECT pass_id FROM bus_pass WHERE route_no = 12")) { rs.next(); plan = "type=" + rs.getString("type") + ", key=" + rs.getString("key") + ", rows~" + rs.getString("rows"); }
            sum = 0; for (int i = 0; i < 5; i++) { long a = System.nanoTime(); lr.setInt(1, 12); int c = 0; try (ResultSet rs = lr.executeQuery()) { while (rs.next()) c++; } sum += ms(a); cnt = c; }
            System.out.printf("  database, WITH index on route_no (created in %.0f ms)  %8.1f ms (%,d rows)  plan: %s%n", icMs, sum / 5, cnt, plan); csv.printf("list route,database with index,%.1f,ms%ncreate index,database,%.0f,ms%n", sum / 5, icMs);
            double dbMb2; try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("SELECT data_length + index_length FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'bus_pass'")) { rs.next(); dbMb2 = rs.getLong(1) / 1048576.0; }
            System.out.printf("  table size with the extra index: %.1f MB (was %.1f MB)%n", dbMb2, dbMb); csv.printf("size,database with route index,%.1f,MB%n", dbMb2);
            List<BusPass> mem = readSer(ser); long a = System.nanoTime(); int c2 = 0; for (int r = 0; r < 20; r++) { c2 = 0; for (BusPass p : mem) if (p.route == 12) c2++; } double inMem = ms(a) / 20;
            System.out.printf("  serialized, already in memory (loop over the list)    %9.1f ms (%,d passes)%n", inMem, c2); csv.printf("list route,serialized in memory,%.1f,ms%n", inMem);
            Files.delete(text); Files.delete(ser); for (Path p : campus) Files.delete(p);
            Db.run(con, "DROP INDEX idx_route ON bus_pass"); Db.run(con, "TRUNCATE TABLE bus_pass");
        }
    }
}
