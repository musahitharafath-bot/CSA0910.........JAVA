import java.io.*;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/** B4.1: migrate the text-file store into the bus_pass table - validate, load in batches inside one transaction, report what failed. */
public class Migrate {
    static final String SQL = "INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount, boarding_stop, valid_until) VALUES (?, ?, ?, ?, ?, ?, ?)";
    record Failure(int lineNo, String reason, String text) { }
    record Report(int linesRead, int valid, List<Failure> failures, int loaded, String dbError, long dbRowsAfter, double ms) { }

    static Report migrate(Connection con, Path file) throws Exception {
        long t0 = System.nanoTime();
        List<BusPass> good = new ArrayList<>(); List<Failure> failures = new ArrayList<>(); Map<String, Integer> firstLine = new HashMap<>();
        int lines = 0;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(Files.newInputStream(file), StandardCharsets.UTF_8))) {
            String line; int no = 0;
            while ((line = r.readLine()) != null) {
                no++; if (line.startsWith("#")) continue; lines++;
                PassCodec.Result res = PassCodec.decode(line);
                if (!res.ok()) { failures.add(new Failure(no, res.error(), line)); continue; }
                Integer prev = firstLine.putIfAbsent(res.pass().passId, no);
                if (prev != null) failures.add(new Failure(no, "duplicate pass ID (first seen on line " + prev + ")", line)); else good.add(res.pass());
            }
        }
        int loaded = 0; String err = "none";
        boolean old = con.getAutoCommit(); con.setAutoCommit(false);
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (BusPass p : good) {
                ps.setString(1, p.passId); ps.setString(2, p.regNo); ps.setString(3, p.name); ps.setInt(4, p.route); ps.setBigDecimal(5, BigDecimal.valueOf(p.amount));
                ps.setString(6, p.stop); ps.setDate(7, java.sql.Date.valueOf(p.validUntil)); ps.addBatch();
                if (++loaded % 500 == 0) ps.executeBatch();
            }
            ps.executeBatch(); con.commit();
        } catch (SQLException e) { con.rollback(); loaded = 0; err = e.getClass().getSimpleName() + ": " + e.getMessage().split("\n")[0]; }
        finally { con.setAutoCommit(old); }
        return new Report(lines, good.size(), failures, loaded, err, Db.count(con, "bus_pass"), (System.nanoTime() - t0) / 1e6);
    }

    static void print(String title, Report r) {
        System.out.println("--- " + title);
        System.out.printf("lines read (not counting the header): %d | valid and unique: %d | failed validation: %d%n", r.linesRead(), r.valid(), r.failures().size());
        System.out.printf("rows loaded in this run: %d | database error: %s | rows in table afterwards: %d | time %.0f ms%n", r.loaded(), r.dbError(), r.dbRowsAfter(), r.ms());
    }

    public static void main(String[] args) throws Exception {
        Path file = Path.of(args[0]); String out = args[1]; Files.createDirectories(Path.of(out));
        try (Connection con = Db.connect()) {
            Db.runScript(con, Path.of("schema.sql"));
            Report r1 = migrate(con, file);
            print("Migration run 1 (empty table)", r1);
            System.out.println("\nFailed lines (written to " + out + "/migration_failures.csv):");
            System.out.printf("%-6s %-58s %s%n", "line", "reason", "text (shortened)");
            try (PrintWriter csv = new PrintWriter(out + "/migration_failures.csv", StandardCharsets.UTF_8)) {
                csv.println("line,reason,text");
                for (Failure f : r1.failures()) {
                    String t = f.text().length() > 56 ? f.text().substring(0, 53) + "..." : f.text();
                    System.out.printf("%-6d %-58s %s%n", f.lineNo(), f.reason(), t);
                    csv.printf("%d,\"%s\",\"%s\"%n", f.lineNo(), f.reason().replace("\"", "\"\""), f.text().replace("\"", "\"\""));
                }
            }
            // verification against the file: same count and same total amount
            BusPassFileStore store = new BusPassFileStore(file); BusPassFileStore.ScanResult sr = store.scanAll();
            Set<String> ids = new HashSet<>(); double fileTotal = 0; int fileUnique = 0;
            for (BusPass p : sr.passes) if (ids.add(p.passId)) { fileTotal += p.amount; fileUnique++; }
            try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*), SUM(amount), COUNT(DISTINCT route_no) FROM bus_pass")) {
                rs.next(); System.out.printf("%nCheck: file has %d unique valid passes, total amount %.2f; table has %d rows, total amount %.2f (%s)%n", fileUnique, fileTotal, rs.getLong(1), rs.getDouble(2),
                        rs.getLong(1) == fileUnique && Math.abs(rs.getDouble(2) - fileTotal) < 0.005 ? "match" : "MISMATCH");
            }
            System.out.println();
            Report r2 = migrate(con, file);
            print("Migration run 2 (same file again: every pass ID is already in the table)", r2);
            System.out.println("The whole second load was rolled back: " + (r2.dbRowsAfter() == r1.loaded() ? "table unchanged, still " + r2.dbRowsAfter() + " rows" : "UNEXPECTED row count"));
        }
    }
}
