import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;

/** Creates input/passes_legacy.txt: 2,000 good passes with eight damaged or conflicting lines inserted at known places. */
public class MakeInput {
    static String line(String... f) { String body = String.join(",", f); return body + "," + PassCodec.crc(body); }
    public static void main(String[] args) throws Exception {
        Path dir = Path.of(args.length > 0 ? args[0] : "input"); Files.createDirectories(dir);
        List<String> out = new ArrayList<>(); out.add(PassCodec.HEADER);
        List<BusPass> good = DataGen.passes(2000, 77);
        Map<Integer, String> bad = new HashMap<>();                                    // inserted BEFORE good record number k
        bad.put(100, "P900001,192311001,Wrong Fields,12");
        bad.put(250, line("P900002", "192311002", "Bad Amount", "7", "Adyar", "2027-03-31", "45oo.00"));
        bad.put(400, "");
        bad.put(777, PassCodec.encode(new BusPass("P900003", "192311003", "Changed After Checksum", 5, "Guindy", LocalDate.of(2027, 3, 31), 4000)).replace("4000.00", "9000.00"));
        bad.put(1000, line("P900004", "192311004", "Negative Amount", "9", "Porur", "2027-03-31", "-250.00"));
        bad.put(1500, PassCodec.encode(new BusPass("P000020", "192311005", "Duplicate Of P000020", 3, "Avadi", LocalDate.of(2027, 3, 31), 4100)));
        bad.put(1800, line("P900006", "192311006", "Bad Date", "9", "Mangadu", "31/03/2027", "4100.00"));
        for (int i = 0; i < good.size(); i++) { if (bad.containsKey(i + 1)) out.add(bad.get(i + 1)); out.add(PassCodec.encode(good.get(i))); }
        String torn = PassCodec.encode(new BusPass("P900008", "192311008", "Half Written", 8, "Koyambedu", LocalDate.of(2027, 3, 31), 4000));
        Files.write(dir.resolve("passes_legacy.txt"), (String.join("\n", out) + "\n" + torn.substring(0, 45)).getBytes(StandardCharsets.UTF_8));
        System.out.println("created " + dir.resolve("passes_legacy.txt") + ": " + (out.size() + 1) + " lines = 1 header + 2000 good passes + 8 damaged or conflicting lines");
    }
}
