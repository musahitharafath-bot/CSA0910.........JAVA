import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.*;

/** B4.3: four counters issue 250 passes each at the same time. How do the file store and the database cope? */
public class CounterRace {
    static final int K = 4, EACH = 250;
    static BusPass pass(int number) { return new BusPass(String.format("P%06d", number), "192311001", "Counter Test", 1 + number % 40, "Tambaram", LocalDate.of(2027, 3, 31), 4000); }

    static int countLines(Path f) throws IOException {                          // "next number" for the file store = lines already in the file
        if (!Files.exists(f)) return 0;
        try (BufferedReader r = new BufferedReader(new FileReader(f.toFile()))) { int n = 0; String l; while ((l = r.readLine()) != null) if (!l.startsWith("#") && !l.isEmpty()) n++; return n; }
    }
    interface Issue { void issue(int counter) throws Exception; }
    static double runThreads(Issue body) throws Exception {
        ExecutorService ex = Executors.newFixedThreadPool(K); CyclicBarrier go = new CyclicBarrier(K); List<Future<?>> fs = new ArrayList<>();
        long t0 = System.nanoTime();
        for (int c = 0; c < K; c++) { final int id = c; fs.add(ex.submit(() -> { go.await(); body.issue(id); return null; })); }
        for (Future<?> f : fs) f.get();
        ex.shutdown(); return (System.nanoTime() - t0) / 1e6;
    }

    public static void main(String[] args) throws Exception {
        String out = args.length > 0 ? args[0] : "output"; Files.createDirectories(Path.of(out));
        int expected = K * EACH;
        System.out.printf("%d counters x %d passes = %,d passes should be issued, each with a different pass ID.%n%n", K, EACH, expected);
        System.out.printf("%-46s %7s %8s %10s %12s %9s%n", "scheme", "trial", "ms", "rows", "distinct IDs", "duplicates");
        try (PrintWriter csv = new PrintWriter(out + "/b4_counters.csv"); Connection admin = Db.connect()) {
            Db.runScript(admin, Path.of("schema.sql"));
            csv.println("scheme,trial,ms,rows,distinct_ids,duplicate_ids,rejected_attempts");
            // ---- A: file store, "next ID = number of lines + 1", no coordination
            for (int trial = 1; trial <= 5; trial++) {
                Path f = Files.createTempFile("race", ".txt"); Files.delete(f); BusPassFileStore s = new BusPassFileStore(f);
                double ms = runThreads(c -> { for (int i = 0; i < EACH; i++) s.add(pass(countLines(f) + 1), false); });
                report(csv, "file, no coordination", trial, ms, f, 0); Files.delete(f);
            }
            // ---- B: file store, one lock around "count + add" (works only inside ONE program)
            Object lock = new Object();
            for (int trial = 1; trial <= 3; trial++) {
                Path f = Files.createTempFile("race", ".txt"); Files.delete(f); BusPassFileStore s = new BusPassFileStore(f);
                double ms = runThreads(c -> { for (int i = 0; i < EACH; i++) synchronized (lock) { s.add(pass(countLines(f) + 1), false); } });
                report(csv, "file, lock inside one program", trial, ms, f, 0); Files.delete(f);
            }
            // ---- C: database, same naive "max + 1" idea, protected by the PRIMARY KEY; a rejected insert is retried
            for (int trial = 1; trial <= 3; trial++) {
                Db.run(admin, "TRUNCATE TABLE bus_pass"); ConcurrentLinkedQueue<Integer> rejects = new ConcurrentLinkedQueue<>();
                double ms = runThreads(c -> {
                    try (Connection con = Db.connect(); PreparedStatement mx = con.prepareStatement("SELECT COALESCE(MAX(CAST(SUBSTRING(pass_id, 2) AS UNSIGNED)), 0) FROM bus_pass");
                         PreparedStatement ins = con.prepareStatement("INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount) VALUES (?, '192311001', 'Counter Test', 1, 4000)")) {
                        for (int i = 0; i < EACH; i++) {
                            while (true) {
                                int next; try (ResultSet rs = mx.executeQuery()) { rs.next(); next = rs.getInt(1) + 1; }
                                ins.setString(1, String.format("P%06d", next));
                                try { ins.executeUpdate(); break; } catch (SQLIntegrityConstraintViolationException e) { rejects.add(1); }
                            }
                        }
                    }
                });
                long rows = Db.count(admin, "bus_pass"); long distinct; try (Statement st = admin.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(DISTINCT pass_id) FROM bus_pass")) { rs.next(); distinct = rs.getLong(1); }
                line(csv, "database, max+1 with PRIMARY KEY + retry", trial, ms, rows, distinct, rejects.size());
            }
            // ---- D: database, AUTO_INCREMENT
            for (int trial = 1; trial <= 3; trial++) {
                Db.run(admin, "TRUNCATE TABLE bus_pass_issue");
                double ms = runThreads(c -> {
                    try (Connection con = Db.connect(); PreparedStatement ins = con.prepareStatement("INSERT INTO bus_pass_issue(reg_no, name, route_no, amount) VALUES ('192311001', 'Counter Test', 1, 4000)")) {
                        for (int i = 0; i < EACH; i++) ins.executeUpdate();
                    }
                });
                long rows = Db.count(admin, "bus_pass_issue"); long distinct; try (Statement st = admin.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(DISTINCT seq) FROM bus_pass_issue")) { rs.next(); distinct = rs.getLong(1); }
                line(csv, "database, AUTO_INCREMENT", trial, ms, rows, distinct, 0);
            }
        }
    }
    static void report(PrintWriter csv, String scheme, int trial, double ms, Path f, int rejected) throws IOException {
        BusPassFileStore.ScanResult r = new BusPassFileStore(f).scanAll(); Set<String> ids = new HashSet<>(); for (BusPass p : r.passes) ids.add(p.passId);
        line(csv, scheme, trial, ms, r.passes.size(), ids.size(), rejected);
    }
    static void line(PrintWriter csv, String scheme, int trial, double ms, long rows, long distinct, int rejected) {
        System.out.printf("%-46s %7d %8.0f %10d %12d %9d%s%n", scheme, trial, ms, rows, distinct, rows - distinct, rejected > 0 ? "   (" + rejected + " inserts rejected by the database and retried)" : "");
        csv.printf("\"%s\",%d,%.0f,%d,%d,%d,%d%n", scheme, trial, ms, rows, distinct, rows - distinct, rejected);
    }
}
