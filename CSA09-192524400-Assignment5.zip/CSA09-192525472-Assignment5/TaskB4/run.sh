#!/bin/sh
# Compile and run TaskB4
cd "$(dirname "$0")"
mkdir -p out output
javac -cp "../lib/*" -d out src/*.java
java -cp "out:../lib/*" ScaleStudy output | tee output/ScaleStudy_output.txt
rm -rf out
