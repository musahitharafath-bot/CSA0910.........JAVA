# TaskB4 - Assignment 5 (CO5), Programming in Java

**Student:** Syed Aakif Hussain S A  |  **Register number:** 192525472

Migration of the text file to the database with a failure report, DatabaseMetaData inspection, an 800,000-pass scale study, and concurrent pass-ID counters.

## Environment
- Compiled and run with Java 21.0.12.1
- Needs the database. ScaleStudy takes several minutes and about 300 MB of disk.
- Test database for the reported results: MariaDB 10.11 with MariaDB Connector/J (MySQL-compatible). Edit `../db.properties` to use your own MySQL.

## Folder contents
- `src/` - Java source code
- `input/` - input files used by the programs
- `output/` - program output (`*_output.txt`), console screenshots (`*_console.png`), CSV data and charts
- `schema.sql` - table definitions the programs create
- `run.sh` - compiles and runs everything in this task

## How to run
```
sh run.sh
```
Or by hand: `javac -cp "../lib/*" -d out src/*.java` then `java -cp "out:../lib/*" <MainClass> output`.

## Programs and results
- `MakeInput` -> `output/MakeInput_output.txt` and `output/MakeInput_console.png`
- `Migrate` -> `output/Migrate_output.txt` and `output/Migrate_console.png`
- `InspectDb` -> `output/InspectDb_output.txt` and `output/InspectDb_console.png`
- `CounterRace` -> `output/CounterRace_output.txt` and `output/CounterRace_console.png`
- `ScaleStudy` -> `output/ScaleStudy_output.txt` and `output/ScaleStudy_console.png`

Data files and charts written to `output/`: `b4_*.csv`, `chart_b4_*.png`, `migration_failures.csv`.

Timings are from a shared 2-vCPU machine and vary by run. Compare ratios and trends, not single numbers.
