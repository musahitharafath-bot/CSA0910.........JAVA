-- Task B3: the bus_pass table of the LOCAL TEST database (also used in Task B4).
DROP TABLE IF EXISTS bus_pass;
CREATE TABLE bus_pass (
    pass_id       VARCHAR(10)   NOT NULL PRIMARY KEY,
    reg_no        VARCHAR(12)   NOT NULL,
    name          VARCHAR(60)   NOT NULL,
    route_no      INT           NOT NULL,
    amount        DECIMAL(10,2) NOT NULL,
    boarding_stop VARCHAR(40)   NULL,
    valid_until   DATE          NULL
) ENGINE=InnoDB;
DROP TABLE IF EXISTS bus_pass_issue;
CREATE TABLE bus_pass_issue (
    seq      INT           NOT NULL AUTO_INCREMENT PRIMARY KEY,
    reg_no   VARCHAR(12)   NOT NULL,
    name     VARCHAR(60)   NOT NULL,
    route_no INT           NOT NULL,
    amount   DECIMAL(10,2) NOT NULL
) ENGINE=InnoDB;
