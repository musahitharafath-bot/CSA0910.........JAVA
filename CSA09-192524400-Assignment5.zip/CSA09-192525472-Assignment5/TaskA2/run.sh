#!/bin/sh
# Compile and run TaskA2
cd "$(dirname "$0")"
mkdir -p out output
javac -cp "../lib/*" -d out src/*.java
java -cp "out:../lib/*" MakeLog /tmp/a2_log50.txt 50 | tee output/MakeLog_output.txt
for m in readAllLines byteArray; do for x in 32m 64m 128m 512m; do java -Xmx$x -cp "out:../lib/*" ReadMem $m /tmp/a2_log50.txt 2>&1 | grep -v JAVA_TOOL; done; done; rm -f /tmp/a2_log50.txt | tee output/ReadMem_output.txt
rm -rf out
