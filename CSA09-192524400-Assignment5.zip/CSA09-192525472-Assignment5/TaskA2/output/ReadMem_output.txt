readAllLines   -Xmx32m   -> OutOfMemoryError: Java heap space
readAllLines   -Xmx64m   -> OutOfMemoryError: Java heap space
readAllLines   -Xmx128m  -> counted 875,086 lines; heap still in use right after the call: 89.9 MB
readAllLines   -Xmx512m  -> counted 875,086 lines; heap still in use right after the call: 90.1 MB
byteArray      -Xmx32m   -> counted 875,086 lines; heap still in use right after the call: -0.7 MB
byteArray      -Xmx64m   -> counted 875,086 lines; heap still in use right after the call: -0.6 MB
byteArray      -Xmx128m  -> counted 875,086 lines; heap still in use right after the call: -0.6 MB
byteArray      -Xmx512m  -> counted 875,086 lines; heap still in use right after the call: -0.6 MB
