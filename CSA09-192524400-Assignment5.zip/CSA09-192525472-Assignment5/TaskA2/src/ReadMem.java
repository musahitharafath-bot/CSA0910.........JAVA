import java.io.*;
import java.nio.file.*;
import java.util.List;

/** Task A2 alternative: count lines with Files.readAllLines (whole file in memory) or with a buffered stream, under a small heap. */
public class ReadMem {
    public static void main(String[] args) throws Exception {
        String mode = args[0]; Path f = Path.of(args[1]);
        long max = Runtime.getRuntime().maxMemory() >> 20;
        String res;
        try {
            long lines; long before = Bench.usedHeap(); long retained;
            if (mode.equals("readAllLines")) { List<String> all = Files.readAllLines(f); lines = all.size(); Bench.gc(); retained = Bench.usedHeap() - before; Bench.sink += all.size(); }
            else { long[] c = new long[1]; lines = LineCounter.byteArray(f, 1 << 16, c); Bench.gc(); retained = Bench.usedHeap() - before; }
            res = String.format("counted %,d lines; heap still in use right after the call: %.1f MB", lines, retained / 1048576.0);
        } catch (OutOfMemoryError e) { res = "OutOfMemoryError: " + e.getMessage(); }
        System.out.printf("%-14s -Xmx%-5s -> %s%n", mode, max + "m", res);
    }
}
