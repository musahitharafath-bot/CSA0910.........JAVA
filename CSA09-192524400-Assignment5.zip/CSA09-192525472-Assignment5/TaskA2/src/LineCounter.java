import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.List;

/** The line counters of Task A2 / B1.3. calls[0] receives the number of read calls that reach FileInputStream. */
final class LineCounter {
    /** FileInputStream that counts how many times a read method is called on it. */
    static final class CountingFis extends FileInputStream {
        long calls;
        CountingFis(Path p) throws IOException { super(p.toFile()); }
        @Override public int read() throws IOException { calls++; return super.read(); }
        @Override public int read(byte[] b) throws IOException { calls++; return super.read(b); }
        @Override public int read(byte[] b, int off, int len) throws IOException { calls++; return super.read(b, off, len); }
    }

    /** A2.1 - the slow program: one read() call for every byte. */
    static long unbuffered(Path p, long[] calls) throws IOException {
        try (CountingFis in = new CountingFis(p)) {
            long lines = 0; int b;
            while ((b = in.read()) != -1) if (b == '\n') lines++;
            calls[0] = in.calls; return lines;
        }
    }

    /** A2.2 (a) - BufferedInputStream: the program still calls read() per byte, but on the buffer, not on the file. */
    static long bufferedStream(Path p, int bufSize, long[] calls) throws IOException {
        try (CountingFis fis = new CountingFis(p); InputStream in = new BufferedInputStream(fis, bufSize)) {
            long lines = 0; int b;
            while ((b = in.read()) != -1) if (b == '\n') lines++;
            calls[0] = fis.calls; return lines;
        }
    }

    /** A2.2 (b) - own byte-array buffer: one read(byte[]) call per chunk. */
    static long byteArray(Path p, int bufSize, long[] calls) throws IOException {
        try (CountingFis in = new CountingFis(p)) {
            byte[] buf = new byte[bufSize]; long lines = 0; int n;
            while ((n = in.read(buf)) != -1) for (int i = 0; i < n; i++) if (buf[i] == '\n') lines++;
            calls[0] = in.calls; return lines;
        }
    }

    /** A2.3 - a buffer that is not needed: the caller already reads 64 KB blocks through an 8 KB BufferedInputStream. */
    static long bufferedStreamBigReads(Path p, long[] calls) throws IOException {
        try (CountingFis fis = new CountingFis(p); InputStream in = new BufferedInputStream(fis)) {
            byte[] buf = new byte[1 << 16]; long lines = 0; int n;
            while ((n = in.read(buf)) != -1) for (int i = 0; i < n; i++) if (buf[i] == '\n') lines++;
            calls[0] = fis.calls; return lines;
        }
    }

    /** Character-based: BufferedReader.readLine() (decodes bytes to chars and creates a String per line). */
    static long readerReadLine(Path p, long[] calls) throws IOException {
        try (CountingFis fis = new CountingFis(p); BufferedReader r = new BufferedReader(new InputStreamReader(fis, StandardCharsets.UTF_8))) {
            long lines = 0; while (r.readLine() != null) lines++;
            calls[0] = fis.calls; return lines;
        }
    }

    /** Alternative concept of Task A2: read everything into memory. */
    static long readAllLines(Path p, long[] calls) throws IOException {
        List<String> all = Files.readAllLines(p); calls[0] = -1; return all.size();
    }
}
