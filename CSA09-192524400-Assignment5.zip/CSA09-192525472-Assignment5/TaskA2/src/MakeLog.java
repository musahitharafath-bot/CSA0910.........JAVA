import java.nio.file.*;

/** Creates a test attendance log: MakeLog <file> <megabytes>. */
public class MakeLog {
    public static void main(String[] a) throws Exception {
        long lines = DataGen.writeLog(Path.of(a[0]), Long.parseLong(a[1]) * 1048576L, 11);
        System.out.println("created " + a[0] + ": " + a[1] + " MB, " + lines + " lines");
    }
}
