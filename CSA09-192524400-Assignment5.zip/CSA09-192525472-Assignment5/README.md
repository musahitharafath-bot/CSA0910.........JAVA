# CSA09-192525472-Assignment5

Programming in Java - Assignment 5 (CO5): file handling, serialization and JDBC for a transport bus-pass system.

**Student:** Syed Aakif Hussain S A  |  **Register number:** 192525472

## Layout (one folder per task)
| Folder | Topic |
|---|---|
| TaskA1 | Record layouts for the bus-pass file |
| TaskA2 | Line counter and buffering |
| TaskA3 | DAO pattern |
| TaskA4 | Serialization, transient, versioning |
| TaskA5 | Transactions and SQL injection |
| TaskB1 | File store, tests, line counting, PassStore |
| TaskB2 | SQL injection and damaged-file tests |
| TaskB3 | JDBC inserts, commit modes, PassLoader |
| TaskB4 | Migration, DatabaseMetaData, scale study, counters |

Each task folder has `src/` (code), `input/` (input files, where used), `output/` (results and screenshots), `run.sh` and a `README.md`.
Shared: `lib/` (JDBC driver, Gson), `db.properties` (connection settings), `sql/create_test_database.sql` (creates the test database and user).

## Quick start
1. Install Java 17+ and MySQL or MariaDB.
2. `mysql -u root -p < sql/create_test_database.sql`
3. Check `db.properties`, then `sh TaskB3/run.sh` (or any other task).

Compiled and run with Java 21.0.12.1. Results in the report were produced on MariaDB 10.11 with MariaDB Connector/J.
