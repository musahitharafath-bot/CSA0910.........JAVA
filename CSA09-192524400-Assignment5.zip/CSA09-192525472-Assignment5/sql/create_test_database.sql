-- Creates the LOCAL TEST database and user used by Assignment 5.
-- Run as an administrator:  mysql -u root -p < sql/create_test_database.sql
-- Never point these programs at a real or production database: they DROP and re-create their own tables.
CREATE DATABASE IF NOT EXISTS transport_test CHARACTER SET utf8mb4;
CREATE USER IF NOT EXISTS 'assign5'@'localhost' IDENTIFIED BY 'assign5pw';
GRANT ALL PRIVILEGES ON transport_test.* TO 'assign5'@'localhost';
-- Only needed for the LOAD DATA LOCAL INFILE comparison in TaskB3 (optional):
SET GLOBAL local_infile = 1;
FLUSH PRIVILEGES;
