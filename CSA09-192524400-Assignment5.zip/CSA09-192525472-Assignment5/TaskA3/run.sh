#!/bin/sh
# Compile and run TaskA3
cd "$(dirname "$0")"
mkdir -p out output
javac -cp "../lib/*" -d out src/*.java
java -cp "out:../lib/*" DaoDemo output | tee output/DaoDemo_output.txt
rm -rf out
