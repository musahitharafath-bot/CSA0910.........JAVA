# TaskA3 - Assignment 5 (CO5), Programming in Java

**Student:** Syed Aakif Hussain S A  |  **Register number:** 192525472

DAO pattern: generic Dao/JdbcDao, three DAOs, and the same features written inline to compare change cost and run time.

## Environment
- Compiled and run with Java 21.0.12.1
- Needs the database (see ../db.properties).
- Test database for the reported results: MariaDB 10.11 with MariaDB Connector/J (MySQL-compatible). Edit `../db.properties` to use your own MySQL.

## Folder contents
- `src/` - Java source code
- `input/` - input files used by the programs
- `output/` - program output (`*_output.txt`), console screenshots (`*_console.png`), CSV data and charts
- `schema.sql` - table definitions the programs create
- `run.sh` - compiles and runs everything in this task

## How to run
```
sh run.sh
```
Or by hand: `javac -cp "../lib/*" -d out src/*.java` then `java -cp "out:../lib/*" <MainClass> output`.

## Programs and results
- `DaoDemo` -> `output/DaoDemo_output.txt` and `output/DaoDemo_console.png`

Data files and charts written to `output/`: `a3_cost.csv`, `a3_rename.csv`.

Timings are from a shared 2-vCPU machine and vary by run. Compare ratios and trends, not single numbers.
