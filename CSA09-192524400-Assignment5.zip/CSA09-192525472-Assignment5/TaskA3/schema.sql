-- Task A3: tables of the student project (test database only)
DROP TABLE IF EXISTS marks;
DROP TABLE IF EXISTS student;
DROP TABLE IF EXISTS course;
CREATE TABLE student (
    reg_no  VARCHAR(12)  NOT NULL PRIMARY KEY,
    name    VARCHAR(60)  NOT NULL,
    dept    VARCHAR(20),
    cgpa    DECIMAL(4,2)
) ENGINE=InnoDB;
CREATE TABLE course (
    code    VARCHAR(10)  NOT NULL PRIMARY KEY,
    title   VARCHAR(60)  NOT NULL,
    credits INT          NOT NULL
) ENGINE=InnoDB;
CREATE TABLE marks (
    reg_no      VARCHAR(12) NOT NULL,
    course_code VARCHAR(10) NOT NULL,
    mark        INT         NOT NULL,
    PRIMARY KEY (reg_no, course_code),
    FOREIGN KEY (reg_no) REFERENCES student(reg_no),
    FOREIGN KEY (course_code) REFERENCES course(code)
) ENGINE=InnoDB;
