import java.sql.*;

/** A3.2: StudentDao implements Dao<Student, String>; it contains only what is specific to the student table. */
class StudentDao extends JdbcDao<Student, String> {
    StudentDao(Connection con) { super(con); }
    protected String insertSql() { return "INSERT INTO student(reg_no, name, dept, cgpa) VALUES (?, ?, ?, ?)"; }
    protected String selectByIdSql() { return "SELECT reg_no, name, dept, cgpa FROM student WHERE reg_no = ?"; }
    protected String selectAllSql() { return "SELECT reg_no, name, dept, cgpa FROM student ORDER BY reg_no"; }
    protected String updateSql() { return "UPDATE student SET name = ?, dept = ?, cgpa = ? WHERE reg_no = ?"; }
    protected String deleteSql() { return "DELETE FROM student WHERE reg_no = ?"; }
    protected Student mapRow(ResultSet rs) throws SQLException { return new Student(rs.getString("reg_no"), rs.getString("name"), rs.getString("dept"), rs.getDouble("cgpa")); }
    protected void bindInsert(PreparedStatement ps, Student s) throws SQLException { ps.setString(1, s.regNo); ps.setString(2, s.name); ps.setString(3, s.dept); ps.setDouble(4, s.cgpa); }
    protected void bindUpdate(PreparedStatement ps, Student s) throws SQLException { ps.setString(1, s.name); ps.setString(2, s.dept); ps.setDouble(3, s.cgpa); ps.setString(4, s.regNo); }
    protected void bindKey(PreparedStatement ps, String id) throws SQLException { ps.setString(1, id); }
}
