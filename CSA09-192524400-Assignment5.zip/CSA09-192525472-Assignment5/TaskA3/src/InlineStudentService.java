import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** The alternative: SQL written directly inside the service classes (one of three such classes). */
class InlineStudentService {
    final Connection con;
    InlineStudentService(Connection con) { this.con = con; }

    void register(String regNo, String name, String dept, double cgpa) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = con.prepareStatement("INSERT INTO student(reg_no, name, dept, cgpa) VALUES (?, ?, ?, ?)");
            ps.setString(1, regNo); ps.setString(2, name); ps.setString(3, dept); ps.setDouble(4, cgpa);
            ps.executeUpdate();
        } finally { if (ps != null) ps.close(); }
    }

    Student find(String regNo) throws SQLException {
        PreparedStatement ps = null; ResultSet rs = null;
        try {
            ps = con.prepareStatement("SELECT reg_no, name, dept, cgpa FROM student WHERE reg_no = ?");
            ps.setString(1, regNo); rs = ps.executeQuery();
            return rs.next() ? new Student(rs.getString("reg_no"), rs.getString("name"), rs.getString("dept"), rs.getDouble("cgpa")) : null;
        } finally { if (rs != null) rs.close(); if (ps != null) ps.close(); }
    }
}
