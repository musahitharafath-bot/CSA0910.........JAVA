import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * The part that was copied three times in StudentDB, CourseDB and MarksDB, written once:
 * prepare, set parameters, execute, map rows to objects, close, report errors.
 * A subclass only supplies what differs: the SQL text, how to bind parameters and how to map one row.
 */
abstract class JdbcDao<T, K> implements Dao<T, K> {
    protected final Connection con;
    JdbcDao(Connection con) { this.con = con; }

    interface Binder { void bind(PreparedStatement ps) throws SQLException; }
    interface RowMapper<R> { R map(ResultSet rs) throws SQLException; }

    protected abstract String insertSql();
    protected abstract String selectByIdSql();
    protected abstract String selectAllSql();
    protected abstract String updateSql();
    protected abstract String deleteSql();
    protected abstract T mapRow(ResultSet rs) throws SQLException;          // object <- row
    protected abstract void bindInsert(PreparedStatement ps, T e) throws SQLException;   // row <- object
    protected abstract void bindUpdate(PreparedStatement ps, T e) throws SQLException;
    protected abstract void bindKey(PreparedStatement ps, K id) throws SQLException;

    protected int execute(String sql, Binder b) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(sql)) { b.bind(ps); return ps.executeUpdate(); }
    }
    protected <R> List<R> query(String sql, Binder b, RowMapper<R> m) throws SQLException {
        List<R> out = new ArrayList<>();
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            b.bind(ps);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) out.add(m.map(rs)); }
        }
        return out;
    }

    @Override public void insert(T e) throws SQLException { execute(insertSql(), ps -> bindInsert(ps, e)); }
    @Override public Optional<T> findById(K id) throws SQLException {
        List<T> l = query(selectByIdSql(), ps -> bindKey(ps, id), this::mapRow); return l.isEmpty() ? Optional.empty() : Optional.of(l.get(0));
    }
    @Override public List<T> findAll() throws SQLException { return query(selectAllSql(), ps -> { }, this::mapRow); }
    @Override public boolean update(T e) throws SQLException { return execute(updateSql(), ps -> bindUpdate(ps, e)) == 1; }
    @Override public boolean delete(K id) throws SQLException { return execute(deleteSql(), ps -> bindKey(ps, id)) == 1; }
}
