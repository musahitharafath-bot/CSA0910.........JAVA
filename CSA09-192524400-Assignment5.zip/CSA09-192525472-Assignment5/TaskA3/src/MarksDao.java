import java.sql.*;

record MarkKey(String regNo, String courseCode) { }
record Mark(String regNo, String courseCode, int mark) { }

/** A third table with a composite primary key (K = MarkKey): the interface still fits. */
class MarksDao extends JdbcDao<Mark, MarkKey> {
    MarksDao(Connection con) { super(con); }
    protected String insertSql() { return "INSERT INTO marks(reg_no, course_code, mark) VALUES (?, ?, ?)"; }
    protected String selectByIdSql() { return "SELECT reg_no, course_code, mark FROM marks WHERE reg_no = ? AND course_code = ?"; }
    protected String selectAllSql() { return "SELECT reg_no, course_code, mark FROM marks ORDER BY reg_no, course_code"; }
    protected String updateSql() { return "UPDATE marks SET mark = ? WHERE reg_no = ? AND course_code = ?"; }
    protected String deleteSql() { return "DELETE FROM marks WHERE reg_no = ? AND course_code = ?"; }
    protected Mark mapRow(ResultSet rs) throws SQLException { return new Mark(rs.getString("reg_no"), rs.getString("course_code"), rs.getInt("mark")); }
    protected void bindInsert(PreparedStatement ps, Mark m) throws SQLException { ps.setString(1, m.regNo()); ps.setString(2, m.courseCode()); ps.setInt(3, m.mark()); }
    protected void bindUpdate(PreparedStatement ps, Mark m) throws SQLException { ps.setInt(1, m.mark()); ps.setString(2, m.regNo()); ps.setString(3, m.courseCode()); }
    protected void bindKey(PreparedStatement ps, MarkKey k) throws SQLException { ps.setString(1, k.regNo()); ps.setString(2, k.courseCode()); }
}
