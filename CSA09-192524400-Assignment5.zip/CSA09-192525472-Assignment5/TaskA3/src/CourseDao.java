import java.sql.*;

record Course(String code, String title, int credits) { }

/** The same generic code reused for a second table: only SQL, binding and mapping are written. */
class CourseDao extends JdbcDao<Course, String> {
    CourseDao(Connection con) { super(con); }
    protected String insertSql() { return "INSERT INTO course(code, title, credits) VALUES (?, ?, ?)"; }
    protected String selectByIdSql() { return "SELECT code, title, credits FROM course WHERE code = ?"; }
    protected String selectAllSql() { return "SELECT code, title, credits FROM course ORDER BY code"; }
    protected String updateSql() { return "UPDATE course SET title = ?, credits = ? WHERE code = ?"; }
    protected String deleteSql() { return "DELETE FROM course WHERE code = ?"; }
    protected Course mapRow(ResultSet rs) throws SQLException { return new Course(rs.getString("code"), rs.getString("title"), rs.getInt("credits")); }
    protected void bindInsert(PreparedStatement ps, Course c) throws SQLException { ps.setString(1, c.code()); ps.setString(2, c.title()); ps.setInt(3, c.credits()); }
    protected void bindUpdate(PreparedStatement ps, Course c) throws SQLException { ps.setString(1, c.title()); ps.setInt(2, c.credits()); ps.setString(3, c.code()); }
    protected void bindKey(PreparedStatement ps, String id) throws SQLException { ps.setString(1, id); }
}
