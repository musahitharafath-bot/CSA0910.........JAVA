import java.io.*;
import java.sql.*;
import java.util.Properties;

/** Opens a connection to the LOCAL TEST database named in db.properties (url, user, password). */
final class Db {
    static Properties cfg() throws IOException {
        Properties p = new Properties();
        try (InputStream in = new FileInputStream(System.getProperty("db.config", "../db.properties"))) { p.load(in); }
        return p;
    }

    static Connection connect() throws Exception { return connect(""); }

    /** extra: additional URL parameters such as "rewriteBatchedStatements=true". */
    static Connection connect(String extra) throws Exception {
        Properties p = cfg(); String url = p.getProperty("url");
        if (!extra.isEmpty()) url += (url.contains("?") ? "&" : "?") + extra;
        return DriverManager.getConnection(url, p.getProperty("user"), p.getProperty("password"));
    }

    static void run(Connection c, String sql) throws SQLException { try (Statement s = c.createStatement()) { s.execute(sql); } }

    /** Runs every statement of an SQL script file (statements end with a semicolon at the end of a line; -- comments are ignored). */
    static void runScript(Connection c, java.nio.file.Path script) throws Exception {
        StringBuilder sb = new StringBuilder();
        for (String line : java.nio.file.Files.readAllLines(script)) {
            if (line.trim().startsWith("--") || line.trim().isEmpty()) continue;
            sb.append(line).append('\n');
            if (line.trim().endsWith(";")) { String sql = sb.toString().trim(); sb.setLength(0); run(c, sql.substring(0, sql.length() - 1)); }
        }
    }

    static long count(Connection c, String table) throws SQLException {
        try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT COUNT(*) FROM " + table)) { rs.next(); return rs.getLong(1); }
    }
}
