/** Entity: one row of the student table (A3.3). */
final class Student {
    final String regNo;     // PRIMARY KEY  <-> column reg_no  VARCHAR(12)
    String name;            //                  column name    VARCHAR(60) NOT NULL
    String dept;            //                  column dept    VARCHAR(20)
    double cgpa;            //                  column cgpa    DECIMAL(4,2)
    Student(String regNo, String name, String dept, double cgpa) { this.regNo = regNo; this.name = name; this.dept = dept; this.cgpa = cgpa; }
    @Override public String toString() { return regNo + " " + name + " " + dept + " " + cgpa; }
}
