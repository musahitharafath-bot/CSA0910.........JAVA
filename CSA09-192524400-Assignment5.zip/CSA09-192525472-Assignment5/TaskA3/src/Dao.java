import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

/** A3.2: the generic data-access interface. T = the entity (Student), K = the type of its primary key. */
interface Dao<T, K> {
    void insert(T entity) throws SQLException;
    Optional<T> findById(K id) throws SQLException;
    List<T> findAll() throws SQLException;
    boolean update(T entity) throws SQLException;
    boolean delete(K id) throws SQLException;
}
