import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** Third inline class: the report reads the same table again with yet another copy of the column names. */
class InlineReportService {
    final Connection con;
    InlineReportService(Connection con) { this.con = con; }

    List<Student> allStudents() throws SQLException {
        List<Student> out = new ArrayList<>();
        Statement st = null; ResultSet rs = null;
        try {
            st = con.createStatement();
            rs = st.executeQuery("SELECT reg_no, name, dept, cgpa FROM student ORDER BY reg_no");
            while (rs.next()) out.add(new Student(rs.getString("reg_no"), rs.getString("name"), rs.getString("dept"), rs.getDouble("cgpa")));
        } finally { if (rs != null) rs.close(); if (st != null) st.close(); }
        return out;
    }

    int countAbove(double cgpa) throws SQLException {
        PreparedStatement ps = null; ResultSet rs = null;
        try {
            ps = con.prepareStatement("SELECT COUNT(*) FROM student WHERE cgpa > ?");
            ps.setDouble(1, cgpa); rs = ps.executeQuery(); rs.next(); return rs.getInt(1);
        } finally { if (rs != null) rs.close(); if (ps != null) ps.close(); }
    }
}
