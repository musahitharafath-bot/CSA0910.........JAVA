import java.sql.*;

/** Second inline class: a "GUI" handler that also needs students, so it has its own copy of the SQL. */
class InlineAdmissionsScreen {
    final Connection con;
    InlineAdmissionsScreen(Connection con) { this.con = con; }

    boolean onUpdateCgpa(String regNo, double cgpa) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = con.prepareStatement("UPDATE student SET cgpa = ? WHERE reg_no = ?");
            ps.setDouble(1, cgpa); ps.setString(2, regNo);
            return ps.executeUpdate() == 1;
        } finally { if (ps != null) ps.close(); }
    }

    String onShowStudent(String regNo) throws SQLException {
        PreparedStatement ps = null; ResultSet rs = null;
        try {
            ps = con.prepareStatement("SELECT name, cgpa FROM student WHERE reg_no = ?");
            ps.setString(1, regNo); rs = ps.executeQuery();
            return rs.next() ? rs.getString("name") + " (" + rs.getDouble("cgpa") + ")" : "not found";
        } finally { if (rs != null) rs.close(); if (ps != null) ps.close(); }
    }
}
