import java.nio.file.*;
import java.sql.*;
import java.util.*;

/** A3: the generic Dao in use, then the cost per operation of the Dao design against inline SQL, then the cost of a column rename. */
public class DaoDemo {
    static int countIn(String[] files, String token) throws Exception {
        int n = 0;
        for (String f : files) for (String line : Files.readAllLines(Path.of("src/" + f))) if (line.contains("\"") && line.contains(token)) n++;
        return n;
    }

    public static void main(String[] args) throws Exception {
        String out = args.length > 0 ? args[0] : "output";
        Files.createDirectories(Path.of(out));
        try (Connection con = Db.connect()) {
            Db.runScript(con, Path.of("schema.sql"));
            StudentDao sd = new StudentDao(con); CourseDao cd = new CourseDao(con); MarksDao md = new MarksDao(con);
            System.out.println("=== The same generic code serves three tables");
            sd.insert(new Student("192311001", "Arun Kumar", "CSE", 8.45)); sd.insert(new Student("192311002", "Divya Raman", "ECE", 9.10));
            cd.insert(new Course("CSA09", "Programming in Java", 4));
            md.insert(new Mark("192311001", "CSA09", 88));
            System.out.println("StudentDao.findById(192311001) = " + sd.findById("192311001").orElse(null));
            System.out.println("StudentDao.findById(000000000) = " + sd.findById("000000000").orElse(null));
            sd.update(new Student("192311001", "Arun Kumar", "CSE", 8.60));
            System.out.println("after update               = " + sd.findById("192311001").get());
            System.out.println("CourseDao.findAll()        = " + cd.findAll());
            System.out.println("MarksDao.findById(MarkKey) = " + md.findById(new MarkKey("192311001", "CSA09")).get());
            System.out.println("StudentDao.delete(192311002) -> " + sd.delete("192311002") + ", findAll() now has " + sd.findAll().size() + " row(s)");

            // ---- cost per operation: Dao versus inline SQL (same connection, same SQL, same driver calls)
            Db.run(con, "DELETE FROM marks"); Db.run(con, "DELETE FROM student");
            try (PreparedStatement ps = con.prepareStatement("INSERT INTO student(reg_no, name, dept, cgpa) VALUES (?, ?, ?, ?)")) {
                con.setAutoCommit(false);
                for (int i = 1; i <= 1000; i++) { ps.setString(1, String.format("1923%08d", i)); ps.setString(2, "Student " + i); ps.setString(3, "CSE"); ps.setDouble(4, 6 + (i % 40) / 10.0); ps.addBatch(); }
                ps.executeBatch(); con.commit(); con.setAutoCommit(true);
            }
            InlineStudentService svc = new InlineStudentService(con); InlineReportService rep = new InlineReportService(con);
            Random r = new Random(4); String[] ids = new String[20000]; for (int i = 0; i < ids.length; i++) ids[i] = String.format("1923%08d", 1 + r.nextInt(1000));
            Runnable daoFind = () -> { try { long s = 0; for (int i = 0; i < 2000; i++) s += sd.findById(ids[i]).get().name.length(); Bench.sink = s; } catch (SQLException e) { throw new RuntimeException(e); } };
            Runnable inlFind = () -> { try { long s = 0; for (int i = 0; i < 2000; i++) s += svc.find(ids[i]).name.length(); Bench.sink = s; } catch (SQLException e) { throw new RuntimeException(e); } };
            Runnable daoAll = () -> { try { Bench.sink = sd.findAll().size(); } catch (SQLException e) { throw new RuntimeException(e); } };
            Runnable inlAll = () -> { try { Bench.sink = rep.allStudents().size(); } catch (SQLException e) { throw new RuntimeException(e); } };
            System.out.println("\n=== Cost per operation (same connection; the two designs are timed alternately, 10 warm-ups, then 20 repetitions each)");
            System.out.printf("%-24s %-11s %12s %10s %10s %14s%n", "operation", "design", "mean us/op", "sd", "median", "bytes/op");
            try (java.io.PrintWriter csv = new java.io.PrintWriter(out + "/a3_cost.csv")) {
                csv.println("operation,design,mean_us_per_op,sd_us,median_us,bytes_per_op");
                Object[][] pairs = {{"findById (2,000 calls)", daoFind, inlFind, 2000}, {"findAll (1,000 rows)", daoAll, inlAll, 1}};
                for (Object[] o : pairs) {
                    Runnable d = (Runnable) o[1], in = (Runnable) o[2]; int per = (Integer) o[3];
                    for (int i = 0; i < 10; i++) { d.run(); in.run(); }
                    double[] td = new double[20], ti = new double[20];
                    for (int i = 0; i < 20; i++) { long t0 = System.nanoTime(); d.run(); td[i] = System.nanoTime() - t0; t0 = System.nanoTime(); in.run(); ti[i] = System.nanoTime() - t0; }
                    long bd = Bench.allocated(d), bi = Bench.allocated(in);
                    String[] names = {"Dao", "inline SQL"}; double[][] ts = {td, ti}; long[] bs = {bd, bi};
                    for (int k = 0; k < 2; k++) {
                        csv.printf("\"%s\",%s,%.2f,%.2f,%.2f,%d%n", o[0], names[k], Bench.mean(ts[k]) / per / 1000, Bench.stdev(ts[k]) / per / 1000, Bench.median(ts[k]) / per / 1000, bs[k] / per);
                        System.out.printf("%-24s %-11s %12.2f %10.2f %10.2f %14d%n", o[0], names[k], Bench.mean(ts[k]) / per / 1000, Bench.stdev(ts[k]) / per / 1000, Bench.median(ts[k]) / per / 1000, bs[k] / per);
                    }
                }
            }
            System.out.println("(findAll rows: us/op is for the whole 1,000-row query)");
        }

        // ---- impact of renaming the column cgpa
        String[] dao = {"JdbcDao.java", "StudentDao.java", "CourseDao.java", "MarksDao.java", "Dao.java"};
        String[] inl = {"InlineStudentService.java", "InlineAdmissionsScreen.java", "InlineReportService.java"};
        System.out.println("\n=== If the column cgpa is renamed: where must the source change?");
        int dl = countIn(dao, "cgpa"), il = countIn(inl, "cgpa");
        int dFiles = 0, iFiles = 0; for (String f : dao) if (countIn(new String[]{f}, "cgpa") > 0) dFiles++; for (String f : inl) if (countIn(new String[]{f}, "cgpa") > 0) iFiles++;
        System.out.printf("Dao design : %d class(es), %d line(s) with the column name in an SQL string%n", dFiles, dl);
        System.out.printf("Inline SQL : %d class(es), %d line(s) with the column name in an SQL string%n", iFiles, il);
        try (java.io.PrintWriter csv = new java.io.PrintWriter(out + "/a3_rename.csv")) { csv.println("design,classes_to_change,sql_lines_to_change"); csv.println("Dao," + dFiles + "," + dl); csv.println("inline," + iFiles + "," + il); }
    }
}
