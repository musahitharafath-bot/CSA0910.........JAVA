import java.sql.*;
import java.util.regex.Pattern;

/** The login check of Task A5.2 in five forms. Each returns the role of the logged-in user, or null if the login is refused. */
final class Login {
    final Connection con;
    Login(Connection con) { this.con = con; }

    /** (1) The ORIGINAL design: the SQL is built by concatenation. */
    String unsafe(String id, String pwd) throws SQLException {
        String sql = "SELECT * FROM users WHERE id='" + id + "' AND pwd='" + pwd + "'";
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) { return rs.next() ? rs.getString("id") + "/" + rs.getString("role") : null; }
    }

    /** (2) The redesign: PreparedStatement - the SQL text is fixed, the values are sent as data. */
    String safe(String id, String pwd) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement("SELECT id, role FROM users WHERE id = ? AND pwd = ?")) {
            ps.setString(1, id); ps.setString(2, pwd);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getString("id") + "/" + rs.getString("role") : null; }
        }
    }

    /** (3) Alternative: escape by doubling every quote (the SQL standard way), then concatenate. */
    static String doubleQuotes(String s) { return s.replace("'", "''"); }
    String escapedByDoubling(String id, String pwd) throws SQLException { return unsafe(doubleQuotes(id), doubleQuotes(pwd)); }

    /** (4) Alternative: escape by putting a backslash before a quote (a common mistake), then concatenate. */
    static String backslashQuotes(String s) { return s.replace("'", "\\'"); }
    String escapedByBackslash(String id, String pwd) throws SQLException { return unsafe(backslashQuotes(id), backslashQuotes(pwd)); }

    /** (5) Alternative: validate with a regular expression (whitelist), then concatenate. */
    static final Pattern ID = Pattern.compile("[A-Za-z0-9_]{3,20}");
    static final Pattern PWD = Pattern.compile("[A-Za-z0-9@#$%^&*!._-]{4,30}");
    String validatedByRegex(String id, String pwd) throws SQLException {
        if (!ID.matcher(id).matches() || !PWD.matcher(pwd).matches()) return null;       // refused before reaching the database
        return unsafe(id, pwd);
    }
}
