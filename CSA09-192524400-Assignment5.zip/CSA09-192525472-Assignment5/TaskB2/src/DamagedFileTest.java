import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;

/** B2: a deliberately damaged bus-pass file and how the file store responds to every kind of damage. */
public class DamagedFileTest {
    /** A line with a CORRECT checksum but the given field values (so that the value checks, not the checksum, must catch it). */
    static String line(String... f) { String body = String.join(",", f); return body + "," + PassCodec.crc(body); }

    public static void main(String[] args) throws Exception {
        String out = args.length > 0 ? args[0] : "output";
        Files.createDirectories(Path.of(out));
        Path f = Files.createTempFile("damaged", ".txt");
        List<String> lines = new ArrayList<>();
        lines.add(PassCodec.HEADER);
        lines.add(PassCodec.encode(new BusPass("P000001", "192311001", "Arun Kumar", 12, "Tambaram", LocalDate.of(2027, 3, 31), 4500)));           // 2  good
        lines.add("P000002,192311002,Divya Raman,7");                                                                                            // 3  wrong number of fields (4)
        lines.add(line("P000003", "192311003", "Karthik Nair", "9", "Guindy", "2027-03-31", "4l00"));                                          // 4  non-numeric amount
        lines.add("");                                                                                                                           // 5  empty line
        lines.add(PassCodec.encode(new BusPass("P000004", "192311004", "Meena, R", 7, "Adyar", LocalDate.of(2027, 3, 31), 3800)));              // 6  good (name has a comma)
        lines.add(line("P000005", "192311005", "Rahul Das", "9", "Porur", "2027-03-31", "-250.00"));                                           // 7  negative amount
        lines.add(line("P000006", "192311006", "Priya Menon", "nine", "Avadi", "2027-03-31", "4100.00"));                                      // 8  route is not a number
        lines.add(line("P000007", "192311007", "Suresh Iyer", "9", "Koyambedu", "31-03-2027", "4100.00"));                                     // 9  date in the wrong format
        lines.add("P000008,192311008,\"Anitha Pillai,9,Saidapet,2027-03-31,4100.00,00000000");                                                 // 10 quote never closed
        lines.add(PassCodec.encode(new BusPass("P000009", "192311009", "Vikram Reddy", 3, "Velachery", LocalDate.of(2027, 3, 31), 4000)).replace("4000.00", "4900.00")); // 11 amount changed after the checksum
        lines.add(PassCodec.encode(new BusPass("P000010", "192311010", "Imran Hussain", 5, "T Nagar", LocalDate.of(2027, 3, 31), 4200)));       // 12 good
        lines.add(PassCodec.encode(new BusPass("P000010", "192311011", "Farah Das", 5, "Guindy", LocalDate.of(2027, 3, 31), 9999)));            // 13 same pass ID again (duplicate)
        Files.write(f, (String.join("\n", lines) + "\n").getBytes(StandardCharsets.UTF_8));
        Files.write(f, new byte[]{(byte) 'P', '0', '0', '0', '0', '1', '1', ',', (byte) 0xC3, (byte) 0x28, (byte) 0xFF, '\n'}, StandardOpenOption.APPEND);   // 14 illegal UTF-8 bytes
        Files.writeString(f, PassCodec.encode(new BusPass("P000012", "192311012", "Deepa Nair", 8, "Mangadu", LocalDate.of(2027, 3, 31), 4000)).substring(0, 40), StandardOpenOption.APPEND);   // 15 half-written last line (no newline)

        BusPassFileStore s = new BusPassFileStore(f);
        BusPassFileStore.ScanResult r = s.scanAll();
        System.out.println("File with " + r.lines + " lines (including the header). Response of the store to every line:\n");
        List<String> all = Files.readAllLines(f, StandardCharsets.ISO_8859_1);
        Set<Integer> bad = new HashSet<>(); Map<Integer, String> why = new HashMap<>();
        for (BusPassFileStore.Damaged d : r.damaged) { bad.add(d.lineNo()); why.put(d.lineNo(), d.reason()); }
        System.out.printf("%-5s %-9s %-62s %s%n", "line", "status", "content (shortened)", "reason");
        for (int i = 0; i < all.size(); i++) {
            String t = all.get(i); t = t.length() > 60 ? t.substring(0, 57) + "..." : t;
            String st = i == 0 ? "header" : bad.contains(i + 1) ? "SKIPPED" : "accepted";
            System.out.printf("%-5d %-9s %-62s %s%n", i + 1, st, t, bad.contains(i + 1) ? why.get(i + 1) : "");
        }
        System.out.println("\nValid passes read: " + r.passes.size() + ", damaged lines reported: " + r.damaged.size());
        System.out.println("find P000004 (name with comma, after damage)  -> " + s.find("P000004").map(x -> x.name).orElse("not found"));
        System.out.println("find P000010 (appears twice, lines 12 and 13)   -> amount " + s.find("P000010").map(x -> String.valueOf(x.amount)).orElse("not found") + "  (the FIRST valid line wins; the duplicate is NOT detected by the file store)");
        System.out.println("passes with ID P000010 in the valid list         -> " + r.passes.stream().filter(p -> p.passId.equals("P000010")).count());
        System.out.println("find P000012 (half-written last line)          -> " + s.find("P000012").map(x -> x.name).orElse("not found"));
        Files.delete(f);
    }
}
