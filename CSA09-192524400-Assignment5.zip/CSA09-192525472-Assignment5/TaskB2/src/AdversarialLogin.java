import java.io.PrintWriter;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/** B2: constructed inputs against the unsafe login and against the alternatives; then the cost of each check per query. */
public class AdversarialLogin {
    interface Check { String run(String id, String pwd) throws SQLException; }

    static String show(Check c, String id, String pwd) {
        try { String r = c.run(id, pwd); return r == null ? "REJECTED" : "ACCEPTED as " + r; }
        catch (SQLException e) { return "SQL ERROR (" + e.getClass().getSimpleName() + ")"; }
    }

    public static void main(String[] args) throws Exception {
        String out = args.length > 0 ? args[0] : "output";
        Files.createDirectories(Path.of(out));
        try (Connection con = Db.connect()) {
            Db.runScript(con, Path.of("schema.sql"));
            Login lg = new Login(con);
            System.out.println("Users in the test table: admin (password Adm1n#Secret), arun (a1b2c3), meera (it's#42). The attacker knows NO password.\n");
            String[][] cases = {
                {"A  normal valid login", "arun", "a1b2c3"},
                {"B  wrong password", "arun", "wrong"},
                {"C  comment out the password test", "admin' -- ", "anything"},
                {"D  tautology in the password", "arun", "' OR '1'='1"},
                {"E  tautology, any user name", "nobody", "x' OR 1=1 -- "},
                {"F  stacked statement (DROP TABLE)", "x'; DROP TABLE users; -- ", "x"},
                {"G  breaks quote-doubling: id ends with \\", "x\\", " OR 1=1 -- "},
                {"H  breaks backslash-escaping: \\' in password", "arun", "\\' OR 1=1 -- "},
                {"I  valid password that contains a quote", "meera", "it's#42"}};
            String[] names = {"unsafe (concatenation)", "PreparedStatement", "escape: double quotes", "escape: backslash+quote", "regex whitelist"};
            Check[] checks = {lg::unsafe, lg::safe, lg::escapedByDoubling, lg::escapedByBackslash, lg::validatedByRegex};
            try (PrintWriter csv = new PrintWriter(out + "/b2_login_matrix.csv")) {
                csv.println("case,id,pwd,variant,result");
                for (String[] c : cases) {
                    System.out.println(c[0] + "   id = [" + c[1] + "]   pwd = [" + c[2] + "]");
                    for (int i = 0; i < checks.length; i++) {
                        String r = show(checks[i], c[1], c[2]);
                        System.out.printf("      %-26s %s%n", names[i], r);
                        csv.printf("\"%s\",\"%s\",\"%s\",\"%s\",\"%s\"%n", c[0], c[1].replace("\"", "\"\""), c[2].replace("\"", "\"\""), names[i], r);
                    }
                }
            }
            // the query that the unsafe code really sends for cases C and D
            System.out.println("\nSQL sent by the unsafe code for case C: SELECT * FROM users WHERE id='admin' -- ' AND pwd='anything'");
            System.out.println("SQL sent by the unsafe code for case D: SELECT * FROM users WHERE id='arun' AND pwd='' OR '1'='1'");
            try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM users")) { rs.next(); System.out.println("Rows in users after case F (DROP TABLE attempt): " + rs.getInt(1) + " (the driver refuses a second statement unless allowMultiQueries=true is set)"); }

            // ---- time cost per query: all variants are timed in turn, round after round, so that warm-up and noise affect all alike
            System.out.println("\n=== Cost per login check (valid login of arun; 2,000 checks per run; 3 warm-up rounds, then 9 measured rounds)");
            final int N = 2000;
            try (PrintWriter csv = new PrintWriter(out + "/b2_cost.csv"); Connection c2 = Db.connect("useServerPrepStmts=true")) {
                Login l2 = new Login(c2);
                String[] tn = {"unsafe Statement (no protection)", "PreparedStatement (driver default, client-side)", "PreparedStatement (server-side prepare)", "regex check + Statement"};
                Check[] timed = {lg::unsafe, lg::safe, l2::safe, lg::validatedByRegex};
                double[][] t = new double[timed.length][9];
                for (int round = -3; round < 9; round++)
                    for (int v = 0; v < timed.length; v++) {
                        long a0 = System.nanoTime(); for (int k = 0; k < N; k++) timed[v].run("arun", "a1b2c3"); double ns = System.nanoTime() - a0;
                        if (round >= 0) t[v][round] = ns / N;
                    }
                csv.println("variant,mean_us_per_check,sd_us,median_us");
                System.out.printf("%-48s %14s %10s %10s%n", "variant", "mean us/check", "sd", "median");
                for (int v = 0; v < timed.length; v++) {
                    System.out.printf("%-48s %14.2f %10.2f %10.2f%n", tn[v], Bench.mean(t[v]) / 1000, Bench.stdev(t[v]) / 1000, Bench.median(t[v]) / 1000);
                    csv.printf("\"%s\",%.3f,%.3f,%.3f%n", tn[v], Bench.mean(t[v]) / 1000, Bench.stdev(t[v]) / 1000, Bench.median(t[v]) / 1000);
                }
                double[] rx = Bench.measure(() -> { for (int k = 0; k < 200000; k++) Bench.sink += (Login.ID.matcher("arun").matches() ? 1 : 0) + (Login.PWD.matcher("a1b2c3").matches() ? 1 : 0); }, 3, 7);
                double[] es = Bench.measure(() -> { for (int k = 0; k < 200000; k++) Bench.sink += Login.doubleQuotes("arun").length() + Login.doubleQuotes("a1b2c3").length(); }, 3, 7);
                System.out.printf("%-48s %14.3f %10.3f%n", "regex validation alone (no query)", Bench.mean(rx) / 200000 / 1000, Bench.stdev(rx) / 200000 / 1000);
                System.out.printf("%-48s %14.3f %10.3f%n", "quote escaping alone (no query)", Bench.mean(es) / 200000 / 1000, Bench.stdev(es) / 200000 / 1000);
                csv.printf("\"regex validation alone (no query)\",%.4f,%.4f,%.4f%n", Bench.mean(rx) / 200000 / 1000, Bench.stdev(rx) / 200000 / 1000, Bench.median(rx) / 200000 / 1000);
                csv.printf("\"quote escaping alone (no query)\",%.4f,%.4f,%.4f%n", Bench.mean(es) / 200000 / 1000, Bench.stdev(es) / 200000 / 1000, Bench.median(es) / 200000 / 1000);
            }
            Db.run(con, "DROP TABLE users");
        }
    }
}
