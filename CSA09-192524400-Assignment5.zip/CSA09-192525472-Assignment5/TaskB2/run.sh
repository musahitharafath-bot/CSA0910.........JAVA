#!/bin/sh
# Compile and run TaskB2
cd "$(dirname "$0")"
mkdir -p out output
javac -cp "../lib/*" -d out src/*.java
java -cp "out:../lib/*" AdversarialLogin output | tee output/AdversarialLogin_output.txt
java -cp "out:../lib/*" DamagedFileTest output | tee output/DamagedFileTest_output.txt
rm -rf out
