-- Task B2: users table of the LOCAL TEST database. Passwords are stored in clear text ONLY because this is a demonstration of a weak design;
-- a real system stores a salted hash (for example PBKDF2 or bcrypt).
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id   VARCHAR(20) NOT NULL PRIMARY KEY,
    pwd  VARCHAR(40) NOT NULL,
    role VARCHAR(10) NOT NULL
) ENGINE=InnoDB;
INSERT INTO users VALUES ('admin', 'Adm1n#Secret', 'ADMIN');
INSERT INTO users VALUES ('arun', 'a1b2c3', 'STUDENT');
INSERT INTO users VALUES ('meera', 'it''s#42', 'STUDENT');
