#!/bin/sh
# A4.2: write a file with one version of Resident and read it with the other, with and without an explicit serialVersionUID.
cd "$(dirname "$0")"
rm -rf work; mkdir -p work
gen() {   # $1 = uid mode (none|fixed), $2 = version (v1|v2)
  d=work/$1_$2; mkdir -p $d
  if [ "$1" = fixed ]; then UID_LINE='private static final long serialVersionUID = 1L;'; else UID_LINE=''; fi
  if [ "$2" = v2 ]; then PF='String phone;'; PS='+ (phone == null ? ", phone=null" : ", phone=" + phone)'; else PF=''; PS=''; fi
  sed -e "s|/\*UID\*/|$UID_LINE|" -e "s|/\*PHONE_FIELD\*/|$PF|" -e "s|/\*PHONE_STR\*/|$PS|" ResidentTemplate.java > $d/Resident.java
  cp Write.java Read.java $d/
  javac -d $d $d/*.java 2>&1 | grep -v JAVA_TOOL_OPTIONS
}
for uid in none fixed; do
  for v in v1 v2; do gen $uid $v; done
  echo "--- serialVersionUID: $uid"
  echo " old file (v1, no phone) read by new class (v2, with phone):"
  java -cp work/${uid}_v1 Write work/${uid}_old.ser 2>&1 | grep -v JAVA_TOOL_OPTIONS
  java -cp work/${uid}_v2 Read work/${uid}_old.ser 2>&1 | grep -v JAVA_TOOL_OPTIONS
  echo " new file (v2, with phone) read by old class (v1):"
  java -cp work/${uid}_v2 Write work/${uid}_new.ser 2>&1 | grep -v JAVA_TOOL_OPTIONS
  java -cp work/${uid}_v1 Read work/${uid}_new.ser 2>&1 | grep -v JAVA_TOOL_OPTIONS
done
rm -rf work
