import java.io.Serializable;

public class Resident implements Serializable {
    /*UID*/
    final String name, regNo;
    /*PHONE_FIELD*/
    Resident(String name, String regNo) { this.name = name; this.regNo = regNo; }
    @Override public String toString() { return name + " (" + regNo + ")" /*PHONE_STR*/; }
}
