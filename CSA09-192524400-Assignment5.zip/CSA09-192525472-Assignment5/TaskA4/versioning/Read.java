import java.io.*;
import java.util.*;

public class Read {
    public static void main(String[] a) throws Exception {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(a[0]))) {
            List<?> l = (List<?>) in.readObject();
            System.out.println("   read OK: " + l);
        } catch (InvalidClassException e) { System.out.println("   java.io.InvalidClassException: " + e.getMessage()); }
    }
}
