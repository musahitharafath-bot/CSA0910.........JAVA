import java.io.*;
import java.util.*;

public class Write {
    public static void main(String[] a) throws Exception {
        List<Resident> l = new ArrayList<>(List.of(new Resident("Arun Kumar", "192311001"), new Resident("Divya Raman", "192311002")));
        try (ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(a[0]))) { o.writeObject(l); }
        System.out.println("   wrote " + l.size() + " residents to " + a[0]);
    }
}
