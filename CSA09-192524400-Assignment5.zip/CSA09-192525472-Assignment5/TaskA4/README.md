# TaskA4 - Assignment 5 (CO5), Programming in Java

**Student:** Syed Aakif Hussain S A  |  **Register number:** 192525472

Serialization: transient, NotSerializableException, shared references, serialVersionUID versioning, and CSV vs JSON vs Java serialization.

## Environment
- Compiled and run with Java 21.0.12.1
- Gson jar is in ../lib. Versioning demo is in versioning/ (run_versions.sh).
- Test database for the reported results: MariaDB 10.11 with MariaDB Connector/J (MySQL-compatible). Edit `../db.properties` to use your own MySQL.

## Folder contents
- `src/` - Java source code
- `output/` - program output (`*_output.txt`), console screenshots (`*_console.png`), CSV data and charts
- `run.sh` - compiles and runs everything in this task

## How to run
```
sh run.sh
```
Or by hand: `javac -cp "../lib/*" -d out src/*.java` then `java -cp "out:../lib/*" <MainClass> output`.

## Programs and results
- `SerialDemo` -> `output/SerialDemo_output.txt` and `output/SerialDemo_console.png`
- `FormatBench` -> `output/FormatBench_output.txt` and `output/FormatBench_console.png`

Data files and charts written to `output/`: `a4_formats.csv`, `chart_a4_formats.png`.

Timings are from a shared 2-vCPU machine and vary by run. Compare ratios and trends, not single numbers.
