#!/bin/sh
# Compile and run TaskA4
cd "$(dirname "$0")"
mkdir -p out output
javac -cp "../lib/*" -d out src/*.java
java -cp "out:../lib/*" SerialDemo | tee output/SerialDemo_output.txt
sh versioning/run_versions.sh | tee output/Versions_output.txt
java -cp "out:../lib/*" FormatBench output | tee output/FormatBench_output.txt
rm -rf out
