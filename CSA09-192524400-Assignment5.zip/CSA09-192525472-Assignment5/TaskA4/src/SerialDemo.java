import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.Connection;
import java.util.*;

/** A4.1: what is written when a Hostel is serialized, and why password and Connection must be transient. */
public class SerialDemo {
    static byte[] save(Object o) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try (ObjectOutputStream out = new ObjectOutputStream(bo)) { out.writeObject(o); }
        return bo.toByteArray();
    }
    static Object load(byte[] b) throws Exception { try (ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(b))) { return in.readObject(); } }
    static boolean contains(byte[] hay, String needle) { return new String(hay, StandardCharsets.ISO_8859_1).contains(needle); }

    public static void main(String[] args) throws Exception {
        try (Connection con = Db.connect()) {
            System.out.println("=== 1. WRONG design: password and Connection are ordinary fields");
            try { save(new ResidentBad("Arun Kumar", "192311001", "S3cret-Pass", con)); System.out.println("saved (unexpected)"); }
            catch (NotSerializableException e) { System.out.println("save fails: java.io.NotSerializableException: " + e.getMessage()); }
            byte[] bad = save(new ResidentBad("Arun Kumar", "192311001", "S3cret-Pass", null));          // Connection left null so that saving is possible
            System.out.println("with the Connection left null the save works, but the file contains the password in clear text: " + contains(bad, "S3cret-Pass"));

            System.out.println("\n=== 2. RIGHT design: password and Connection are transient");
            Hostel h = new Hostel("Kaveri Hostel");
            Resident rep = null;
            for (int r = 101; r <= 103; r++) {
                Room room = new Room(r);
                for (int k = 1; k <= 2; k++) { Resident x = new Resident("Resident " + r + "-" + k, "1923" + r + k, "pw" + r + k, con); room.residents.add(x); if (rep == null) rep = x; }
                h.rooms.add(room);
            }
            h.representative = rep;
            byte[] data = save(h);
            int residents = h.rooms.stream().mapToInt(x -> x.residents.size()).sum();
            System.out.println("Object graph: 1 Hostel -> " + h.rooms.size() + " Room objects -> " + residents + " Resident objects, one Resident is shared (representative and room 101)");
            System.out.println("Bytes written: " + data.length + "; contains any password: " + contains(data, "pw101"));
            Hostel g = (Hostel) load(data);
            System.out.println("Loaded: " + g.name + ", rooms " + g.rooms.size() + ", residents " + g.rooms.stream().mapToInt(x -> x.residents.size()).sum());
            Resident first = g.rooms.get(0).residents.get(0);
            System.out.println("First resident after loading: " + first);
            System.out.println("Shared reference preserved (representative == first resident of room 101): " + (g.representative == first));
            System.out.println("Original and copy are different objects: " + (g != h));
        }
    }
}
