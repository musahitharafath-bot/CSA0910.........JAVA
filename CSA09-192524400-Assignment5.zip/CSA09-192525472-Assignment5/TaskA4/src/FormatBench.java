import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** A4 alternative: the same residents saved as Java serialization, CSV and JSON - size, save time, load time, and a new field. */
public class FormatBench {
    static class R implements Serializable {
        private static final long serialVersionUID = 1L;
        String name, regNo; int room; String phone; transient String password;
        R(String n, String r, int room, String phone) { name = n; regNo = r; this.room = room; this.phone = phone; }
    }
    static String q(String s) { return (s.indexOf(',') >= 0 || s.indexOf('"') >= 0) ? '"' + s.replace("\"", "\"\"") + '"' : s; }
    static List<String> split(String l) {
        List<String> o = new ArrayList<>(); StringBuilder c = new StringBuilder(); boolean in = false;
        for (int i = 0; i < l.length(); i++) { char ch = l.charAt(i);
            if (in) { if (ch == '"') { if (i + 1 < l.length() && l.charAt(i + 1) == '"') { c.append('"'); i++; } else in = false; } else c.append(ch); }
            else if (ch == '"') in = true; else if (ch == ',') { o.add(c.toString()); c.setLength(0); } else c.append(ch); }
        o.add(c.toString()); return o;
    }
    static void saveSer(List<R> l, Path f) throws IOException { try (ObjectOutputStream o = new ObjectOutputStream(new BufferedOutputStream(Files.newOutputStream(f), 1 << 16))) { o.writeObject(l); } }
    @SuppressWarnings("unchecked") static List<R> loadSer(Path f) throws Exception { try (ObjectInputStream i = new ObjectInputStream(new BufferedInputStream(Files.newInputStream(f), 1 << 16))) { return (List<R>) i.readObject(); } }
    static void saveCsv(List<R> l, Path f) throws IOException {
        try (BufferedWriter w = Files.newBufferedWriter(f)) { w.write("name,regNo,room,phone\n"); for (R r : l) { w.write(q(r.name) + "," + r.regNo + "," + r.room + "," + q(r.phone == null ? "" : r.phone) + "\n"); } }
    }
    static List<R> loadCsv(Path f) throws IOException {
        List<R> out = new ArrayList<>();
        try (BufferedReader r = Files.newBufferedReader(f)) { r.readLine(); String line;
            while ((line = r.readLine()) != null) { List<String> p = split(line); out.add(new R(p.get(0), p.get(1), Integer.parseInt(p.get(2)), p.size() > 3 && !p.get(3).isEmpty() ? p.get(3) : null)); } }
        return out;
    }
    static final Gson GSON = new Gson();
    static final Type LT = new TypeToken<List<R>>() { }.getType();
    static void saveJson(List<R> l, Path f) throws IOException { try (Writer w = new BufferedWriter(Files.newBufferedWriter(f), 1 << 16)) { GSON.toJson(l, LT, w); } }
    static List<R> loadJson(Path f) throws IOException { try (Reader r = new BufferedReader(Files.newBufferedReader(f), 1 << 16)) { return GSON.fromJson(r, LT); } }

    public static void main(String[] args) throws Exception {
        String out = args.length > 0 ? args[0] : "output";
        Files.createDirectories(Path.of(out));
        System.out.printf("%-9s %-20s %12s %12s %12s %12s%n", "residents", "format", "file bytes", "save ms", "load ms", "bytes/res");
        try (PrintWriter csv = new PrintWriter(out + "/a4_formats.csv")) {
            csv.println("residents,format,file_bytes,bytes_per_resident,save_ms,save_sd,load_ms,load_sd");
            for (int n : new int[]{1000, 10000, 100000}) {
                Random r = new Random(6); List<R> l = new ArrayList<>(n);
                for (int i = 0; i < n; i++) { String nm = DataGen.FIRST[r.nextInt(15)] + " " + DataGen.LAST[r.nextInt(10)]; if (i % 50 == 0) nm = DataGen.LAST[r.nextInt(10)] + ", " + DataGen.FIRST[r.nextInt(15)];
                    l.add(new R(nm, String.format("1923%05d", i), 100 + r.nextInt(300), i % 3 == 0 ? null : String.format("9%09d", r.nextInt(1000000000)))); }
                Object[][] fm = {{"Java serialization", (ThrowingSave) FormatBench::saveSer, (ThrowingLoad) FormatBench::loadSer}, {"CSV", (ThrowingSave) FormatBench::saveCsv, (ThrowingLoad) FormatBench::loadCsv}, {"JSON (Gson)", (ThrowingSave) FormatBench::saveJson, (ThrowingLoad) FormatBench::loadJson}};
                for (Object[] f : fm) {
                    Path p = Files.createTempFile("fmt", ".dat"); ThrowingSave sv = (ThrowingSave) f[1]; ThrowingLoad ld = (ThrowingLoad) f[2];
                    int warm = n >= 100000 ? 1 : 3, reps = n >= 100000 ? 5 : 9;
                    double[] s = Bench.measure(() -> { try { sv.save(l, p); } catch (Exception e) { throw new RuntimeException(e); } }, warm, reps);
                    double[] g = Bench.measure(() -> { try { Bench.sink += ld.load(p).size(); } catch (Exception e) { throw new RuntimeException(e); } }, warm, reps);
                    List<R> back = ld.load(p); if (back.size() != n || !back.get(7).regNo.equals(l.get(7).regNo)) throw new IllegalStateException("round trip failed for " + f[0]);
                    long size = Files.size(p);
                    csv.printf("%d,\"%s\",%d,%.1f,%.2f,%.2f,%.2f,%.2f%n", n, f[0], size, size / (double) n, Bench.mean(s) / 1e6, Bench.stdev(s) / 1e6, Bench.mean(g) / 1e6, Bench.stdev(g) / 1e6);
                    System.out.printf("%-9d %-20s %12d %12.1f %12.1f %12.1f%n", n, f[0], size, Bench.mean(s) / 1e6, Bench.mean(g) / 1e6, size / (double) n);
                    Files.delete(p);
                }
            }
        }
        // ---- a field is added: how does each format cope with a file written BEFORE the field existed?
        System.out.println("\n=== An old file (without the phone field) read by the new program");
        Path c = Files.createTempFile("old", ".csv"); Files.writeString(c, "name,regNo,room\nArun Kumar,192311001,101\n\"Raman, Meena\",192311002,102\n");
        try { List<R> x = loadCsv(c); System.out.println("CSV : read OK, phone = " + x.get(0).phone + " (the reader checks the column count and uses a default; a reader that assumes the new layout would fail with IndexOutOfBounds)"); }
        catch (Exception e) { System.out.println("CSV : " + e); }
        Path j = Files.createTempFile("old", ".json"); Files.writeString(j, "[{\"name\":\"Arun Kumar\",\"regNo\":\"192311001\",\"room\":101},{\"name\":\"Divya Raman\",\"regNo\":\"192311002\",\"room\":102}]");
        List<R> y = loadJson(j); System.out.println("JSON: read OK, phone = " + y.get(0).phone + " (a missing key simply stays null; an unknown key in a newer file is ignored)");
        System.out.println("Java serialization: see the versioning experiment (run_versions.sh): with a fixed serialVersionUID it reads OK, without one it throws InvalidClassException.");
        Files.delete(c); Files.delete(j);
    }
    interface ThrowingSave { void save(List<R> l, Path p) throws Exception; }
    interface ThrowingLoad { List<R> load(Path p) throws Exception; }
}
