import java.io.Serializable;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

/** A4.1 - the object graph of the hostel program, with the transient design applied. */
class Resident implements Serializable {
    private static final long serialVersionUID = 1L;
    final String name, regNo;
    transient String password;        // a secret: must never be written to a file; after loading it is null and must be asked for again
    transient Connection db;          // a live resource: Connection is not Serializable and has no meaning after a restart
    Resident(String name, String regNo, String password, Connection db) { this.name = name; this.regNo = regNo; this.password = password; this.db = db; }
    @Override public String toString() { return name + "(" + regNo + ", password=" + password + ", db=" + (db == null ? "null" : "open") + ")"; }
}

class Room implements Serializable {
    private static final long serialVersionUID = 1L;
    final int number; final List<Resident> residents = new ArrayList<>();
    Room(int number) { this.number = number; }
}

class Hostel implements Serializable {
    private static final long serialVersionUID = 1L;
    final String name; final List<Room> rooms = new ArrayList<>();
    Resident representative;           // the same Resident object is also in a room: the graph has a shared reference
    Hostel(String name) { this.name = name; }
}

/** The WRONG design: nothing is transient. Used only to show what goes wrong. */
class ResidentBad implements Serializable {
    private static final long serialVersionUID = 1L;
    final String name, regNo; String password; Connection db;
    ResidentBad(String name, String regNo, String password, Connection db) { this.name = name; this.regNo = regNo; this.password = password; this.db = db; }
}
