import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 * Runs the completed Converter.convert() (TODO 2) without a desktop: a Converter object is allocated without its
 * constructor (a JFrame cannot be created on a headless machine), real Swing field components are injected, and the
 * program's own private convert() method is invoked by reflection. The lambda wiring of TODO 1 is checked by the
 * compiler and by running Converter on a desktop (see README).
 */
public class ConverterCheck {
    static int passed, failed;
    static void check(String name, boolean ok) { System.out.println((ok ? "PASS " : "FAIL ") + name); if (ok) passed++; else failed++; }

    static void set(Object o, String field, Object value) throws Exception {
        Field f = Converter.class.getDeclaredField(field); f.setAccessible(true); f.set(o, value);
    }

    static void save(JPanel p, String file) throws Exception {
        java.awt.Dimension d = p.getPreferredSize();
        p.setSize(d.width + 20, d.height + 10);
        for (java.awt.Component c : new java.awt.Component[]{p}) p.doLayout();
        BufferedImage img = new BufferedImage(p.getWidth(), p.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics(); g.setColor(Color.WHITE); g.fillRect(0, 0, p.getWidth(), p.getHeight()); p.paint(g); g.dispose();
        ImageIO.write(img, "png", new File(file));
        System.out.println("   offscreen render of the converter components -> " + file);
    }

    public static void main(String[] args) throws Exception {
        Field uf = sun.misc.Unsafe.class.getDeclaredField("theUnsafe"); uf.setAccessible(true);
        sun.misc.Unsafe unsafe = (sun.misc.Unsafe) uf.get(null);
        Converter c = (Converter) unsafe.allocateInstance(Converter.class);
        JTextField amount = new JTextField(10);
        JComboBox<String> target = new JComboBox<>(new String[]{"USD", "EUR"});
        JLabel result = new JLabel(" ");
        set(c, "amount", amount); set(c, "target", target); set(c, "result", result);
        Method convert = Converter.class.getDeclaredMethod("convert"); convert.setAccessible(true);

        String[][] cases = {{"1000", "USD", "12.00 USD"}, {"1000", "EUR", "11.00 EUR"}, {"250.5", "USD", "3.01 USD"},
                {"abc", "USD", "Invalid amount"}, {"", "EUR", "Invalid amount"}, {"-5", "USD", "Invalid amount"}};
        // Preview panel with the same components in the same FlowLayout order as the Converter window
        JPanel preview = new JPanel(new FlowLayout());
        preview.add(new JLabel("INR")); preview.add(amount); preview.add(target); preview.add(new JButton("Convert")); preview.add(result);
        new File("output").mkdirs();
        int n = 1;
        for (String[] t : cases) {
            amount.setText(t[0]); target.setSelectedItem(t[1]);
            convert.invoke(c);
            System.out.println("amount='" + t[0] + "' to " + t[1] + " -> label shows '" + result.getText() + "'");
            check("T" + (n++) + " expected '" + t[2] + "'", result.getText().equals(t[2]));
            if (t[0].equals("1000") && t[1].equals("USD")) save(preview, "output/Converter_valid_conversion.png");
            if (t[0].equals("abc")) save(preview, "output/Converter_invalid_amount.png");
        }
        System.out.println(passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }
}
