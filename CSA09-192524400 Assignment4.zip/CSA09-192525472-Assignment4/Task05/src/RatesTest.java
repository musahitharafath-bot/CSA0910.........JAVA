public class RatesTest {
    static int passed, failed;
    static void check(String name, boolean ok) { System.out.println((ok ? "PASS " : "FAIL ") + name); if (ok) passed++; else failed++; }

    public static void main(String[] args) {
        check("T1 1000 INR -> 12.00 USD", Rates.convert("1000", "USD").equals("12.00 USD"));
        check("T2 1000 INR -> 11.00 EUR", Rates.convert("1000", "EUR").equals("11.00 EUR"));
        check("T3 decimal and spaces: ' 250.5 ' -> 3.01 USD", Rates.convert(" 250.5 ", "USD").equals("3.01 USD"));
        check("T4 letters -> Invalid amount", Rates.convert("abc", "USD").equals("Invalid amount"));
        check("T5 blank -> Invalid amount", Rates.convert("", "USD").equals("Invalid amount"));
        check("T6 negative -> Invalid amount", Rates.convert("-5", "EUR").equals("Invalid amount"));
        check("T7 NaN -> Invalid amount", Rates.convert("NaN", "EUR").equals("Invalid amount"));
        check("T8 zero -> 0.00 USD", Rates.convert("0", "USD").equals("0.00 USD"));
        System.out.println(passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }
}
