import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;

/** Alternative concept: ONE shared Action object is the single handler for the button, a menu item and Ctrl+Enter. */
public class ConverterShared extends JFrame {
    private final JTextField amount = new JTextField(10);
    private final JComboBox<String> target = new JComboBox<>(new String[]{"USD", "EUR"});
    private final JLabel result = new JLabel(" ");

    private final AbstractAction convertAction = new AbstractAction("Convert") {
        @Override public void actionPerformed(ActionEvent e) {
            result.setText(Rates.convert(amount.getText(), (String) target.getSelectedItem()));
        }
    };

    public ConverterShared() {
        super("Converter (shared Action)");
        setLayout(new FlowLayout());
        convertAction.putValue(javax.swing.Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control ENTER"));
        JMenuBar bar = new JMenuBar();
        JMenu menu = new JMenu("Actions");
        menu.add(new JMenuItem(convertAction));            // menu item uses the same Action
        bar.add(menu);
        setJMenuBar(bar);
        add(new JLabel("INR")); add(amount); add(target);
        add(new JButton(convertAction));                  // button uses the same Action
        amount.setAction(convertAction);                  // Enter key uses the same Action
        add(result);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
    }

    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new ConverterShared().setVisible(true)); }
}
