import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JTextField;

/** Counts listener objects needed for three triggers (button, menu item, Enter key): one handler each vs one shared Action. */
public class TriggerCount {
    public static void main(String[] args) {
        // Style (c) repeated for every trigger: three separate anonymous listener objects
        JButton b1 = new JButton("Convert"); JMenuItem m1 = new JMenuItem("Convert"); JTextField f1 = new JTextField();
        b1.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { } });
        m1.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { } });
        f1.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { } });
        System.out.println("One anonymous listener per trigger : distinct handler objects = " + distinct(b1, m1, f1));

        // One handler object reused by every trigger (what ConverterC2 / ConverterD2 do for two triggers)
        ActionListener shared = e -> { };
        JButton b2 = new JButton("Convert"); JMenuItem m2 = new JMenuItem("Convert"); JTextField f2 = new JTextField();
        b2.addActionListener(shared); m2.addActionListener(shared); f2.addActionListener(shared);
        System.out.println("One lambda stored in a variable    : distinct handler objects = " + distinct(b2, m2, f2));

        // Shared Action: text, accelerator and handler in one object
        AbstractAction action = new AbstractAction("Convert") { public void actionPerformed(ActionEvent e) { } };
        JButton b3 = new JButton(action); JMenuItem m3 = new JMenuItem(action); JTextField f3 = new JTextField(); f3.setAction(action);
        System.out.println("One shared Action                  : distinct handler objects = " + distinct(b3, m3, f3));
        System.out.println("Adding a 4th trigger: styles (a)-(c) need one more addActionListener line (a new object for (c) unless the handler is shared);");
        System.out.println("a shared Action needs one line, new JButton(action), with no new handler code and no duplicated text/enabled state.");
    }

    static int distinct(Object... components) {
        Set<Object> set = Collections.newSetFromMap(new IdentityHashMap<>());
        for (Object o : components) {
            ActionListener[] ls = o instanceof JButton b ? b.getActionListeners() : o instanceof JMenuItem m ? m.getActionListeners() : ((JTextField) o).getActionListeners();
            for (ActionListener l : ls) set.add(l);
        }
        return set.size();
    }
}
