/** Shared conversion rule used by the four style variants (A-D). */
public class Rates {
    static double rate(String currency) { return currency.equals("USD") ? 0.012 : 0.011; }

    /** Returns e.g. "12.00 USD", or "Invalid amount" for blank, non-numeric, negative or non-finite input. */
    public static String convert(String amountText, String currency) {
        try {
            double v = Double.parseDouble(amountText.trim());
            if (Double.isNaN(v) || Double.isInfinite(v) || v < 0) return "Invalid amount";
            return String.format("%.2f %s", v * rate(currency), currency);
        } catch (NumberFormatException ex) {
            return "Invalid amount";
        }
    }
}
