-- Task 6: Campus Event Registration - MySQL 8 schema and sample data
CREATE DATABASE IF NOT EXISTS campus_events CHARACTER SET utf8mb4;
USE campus_events;

CREATE TABLE IF NOT EXISTS events (
    event_id   INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(60) NOT NULL UNIQUE,
    event_date DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS registrations (
    reg_id        BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_id    VARCHAR(12) NOT NULL,
    student_name  VARCHAR(60) NOT NULL,
    email         VARCHAR(80) NOT NULL,
    event_id      INT NOT NULL,
    registered_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    -- Rule: a student cannot register twice for the same event. Enforced by the database itself,
    -- so even two clients racing each other cannot create a duplicate.
    CONSTRAINT uq_student_event UNIQUE (student_id, event_id),
    CONSTRAINT fk_reg_event FOREIGN KEY (event_id) REFERENCES events(event_id),
    INDEX idx_reg_event (event_id, reg_id)
);

INSERT INTO events (name, event_date) VALUES
    ('Hackathon', '2026-12-05'),
    ('Dance Fest', '2026-12-12'),
    ('Quiz Bowl', '2026-12-18'),
    ('Music Night', '2026-12-20');

INSERT INTO registrations (student_id, student_name, email, event_id)
SELECT '192525001', 'Anitha R', 'anitha@example.edu', event_id FROM events WHERE name = 'Hackathon';
INSERT INTO registrations (student_id, student_name, email, event_id)
SELECT '192525002', 'Karthik S', 'karthik@example.edu', event_id FROM events WHERE name = 'Dance Fest';

-- Queries used by JdbcRegistrationDao (all parameterised with PreparedStatement):
--   duplicate check : SELECT 1 FROM registrations r JOIN events e ON r.event_id=e.event_id WHERE r.student_id=? AND e.name=?
--   one page        : SELECT ... WHERE (? IS NULL OR e.name=?) ORDER BY r.reg_id LIMIT ? OFFSET ?
--   count           : SELECT COUNT(*) ... WHERE (? IS NULL OR e.name=?)
