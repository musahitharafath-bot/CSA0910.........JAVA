# Task06 - Design Challenge: Campus Event Registration Desktop Application

**Student:** Syed Aakif Hussain S A  |  **Register No.:** 192525472

## Contents

| Folder | What it holds |
|---|---|
| `src/` | Java source code |
| `input/` | No input file needed for this task |
| `output/` | Console output (`*_output.txt`), console screenshots (`*_console.png`) and, where the task has a screen, images of it |

## Source files

- `src/eventreg/app/LoadBench.java`
- `src/eventreg/app/Main.java`
- `src/eventreg/app/RegistrationTests.java`
- `src/eventreg/app/SampleData.java`
- `src/eventreg/app/ScreenshotHarness.java`
- `src/eventreg/dao/DaoException.java`
- `src/eventreg/dao/DuplicateRegistrationException.java`
- `src/eventreg/dao/InMemoryRegistrationDao.java`
- `src/eventreg/dao/JdbcRegistrationDao.java`
- `src/eventreg/dao/RegistrationDao.java`
- `src/eventreg/model/PageResult.java`
- `src/eventreg/model/Registration.java`
- `src/eventreg/service/RegistrationService.java`
- `src/eventreg/service/ValidationException.java`
- `src/eventreg/ui/AppPanel.java`
- `src/eventreg/ui/MainFrame.java`
- `src/eventreg/ui/RegisterForm.java`
- `src/eventreg/ui/RegistrationsView.java`

## Written answers

- `ANSWERS.md` - Stages 1-5 and alternative analysis
- `sql/schema.sql` - MySQL script

## Compile and run

```
sh run.sh
```

or manually from inside this folder (see `run.sh` for the exact commands). Compiled and run with Java 21.0.12.1.
Window: `java -cp out eventreg.app.Main` (in-memory demo data) or with MySQL: `java -Ddb.url=jdbc:mysql://localhost:3306/campus_events -Ddb.user=root -Ddb.password=... -cp "out:mysql-connector-j.jar" eventreg.app.Main` after running `sql/schema.sql`.

## Output

- `output/01_register_screen.png`
- `output/02_normal_registering_in_progress.png`
- `output/03_normal_registration_success.png`
- `output/04_registrations_table_new_row_last_page.png`
- `output/05_invalid_input_errors.png`
- `output/06_duplicate_registration_rejected.png`
- `output/07_filter_by_event.png`
- `output/LoadBench_console.png`
- `output/LoadBench_output.txt`
- `output/RegistrationTests_console.png`
- `output/RegistrationTests_output.txt`
- `output/ScreenshotHarness_console.png`
- `output/ScreenshotHarness_output.txt`
- `output/registrations_export.csv`

The `*_console.png` files are console-style images rendered from the real program output. Images of Swing screens were painted off-screen from the real components because the machine used had no desktop.
For submission, replace them with (or add) your own screenshots of the running windows, taken on your computer.
