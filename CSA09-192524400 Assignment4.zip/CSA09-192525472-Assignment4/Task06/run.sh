#!/bin/sh
# Compile and run Task06
cd "$(dirname "$0")"
mkdir -p out output
javac -d out $(find src -name "*.java")
java -Djava.awt.headless=true -cp out eventreg.app.RegistrationTests | tee output/RegistrationTests_output.txt
java -Djava.awt.headless=true -cp out eventreg.app.ScreenshotHarness | tee output/ScreenshotHarness_output.txt
java -Djava.awt.headless=true -Xmx1g -cp out eventreg.app.LoadBench | tee output/LoadBench_output.txt
# To open the real window (needs a desktop):
#   in-memory demo data : java -cp out eventreg.app.Main
#   MySQL (after running sql/schema.sql and adding the Connector/J jar):
#   java -Ddb.url=jdbc:mysql://localhost:3306/campus_events -Ddb.user=root -Ddb.password=YOURPASSWORD -cp "out:mysql-connector-j.jar" eventreg.app.Main
