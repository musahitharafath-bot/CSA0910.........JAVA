package eventreg.model;

/** One row of the registrations table (the event is shown by name). */
public record Registration(long id, String studentId, String studentName, String email, String eventName) { }
