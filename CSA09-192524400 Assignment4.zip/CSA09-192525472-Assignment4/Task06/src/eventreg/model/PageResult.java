package eventreg.model;

import java.util.List;

/** One page of rows plus the total number of matching rows (for "Page x of y"). */
public record PageResult(List<Registration> rows, int total, int page, int pageSize) {
    public int totalPages() { return Math.max(1, (total + pageSize - 1) / pageSize); }
}
