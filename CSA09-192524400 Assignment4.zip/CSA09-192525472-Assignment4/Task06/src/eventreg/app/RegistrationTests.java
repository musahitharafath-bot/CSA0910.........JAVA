package eventreg.app;

import eventreg.dao.DaoException;
import eventreg.dao.DuplicateRegistrationException;
import eventreg.dao.InMemoryRegistrationDao;
import eventreg.model.PageResult;
import eventreg.service.RegistrationService;
import eventreg.service.ValidationException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/** Headless tests of the service and DAO layers: normal, invalid and duplicate registrations, paging, export. */
public class RegistrationTests {
    static int passed, failed;
    static void check(String name, boolean ok) { System.out.println((ok ? "PASS " : "FAIL ") + name); if (ok) passed++; else failed++; }

    interface Body { void run() throws Exception; }
    static Class<?> thrown(Body b) { try { b.run(); return null; } catch (Exception e) { return e.getClass(); } }
    static List<String> errors(Body b) { try { b.run(); return List.of(); } catch (ValidationException e) { return e.errors(); } catch (Exception e) { return List.of("OTHER " + e); } }

    public static void main(String[] args) throws Exception {
        InMemoryRegistrationDao dao = new InMemoryRegistrationDao(SampleData.EVENTS, 0);
        RegistrationService s = new RegistrationService(dao);

        s.register("192525472", "Syed Aakif Hussain", "aakif@example.edu", "Hackathon");
        check("T1 normal registration saved", dao.count(null) == 1 && dao.exists("192525472", "Hackathon"));
        check("T2 same student, different event is allowed", thrown(() -> s.register("192525472", "Syed Aakif Hussain", "aakif@example.edu", "Quiz Bowl")) == null);
        check("T3 DUPLICATE (same student, same event) rejected", thrown(() -> s.register("192525472", "Syed Aakif Hussain", "aakif@example.edu", "Hackathon")) == DuplicateRegistrationException.class);
        check("T4 nothing extra was stored by the duplicate", dao.count(null) == 2);
        check("T5 invalid student id rejected", errors(() -> s.register("12ab", "Anitha R", "a@x.edu", "Hackathon")).contains("Student ID must be exactly 9 digits"));
        check("T6 invalid name rejected", errors(() -> s.register("192525001", "R", "a@x.edu", "Hackathon")).contains("Name must be 2-60 letters"));
        check("T7 invalid email rejected", errors(() -> s.register("192525001", "Anitha R", "not-an-email", "Hackathon")).contains("Email address is not valid"));
        check("T8 missing event rejected", errors(() -> s.register("192525001", "Anitha R", "a@x.edu", null)).contains("Select an event"));
        check("T9 all four errors are reported together", errors(() -> s.register("", "", "", null)).size() == 4);
        check("T10 SQL-injection style text rejected by validation", !errors(() -> s.register("1'; DROP TABLE registrations;--", "x", "y", "Hackathon")).isEmpty());
        check("T11 invalid input stored nothing", dao.count(null) == 2);

        InMemoryRegistrationDao big = new InMemoryRegistrationDao(SampleData.EVENTS, 0);
        SampleData.seed(big, 25);
        RegistrationService bs = new RegistrationService(big);
        PageResult p0 = bs.page(null, 0), p2 = bs.page(null, 2), p9 = bs.page(null, 99);
        check("T12 page 1 has 10 rows, 3 pages for 25 rows", p0.rows().size() == 10 && p0.totalPages() == 3 && p0.total() == 25);
        check("T13 last page has the remaining 5 rows", p2.rows().size() == 5);
        check("T14 page number beyond the end is clamped to the last page", p9.page() == 2);
        PageResult f = bs.page("Quiz Bowl", 0);
        check("T15 filter by event shows only that event (6 of 25)", f.total() == 6 && f.rows().stream().allMatch(r -> r.eventName().equals("Quiz Bowl")));

        // two clients race to register the same student: exactly one may succeed
        InMemoryRegistrationDao race = new InMemoryRegistrationDao(SampleData.EVENTS, 5);
        RegistrationService rs = new RegistrationService(race);
        AtomicInteger ok = new AtomicInteger(), dup = new AtomicInteger();
        Thread[] ts = new Thread[8];
        for (int i = 0; i < ts.length; i++) {
            ts[i] = new Thread(() -> {
                try { rs.register("192525999", "Race Test", "r@x.edu", "Dance Fest"); ok.incrementAndGet(); }
                catch (DuplicateRegistrationException e) { dup.incrementAndGet(); }
                catch (Exception e) { System.out.println("unexpected " + e); }
            });
            ts[i].start();
        }
        for (Thread t : ts) t.join();
        check("T16 8 simultaneous attempts: exactly 1 saved, 7 rejected as duplicates", ok.get() == 1 && dup.get() == 7 && race.count(null) == 1);

        Path csv = Files.createTempFile("reg", ".csv");
        InMemoryRegistrationDao weird = new InMemoryRegistrationDao(SampleData.EVENTS, 0);
        weird.insert("192525777", "Comma, Name", "=cmd@x.edu", "Hackathon");
        int n = new RegistrationService(weird).exportCsv(csv, null);
        String text = Files.readString(csv);
        check("T17 export writes header + 1 row", n == 1 && text.lines().count() == 2);
        check("T18 export quotes commas and neutralises a leading '='", text.contains("\"Comma, Name\"") && text.contains("'=cmd@x.edu"));
        int nBig = bs.exportCsv(csv, "Hackathon");
        check("T19 filtered export contains only that event's rows (7)", nBig == 7);

        System.out.println(passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }
}
