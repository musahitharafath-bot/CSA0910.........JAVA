package eventreg.app;

import eventreg.dao.InMemoryRegistrationDao;
import eventreg.model.Registration;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 * 100,000 registrations: load everything into a table model at once versus one page of 10 rows (LIMIT/OFFSET).
 * Measured in-process with the in-memory DAO, so the figures show the cost of building and holding the rows;
 * with MySQL the load-all cost grows further (network transfer is linear in the rows read).
 */
public class LoadBench {
    static volatile long sink;

    public static void main(String[] args) throws Exception {
        int n = 100_000;
        InMemoryRegistrationDao dao = new InMemoryRegistrationDao(SampleData.EVENTS, 0);
        SampleData.seed(dao, n);
        System.out.println("Registrations in the store: " + dao.count(null));
        String[] cols = {"ID", "Student ID", "Name", "Email", "Event"};

        // A. all rows at once
        System.gc(); long before = used();
        long t = System.nanoTime();
        List<Registration> all = dao.page(null, Integer.MAX_VALUE, 0);
        DefaultTableModel full = new DefaultTableModel(cols, 0);
        for (Registration r : all) full.addRow(new Object[]{r.id(), r.studentId(), r.studentName(), r.email(), r.eventName()});
        double loadAllMs = (System.nanoTime() - t) / 1e6;
        long loadAllBytes = used() - before;
        sink += full.getRowCount();

        // B. one page of 10 rows, first / middle / last page
        int[] offsets = {0, n / 2, n - 10};
        String[] names = {"first page (OFFSET 0)", "middle page (OFFSET 50000)", "last page (OFFSET 99990)"};
        System.gc(); before = used();
        DefaultTableModel pageModel = new DefaultTableModel(cols, 0);
        double[] pageMs = new double[3];
        for (int i = 0; i < 3; i++) {
            for (int w = 0; w < 5; w++) dao.page(null, 10, offsets[i]);          // warm-up
            t = System.nanoTime();
            int rounds = 20;
            for (int k = 0; k < rounds; k++) {
                pageModel.setRowCount(0);
                for (Registration r : dao.page(null, 10, offsets[i])) pageModel.addRow(new Object[]{r.id(), r.studentId(), r.studentName(), r.email(), r.eventName()});
            }
            pageMs[i] = (System.nanoTime() - t) / 1e6 / rounds;
        }
        long pageBytes = Math.max(used() - before, 0);
        sink += pageModel.getRowCount();

        System.out.printf("%n%-34s %-18s %-22s%n", "Approach", "Time (ms)", "Extra heap in use (MB)");
        System.out.printf("%-34s %-18.1f %-22.1f%n", "A. load all 100,000 rows", loadAllMs, loadAllBytes / 1048576.0);
        for (int i = 0; i < 3; i++)
            System.out.printf("%-34s %-18.3f %-22.3f%n", "B. " + names[i], pageMs[i], pageBytes / 1048576.0);
        System.out.println();
        System.out.printf("If approach A ran on the event-dispatch thread the window would be frozen for about %.0f ms;%n", loadAllMs);
        System.out.println("approach B runs in a SwingWorker and each page is tiny, so the window never freezes.");
        System.out.println("Both scan O(offset) rows inside the in-memory DAO (MySQL also walks OFFSET rows; a keyset 'WHERE reg_id > ?' would make deep pages O(1)).");
    }

    static long used() { System.gc(); Runtime r = Runtime.getRuntime(); return r.totalMemory() - r.freeMemory(); }
}
