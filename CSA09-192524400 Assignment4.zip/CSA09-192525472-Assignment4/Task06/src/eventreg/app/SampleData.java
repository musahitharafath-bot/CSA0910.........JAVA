package eventreg.app;

import eventreg.dao.DaoException;
import eventreg.dao.RegistrationDao;
import java.util.List;

/** Demo data for the in-memory DAO (the MySQL script has its own sample rows). */
public class SampleData {
    public static final List<String> EVENTS = List.of("Hackathon", "Dance Fest", "Quiz Bowl", "Music Night");
    private static final String[] NAMES = {"Anitha R", "Karthik S", "Divya M", "Rahul K", "Meena P", "Suresh V", "Priya N", "Arjun T", "Lakshmi D", "Vikram J"};

    public static void seed(RegistrationDao dao, int n) throws DaoException {
        for (int i = 0; i < n; i++) {
            String id = String.format("1925%05d", i + 1);
            String name = NAMES[i % NAMES.length];
            dao.insert(id, name, name.toLowerCase().replace(" ", ".") + (i + 1) + "@example.edu", EVENTS.get(i % EVENTS.size()));
        }
    }
}
