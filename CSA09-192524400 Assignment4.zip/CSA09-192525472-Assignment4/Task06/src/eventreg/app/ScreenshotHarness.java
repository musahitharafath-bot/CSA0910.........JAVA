package eventreg.app;

import eventreg.dao.InMemoryRegistrationDao;
import eventreg.service.RegistrationService;
import eventreg.ui.AppPanel;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.JMenuBar;
import javax.swing.SwingUtilities;

/**
 * Drives the real Swing application (AppPanel + menu bar + SwingWorkers) on a machine without a desktop and saves
 * each state as a PNG. Every step is tied to the requirement it demonstrates. The real window (MainFrame) is the same
 * panel inside a JFrame; take your own screenshots of it on your computer for the final submission.
 */
public class ScreenshotHarness {
    static AppPanel app;
    static JMenuBar bar;

    static void layoutAll(Component c) {
        if (c instanceof Container k) { k.doLayout(); for (Component child : k.getComponents()) layoutAll(child); }
    }

    static void waitIdle() throws Exception {
        long end = System.currentTimeMillis() + 10_000;
        while (true) {
            final boolean[] busy = new boolean[1];
            SwingUtilities.invokeAndWait(() -> busy[0] = app.isBusy());
            if (!busy[0]) return;
            if (System.currentTimeMillis() > end) throw new IllegalStateException("timed out waiting for background work");
            Thread.sleep(25);
        }
    }

    static void shot(String file, String requirement) throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            try {
                int w = 900, h = 520;
                bar.setSize(w, bar.getPreferredSize().height);
                layoutAll(bar);
                app.setSize(w, h - bar.getHeight());
                layoutAll(app);
                BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
                Graphics2D g = img.createGraphics();
                g.setColor(Color.WHITE); g.fillRect(0, 0, w, h);
                bar.paint(g);
                g.translate(0, bar.getHeight());
                app.paint(g);
                g.dispose();
                ImageIO.write(img, "png", new File("output/" + file));
            } catch (Exception e) { throw new RuntimeException(e); }
        });
        System.out.println("   screenshot output/" + file + "  <- " + requirement);
    }

    static String message() throws Exception {
        final String[] m = new String[1];
        SwingUtilities.invokeAndWait(() -> m[0] = app.form().messageText());
        return m[0];
    }

    public static void main(String[] args) throws Exception {
        new File("output").mkdirs();
        InMemoryRegistrationDao dao = new InMemoryRegistrationDao(SampleData.EVENTS, 150);   // 150 ms: imitates a database call
        SampleData.seed(dao, 25);
        RegistrationService service = new RegistrationService(dao);
        SwingUtilities.invokeAndWait(() -> { app = new AppPanel(service); bar = app.createMenuBar(); app.start(); });
        waitIdle();

        System.out.println("S1 Start-up: events and first page loaded in the background");
        shot("01_register_screen.png", "Stage 2: register screen with menu bar (File / View / Help)");

        System.out.println("S2 NORMAL registration: 192525100, Syed Aakif Hussain, Hackathon");
        SwingUtilities.invokeAndWait(() -> { app.form().fill("192525100", "Syed Aakif Hussain", "aakif@example.edu", "Hackathon"); app.form().submit(); });
        SwingUtilities.invokeAndWait(() -> System.out.println("   right after the click the window is not blocked; message = '" + app.form().messageText() + "'"));
        shot("02_normal_registering_in_progress.png", "Stage 3: long-running DB work off the event thread (Saving... shown, UI still painting)");
        waitIdle();
        System.out.println("   result message: " + message());
        shot("03_normal_registration_success.png", "Test N1: valid registration accepted, confirmation shown");

        SwingUtilities.invokeAndWait(() -> app.showScreen(AppPanel.LIST));
        waitIdle();
        SwingUtilities.invokeAndWait(() -> System.out.println("   registrations screen: page " + (app.view().pageNumber() + 1) + ", rows on page = " + app.view().rowCount()));
        shot("04_registrations_table_new_row_last_page.png", "Test N1: the new registration appears in the table (last page)");

        System.out.println("S3 INVALID input: id '12ab', name 'A', email 'bad', no event");
        SwingUtilities.invokeAndWait(() -> { app.showScreen(AppPanel.REGISTER); app.form().fill("12ab", "A", "bad", null); app.form().submit(); });
        waitIdle();
        System.out.println("   result message: " + message());
        shot("05_invalid_input_errors.png", "Test I1: all four validation errors shown, nothing saved");

        System.out.println("S4 DUPLICATE registration: same student, same event again");
        SwingUtilities.invokeAndWait(() -> { app.form().fill("192525100", "Syed Aakif Hussain", "aakif@example.edu", "Hackathon"); app.form().submit(); });
        waitIdle();
        System.out.println("   result message: " + message());
        shot("06_duplicate_registration_rejected.png", "Test D1: duplicate registration rejected with a clear message");

        System.out.println("S5 FILTER by event: Dance Fest");
        SwingUtilities.invokeAndWait(() -> { app.showScreen(AppPanel.LIST); app.view().selectFilter("Dance Fest"); });
        waitIdle();
        SwingUtilities.invokeAndWait(() -> System.out.println("   filtered table shows " + app.view().rowCount() + " rows on page " + (app.view().pageNumber() + 1)));
        shot("07_filter_by_event.png", "Test F1: table filtered by event (Dance Fest only)");

        System.out.println("S6 EXPORT to CSV");
        java.io.File csv = new java.io.File("output/registrations_export.csv");
        SwingUtilities.invokeAndWait(() -> app.exportTo(csv.toPath()));
        Thread.sleep(600);
        System.out.println("   exported file lines: " + java.nio.file.Files.readAllLines(csv.toPath()).size() + " (header + " + (java.nio.file.Files.readAllLines(csv.toPath()).size() - 1) + " registrations)");
        System.exit(0);
    }
}
