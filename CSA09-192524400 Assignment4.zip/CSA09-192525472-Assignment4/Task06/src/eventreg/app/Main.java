package eventreg.app;

import eventreg.dao.InMemoryRegistrationDao;
import eventreg.dao.JdbcRegistrationDao;
import eventreg.dao.RegistrationDao;
import eventreg.service.RegistrationService;
import eventreg.ui.MainFrame;
import javax.swing.SwingUtilities;

/**
 * Start-up. With -Ddb.url=jdbc:mysql://localhost:3306/campus_events -Ddb.user=... -Ddb.password=... (and the MySQL
 * Connector/J jar on the class path) the application uses MySQL; without them it uses the in-memory demo data.
 */
public class Main {
    public static void main(String[] args) throws Exception {
        String url = System.getProperty("db.url");
        RegistrationDao dao;
        if (url != null) {
            dao = new JdbcRegistrationDao(url, System.getProperty("db.user", "root"), System.getProperty("db.password", ""));
            System.out.println("Using MySQL: " + url);
        } else {
            InMemoryRegistrationDao mem = new InMemoryRegistrationDao(SampleData.EVENTS, 300);   // 300 ms imitates a slow database
            SampleData.seed(mem, 25);
            dao = mem;
            System.out.println("No -Ddb.url given: using in-memory demo data (25 registrations, 300 ms simulated latency)");
        }
        RegistrationService service = new RegistrationService(dao);
        SwingUtilities.invokeLater(() -> new MainFrame(service).setVisible(true));
    }
}
