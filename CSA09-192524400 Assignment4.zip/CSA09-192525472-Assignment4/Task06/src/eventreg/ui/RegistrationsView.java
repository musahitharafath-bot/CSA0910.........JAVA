package eventreg.ui;

import eventreg.dao.DaoException;
import eventreg.model.PageResult;
import eventreg.model.Registration;
import eventreg.service.RegistrationService;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.List;
import java.util.concurrent.ExecutionException;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingWorker;
import javax.swing.table.DefaultTableModel;

/** Table screen: one page at a time (SQL LIMIT/OFFSET) loaded by a SwingWorker, filtered by event. */
public class RegistrationsView extends JPanel {
    private static final String ALL = "All events";
    private final RegistrationService service;
    private final JComboBox<String> filter = new JComboBox<>();
    private final DefaultTableModel model = new DefaultTableModel(new Object[]{"ID", "Student ID", "Name", "Email", "Event"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JButton prev = new JButton("Prev");
    private final JButton next = new JButton("Next");
    private final JLabel pageLabel = new JLabel("Page 1 of 1");
    private final JLabel state = new JLabel(" ");
    private int page;
    private int totalPages = 1;
    private boolean busy, updatingFilter;

    public RegistrationsView(RegistrationService service) {
        super(new BorderLayout());
        this.service = service;
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        top.add(new JLabel("Event:")); top.add(filter); top.add(state);
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 6));
        bottom.add(prev); bottom.add(pageLabel); bottom.add(next);
        add(top, BorderLayout.NORTH);
        JScrollPane scroll = new JScrollPane(table);
        scroll.setColumnHeaderView(table.getTableHeader());
        add(scroll, BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);
        table.setAutoCreateRowSorter(false);
        filter.addItem(ALL);
        prev.addActionListener(e -> load(page - 1));
        next.addActionListener(e -> load(page + 1));
        filter.addActionListener(e -> { if (!updatingFilter) load(0); });
    }

    public void setEvents(List<String> names) {
        updatingFilter = true;
        filter.removeAllItems();
        filter.addItem(ALL);
        for (String n : names) filter.addItem(n);
        updatingFilter = false;
    }

    public void selectFilter(String eventName) { filter.setSelectedItem(eventName == null ? ALL : eventName); }
    public boolean isBusy() { return busy; }
    public int pageNumber() { return page; }
    public int rowCount() { return model.getRowCount(); }
    public String stateText() { return state.getText(); }

    private String currentFilter() {
        String sel = (String) filter.getSelectedItem();
        return sel == null || sel.equals(ALL) ? null : sel;
    }

    /** Loads one page in the background; the table is only touched on the event-dispatch thread in done(). */
    public void load(int wantedPage) {
        busy = true;
        prev.setEnabled(false); next.setEnabled(false); filter.setEnabled(false);
        state.setText("Loading...");
        String ev = currentFilter();
        new SwingWorker<PageResult, Void>() {
            @Override protected PageResult doInBackground() throws Exception { return service.page(ev, wantedPage); }
            @Override protected void done() {
                try {
                    PageResult r = get();
                    model.setRowCount(0);
                    for (Registration x : r.rows()) model.addRow(new Object[]{x.id(), x.studentId(), x.studentName(), x.email(), x.eventName()});
                    page = r.page(); totalPages = r.totalPages();
                    pageLabel.setText("Page " + (page + 1) + " of " + totalPages + "  (" + r.total() + " registrations)");
                    state.setText(" ");
                } catch (ExecutionException ex) {
                    state.setText("Could not load: " + (ex.getCause() instanceof DaoException ? ex.getCause().getMessage() : ex.getCause()));
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                } finally {
                    prev.setEnabled(page > 0); next.setEnabled(page < totalPages - 1); filter.setEnabled(true);
                    busy = false;
                }
            }
        }.execute();
    }
}
