package eventreg.ui;

import eventreg.service.RegistrationService;
import javax.swing.JFrame;

/** The window: it only hosts the panel and the menu bar. */
public class MainFrame extends JFrame {
    public MainFrame(RegistrationService service) {
        super("Campus Event Registration");
        AppPanel panel = new AppPanel(service);
        setContentPane(panel);
        setJMenuBar(panel.createMenuBar());
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 560);
        setLocationRelativeTo(null);
        panel.start();
    }
}
