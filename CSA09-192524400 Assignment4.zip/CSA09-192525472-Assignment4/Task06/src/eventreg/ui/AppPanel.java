package eventreg.ui;

import eventreg.dao.DaoException;
import eventreg.service.RegistrationService;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.event.KeyEvent;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.ExecutionException;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.SwingWorker;

/** Main content: the two screens in a CardLayout, a status line and the menu bar. */
public class AppPanel extends JPanel {
    public static final String REGISTER = "register", LIST = "list";
    private final RegistrationService service;
    private final CardLayout cards = new CardLayout();
    private final JPanel center = new JPanel(cards);
    private final RegistrationsView view;
    private final RegisterForm form;
    private final JLabel status = new JLabel("Ready");
    private boolean loadingEvents;

    public AppPanel(RegistrationService service) {
        super(new BorderLayout());
        this.service = service;
        view = new RegistrationsView(service);
        form = new RegisterForm(service, () -> view.load(Integer.MAX_VALUE));   // refresh, clamped to the last page
        center.add(form, REGISTER);
        center.add(view, LIST);
        add(center, BorderLayout.CENTER);
        add(status, BorderLayout.SOUTH);
        showScreen(REGISTER);
    }

    public RegisterForm form() { return form; }
    public RegistrationsView view() { return view; }
    public boolean isBusy() { return loadingEvents || form.isBusy() || view.isBusy(); }
    public void showScreen(String name) { cards.show(center, name); status.setText(name.equals(REGISTER) ? "Register screen" : "Registrations screen"); }

    /** Loads the event list and the first page in the background. */
    public void start() {
        loadingEvents = true;
        new SwingWorker<List<String>, Void>() {
            @Override protected List<String> doInBackground() throws Exception { return service.events(); }
            @Override protected void done() {
                try {
                    List<String> names = get();
                    form.setEvents(names); view.setEvents(names); view.load(0);
                } catch (ExecutionException ex) {
                    status.setText("Database unavailable: " + (ex.getCause() instanceof DaoException ? ex.getCause().getMessage() : ex.getCause()));
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                } finally {
                    loadingEvents = false;
                }
            }
        }.execute();
    }

    public JMenuBar createMenuBar() {
        JMenuBar bar = new JMenuBar();
        JMenu file = new JMenu("File");
        JMenuItem export = new JMenuItem("Export CSV...");
        JMenuItem exit = new JMenuItem("Exit");
        file.add(export); file.addSeparator(); file.add(exit);
        JMenu viewMenu = new JMenu("View");
        JMenuItem reg = new JMenuItem("Register");
        JMenuItem list = new JMenuItem("Registrations");
        reg.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, KeyEvent.CTRL_DOWN_MASK));
        list.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, KeyEvent.CTRL_DOWN_MASK));
        viewMenu.add(reg); viewMenu.add(list);
        JMenu help = new JMenu("Help");
        JMenuItem about = new JMenuItem("About");
        help.add(about);
        bar.add(file); bar.add(viewMenu); bar.add(help);

        reg.addActionListener(e -> showScreen(REGISTER));
        list.addActionListener(e -> { showScreen(LIST); view.load(view.pageNumber()); });
        about.addActionListener(e -> JOptionPane.showMessageDialog(this, "Campus Event Registration\nSwing + JDBC, CSA09 Assignment 4"));
        exit.addActionListener(e -> System.exit(0));
        export.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setSelectedFile(new java.io.File("registrations.csv"));
            if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) exportTo(chooser.getSelectedFile().toPath());
        });
        return bar;
    }

    /** Export runs in the background too; the result is reported in the status line. */
    public void exportTo(Path file) {
        status.setText("Exporting...");
        new SwingWorker<Integer, Void>() {
            @Override protected Integer doInBackground() throws Exception { return service.exportCsv(file, null); }
            @Override protected void done() {
                try { status.setText("Exported " + get() + " registrations to " + file); }
                catch (ExecutionException ex) { status.setText("Export failed: " + ex.getCause().getMessage()); }
                catch (InterruptedException ex) { Thread.currentThread().interrupt(); }
            }
        }.execute();
    }
}
