package eventreg.ui;

import eventreg.dao.DaoException;
import eventreg.dao.DuplicateRegistrationException;
import eventreg.service.RegistrationService;
import eventreg.service.ValidationException;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;
import java.util.concurrent.ExecutionException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingWorker;

/** Registration screen. The database call runs in a SwingWorker, so the window stays responsive. */
public class RegisterForm extends JPanel {
    private final RegistrationService service;
    private final Runnable onRegistered;
    private final JTextField studentId = new JTextField(14);
    private final JTextField name = new JTextField(24);
    private final JTextField email = new JTextField(24);
    private final JComboBox<String> event = new JComboBox<>();
    private final JButton register = new JButton("Register");
    private final JButton clear = new JButton("Clear");
    private final JLabel message = new JLabel(" ");
    private boolean busy;

    public RegisterForm(RegistrationService service, Runnable onRegistered) {
        super(new GridBagLayout());
        this.service = service;
        this.onRegistered = onRegistered;
        setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6, 6, 6, 6); c.anchor = GridBagConstraints.WEST;
        JLabel heading = new JLabel("Register for an event");
        heading.setFont(heading.getFont().deriveFont(java.awt.Font.BOLD, 18f));
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2; add(heading, c);
        c.gridwidth = 1;
        addRow(c, 1, "Student ID (9 digits)", studentId);
        addRow(c, 2, "Full name", name);
        addRow(c, 3, "Email", email);
        addRow(c, 4, "Event", event);
        JPanel buttons = new JPanel(); buttons.add(register); buttons.add(clear);
        c.gridx = 1; c.gridy = 5; add(buttons, c);
        c.gridx = 0; c.gridy = 6; c.gridwidth = 2; c.weightx = 1; c.weighty = 1; c.anchor = GridBagConstraints.NORTHWEST;
        add(message, c);

        register.addActionListener(e -> submit());
        clear.addActionListener(e -> clearFields());
        studentId.addActionListener(e -> submit());     // Enter in a field also registers
    }

    private void addRow(GridBagConstraints c, int row, String label, java.awt.Component field) {
        c.gridx = 0; c.gridy = row; add(new JLabel(label), c);
        c.gridx = 1; add(field, c);
    }

    public void setEvents(List<String> names) {
        event.removeAllItems();
        for (String n : names) event.addItem(n);
        event.setSelectedIndex(-1);
    }

    /** Used by the screenshot harness and tests to fill the form without typing. */
    public void fill(String id, String fullName, String mail, String eventName) {
        studentId.setText(id); name.setText(fullName); email.setText(mail); event.setSelectedItem(eventName);
        if (eventName == null) event.setSelectedIndex(-1);
    }

    public boolean isBusy() { return busy; }
    public String messageText() { return message.getText().replace("&bull;", "-").replaceAll("<[^>]*>", " ").replaceAll("\\s+", " ").trim(); }

    private void clearFields() { fill("", "", "", null); show(" ", Color.BLACK); }

    private void show(String text, Color colour) { message.setForeground(colour); message.setText(text); }

    public void submit() {
        if (busy) return;                                   // ignore a second click while the first is running
        busy = true;
        register.setEnabled(false);
        show("Saving...", Color.DARK_GRAY);
        String id = studentId.getText(), nm = name.getText(), em = email.getText(), ev = (String) event.getSelectedItem();
        new SwingWorker<Void, Void>() {
            @Override protected Void doInBackground() throws Exception {      // background thread: no Swing calls here
                service.register(id, nm, em, ev);
                return null;
            }
            @Override protected void done() {                                  // event-dispatch thread again
                try {
                    get();
                    show("Registered " + id.trim() + " for " + ev + ".", new Color(0, 120, 0));
                    clearTextFields();
                    onRegistered.run();
                } catch (ExecutionException ex) {
                    Throwable cause = ex.getCause();
                    if (cause instanceof ValidationException v) {
                        StringBuilder sb = new StringBuilder("<html>Please correct:<br>");
                        for (String err : v.errors()) sb.append("&bull; ").append(err).append("<br>");
                        show(sb.append("</html>").toString(), Color.RED);
                    } else if (cause instanceof DuplicateRegistrationException d) {
                        show("<html>Not registered: " + d.getMessage() + ".</html>", new Color(200, 90, 0));
                    } else if (cause instanceof DaoException d) {
                        show("<html>Database problem: " + d.getMessage() + ". Nothing was saved.</html>", Color.RED);
                    } else {
                        show("Unexpected error: " + cause, Color.RED);
                    }
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                } finally {
                    register.setEnabled(true);
                    busy = false;
                }
            }
        }.execute();
    }

    private void clearTextFields() { studentId.setText(""); name.setText(""); email.setText(""); }
}
