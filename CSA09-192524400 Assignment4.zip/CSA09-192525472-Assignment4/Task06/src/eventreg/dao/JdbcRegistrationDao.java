package eventreg.dao;

import eventreg.model.Registration;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

/**
 * MySQL implementation (JDBC). Every statement is a PreparedStatement, every connection is closed by
 * try-with-resources, and paging is done by the database with LIMIT / OFFSET.
 * Needs the MySQL Connector/J jar on the class path and the tables from sql/schema.sql.
 */
public class JdbcRegistrationDao implements RegistrationDao {
    private static final String FROM = " FROM registrations r JOIN events e ON r.event_id = e.event_id ";
    private final String url, user, password;

    public JdbcRegistrationDao(String url, String user, String password) {
        this.url = url; this.user = user; this.password = password;
    }

    private Connection open() throws SQLException { return DriverManager.getConnection(url, user, password); }

    @Override public List<String> eventNames() throws DaoException {
        try (Connection c = open(); PreparedStatement ps = c.prepareStatement("SELECT name FROM events ORDER BY event_date");
             ResultSet rs = ps.executeQuery()) {
            List<String> names = new ArrayList<>();
            while (rs.next()) names.add(rs.getString(1));
            return names;
        } catch (SQLException e) { throw new DaoException("Could not read the event list", e); }
    }

    @Override public boolean exists(String studentId, String eventName) throws DaoException {
        String sql = "SELECT 1" + FROM + "WHERE r.student_id = ? AND e.name = ?";
        try (Connection c = open(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, studentId); ps.setString(2, eventName);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        } catch (SQLException e) { throw new DaoException("Could not check for an existing registration", e); }
    }

    @Override public void insert(String studentId, String studentName, String email, String eventName) throws DaoException {
        String sql = "INSERT INTO registrations (student_id, student_name, email, event_id) "
                   + "SELECT ?, ?, ?, event_id FROM events WHERE name = ?";
        try (Connection c = open(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, studentId); ps.setString(2, studentName); ps.setString(3, email); ps.setString(4, eventName);
            if (ps.executeUpdate() == 0) throw new DaoException("Unknown event: " + eventName);
        } catch (SQLIntegrityConstraintViolationException e) {          // uq_student_event fired: another client was faster
            throw new DuplicateRegistrationException("Student " + studentId + " is already registered for " + eventName);
        } catch (SQLException e) { throw new DaoException("Could not save the registration", e); }
    }

    @Override public List<Registration> page(String eventFilter, int limit, int offset) throws DaoException {
        String sql = "SELECT r.reg_id, r.student_id, r.student_name, r.email, e.name" + FROM
                   + "WHERE (? IS NULL OR e.name = ?) ORDER BY r.reg_id LIMIT ? OFFSET ?";
        try (Connection c = open(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, eventFilter); ps.setString(2, eventFilter); ps.setInt(3, limit); ps.setInt(4, offset);
            try (ResultSet rs = ps.executeQuery()) {
                List<Registration> rows = new ArrayList<>();
                while (rs.next()) rows.add(new Registration(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)));
                return rows;
            }
        } catch (SQLException e) { throw new DaoException("Could not load registrations", e); }
    }

    @Override public int count(String eventFilter) throws DaoException {
        String sql = "SELECT COUNT(*)" + FROM + "WHERE (? IS NULL OR e.name = ?)";
        try (Connection c = open(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, eventFilter); ps.setString(2, eventFilter);
            try (ResultSet rs = ps.executeQuery()) { rs.next(); return rs.getInt(1); }
        } catch (SQLException e) { throw new DaoException("Could not count registrations", e); }
    }
}
