package eventreg.dao;

/** Raised when the (student, event) pair already exists - the database's UNIQUE rule or the in-memory equivalent. */
public class DuplicateRegistrationException extends DaoException {
    public DuplicateRegistrationException(String message) { super(message); }
}
