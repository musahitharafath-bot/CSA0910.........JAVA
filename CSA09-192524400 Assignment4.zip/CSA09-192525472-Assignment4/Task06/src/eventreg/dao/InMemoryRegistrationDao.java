package eventreg.dao;

import eventreg.model.Registration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * In-memory stand-in for MySQL, used for the demo, the tests and the benchmark on a machine without a database.
 * It enforces the same UNIQUE (student, event) rule and the same LIMIT/OFFSET paging as the JDBC version.
 */
public class InMemoryRegistrationDao implements RegistrationDao {
    private final List<String> events;
    private final List<Registration> rows = new ArrayList<>();
    private final Set<String> keys = new HashSet<>();
    private long nextId = 1;
    private final long latencyMs;

    public InMemoryRegistrationDao(List<String> events, long latencyMs) { this.events = List.copyOf(events); this.latencyMs = latencyMs; }

    private void pause() {
        if (latencyMs > 0) try { Thread.sleep(latencyMs); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    @Override public synchronized List<String> eventNames() { return events; }

    @Override public synchronized boolean exists(String studentId, String eventName) { pause(); return keys.contains(studentId + "|" + eventName); }

    @Override public synchronized void insert(String studentId, String studentName, String email, String eventName) throws DaoException {
        pause();
        if (!events.contains(eventName)) throw new DaoException("Unknown event: " + eventName);
        if (!keys.add(studentId + "|" + eventName))
            throw new DuplicateRegistrationException("Student " + studentId + " is already registered for " + eventName);
        rows.add(new Registration(nextId++, studentId, studentName, email, eventName));
    }

    @Override public synchronized List<Registration> page(String eventFilter, int limit, int offset) {
        pause();
        List<Registration> out = new ArrayList<>();
        int skipped = 0;
        for (Registration r : rows) {
            if (eventFilter != null && !r.eventName().equals(eventFilter)) continue;
            if (skipped++ < offset) continue;
            if (out.size() == limit) break;
            out.add(r);
        }
        return out;
    }

    @Override public synchronized int count(String eventFilter) {
        if (eventFilter == null) return rows.size();
        int n = 0;
        for (Registration r : rows) if (r.eventName().equals(eventFilter)) n++;
        return n;
    }
}
