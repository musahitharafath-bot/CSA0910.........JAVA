package eventreg.dao;

import eventreg.model.Registration;
import java.util.List;

/** Data-access layer: the only place that knows how rows are stored. eventFilter == null means "all events". */
public interface RegistrationDao {
    List<String> eventNames() throws DaoException;
    boolean exists(String studentId, String eventName) throws DaoException;
    void insert(String studentId, String studentName, String email, String eventName) throws DaoException;
    List<Registration> page(String eventFilter, int limit, int offset) throws DaoException;
    int count(String eventFilter) throws DaoException;
}
