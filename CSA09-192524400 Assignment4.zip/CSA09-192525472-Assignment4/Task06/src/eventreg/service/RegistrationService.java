package eventreg.service;

import eventreg.dao.DaoException;
import eventreg.dao.DuplicateRegistrationException;
import eventreg.dao.RegistrationDao;
import eventreg.model.PageResult;
import eventreg.model.Registration;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** Business layer: validation, duplicate check, paging and export. No Swing here, so it is fully testable. */
public class RegistrationService {
    public static final int PAGE_SIZE = 10;
    private static final Pattern STUDENT_ID = Pattern.compile("[0-9]{9}");
    private static final Pattern NAME = Pattern.compile("[A-Za-z][A-Za-z .'-]{1,59}");
    private static final Pattern EMAIL = Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}");
    private final RegistrationDao dao;

    public RegistrationService(RegistrationDao dao) { this.dao = dao; }

    public List<String> events() throws DaoException { return dao.eventNames(); }

    /** Rules R1-R5 of Stage 1: every error is collected, nothing is saved unless the list is empty. */
    public void register(String studentId, String name, String email, String event) throws ValidationException, DaoException {
        List<String> errors = new ArrayList<>();
        String id = studentId == null ? "" : studentId.trim();
        String nm = name == null ? "" : name.trim();
        String em = email == null ? "" : email.trim();
        if (!STUDENT_ID.matcher(id).matches()) errors.add("Student ID must be exactly 9 digits");
        if (!NAME.matcher(nm).matches()) errors.add("Name must be 2-60 letters");
        if (!EMAIL.matcher(em).matches()) errors.add("Email address is not valid");
        if (event == null || event.isBlank()) errors.add("Select an event");
        if (!errors.isEmpty()) throw new ValidationException(errors);
        if (dao.exists(id, event))
            throw new DuplicateRegistrationException("Student " + id + " is already registered for " + event);
        dao.insert(id, nm, em, event);          // the UNIQUE constraint still protects against a race between two clients
    }

    public PageResult page(String eventFilter, int page) throws DaoException {
        int total = dao.count(eventFilter);
        int pages = Math.max(1, (total + PAGE_SIZE - 1) / PAGE_SIZE);
        int p = Math.min(Math.max(page, 0), pages - 1);
        return new PageResult(dao.page(eventFilter, PAGE_SIZE, p * PAGE_SIZE), total, p, PAGE_SIZE);
    }

    /** Writes every matching row to a CSV file, one page at a time so memory use stays small. Returns the row count. */
    public int exportCsv(Path file, String eventFilter) throws DaoException, IOException {
        int written = 0;
        try (BufferedWriter w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
            w.write("id,student_id,name,email,event\n");
            for (int offset = 0; ; offset += 500) {
                List<Registration> rows = dao.page(eventFilter, 500, offset);
                for (Registration r : rows) {
                    w.write(r.id() + "," + csv(r.studentId()) + "," + csv(r.studentName()) + "," + csv(r.email()) + "," + csv(r.eventName()) + "\n");
                    written++;
                }
                if (rows.size() < 500) break;
            }
        }
        return written;
    }

    static String csv(String s) {
        boolean quote = s.contains(",") || s.contains("\"") || s.contains("\n");
        String t = s.replace("\"", "\"\"");
        if (!t.isEmpty() && "=+-@".indexOf(t.charAt(0)) >= 0) t = "'" + t;      // stop spreadsheet formula injection
        return quote ? "\"" + t + "\"" : t;
    }
}
