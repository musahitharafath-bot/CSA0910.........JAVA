package eventreg.service;

import java.util.List;

/** Carries every problem found in the form, so the user sees all of them at once. */
public class ValidationException extends Exception {
    private final List<String> errors;
    public ValidationException(List<String> errors) { super(String.join("; ", errors)); this.errors = List.copyOf(errors); }
    public List<String> errors() { return errors; }
}
