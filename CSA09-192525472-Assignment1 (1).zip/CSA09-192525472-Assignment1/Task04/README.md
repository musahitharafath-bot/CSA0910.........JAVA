# Task04 – Design Classes, Objects and Constructors

**Student:** Syed Aakif Hussain S A  |  **Register No.:** 192525472

## Contents

| Folder | What it holds |
|---|---|
| `src/` | Java source code |
| `input/` | No input file needed for this task |
| `output/` | Console output (`*_output.txt`) and console screenshots (`*_console.png`) |

## Source files

- `src/ParkingSlot.java`
- `src/ParkingTicket.java`
- `src/SlotDemo.java`
- `src/TicketDemo.java`

## Compile and run

```
sh run.sh
```

or manually, from inside this folder (see `run.sh` for the exact commands). Tested with Compiled and run with Java 21.0.12.1.

## Output

- `output/SlotDemo_console.png`
- `output/TicketDemo_console.png`

The `.png` files are console-style images rendered from the real program output. For submission, replace them with your own screenshots taken on your computer.
